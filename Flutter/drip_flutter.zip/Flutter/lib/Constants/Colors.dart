import 'dart:ui';

const kPrimaryColor = Color(0xFFF07846);