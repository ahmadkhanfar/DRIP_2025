import 'dart:collection';
import 'dart:convert';

import '../Services/Controllers/open_drone_id_parser.dart';
import 'Constants.dart';

class LogMessageEntry {
  static  String DELIM = Constants.DELIM;
  static  String DELIM_BASIC_ID = DELIM + DELIM + DELIM;
  static  String DELIM_LOCATION = DELIM * 17;
  static  String DELIM_AUTHENTICATION = DELIM * 6;
  static  String DELIM_SELF_ID = DELIM + DELIM;
  static  String DELIM_SYSTEM = DELIM * 12;
  static  String DELIM_OPERATOR = DELIM + DELIM;

  List<Message> messages = [];

  int msgVersion = 0;

  int getMsgVersion() => msgVersion;
  setMsgVersion(int version) {
    msgVersion = version;
  }

  void add(Message message) {
    messages.add(message);
  }

  StringBuffer getMessageLogEntry() {
    if (messages.isEmpty) {
      // Return an empty StringBuffer instead of null
      return StringBuffer();
    }

    // Sort the messages
    messages.sort((a, b) => a.compareTo(b));

    StringBuffer entry = StringBuffer();
    int i = 0;

    // Processing Basic ID
    for (int j = 0; j < 2; j++) {
      if (i < messages.length && messages[i].header.type == MessageType.basicId) {
        var message = messages[i] as Message<BasicId>;
        entry.write(message.payload.toCsvString());
        i++;
      } else {
        entry.write(DELIM_BASIC_ID);
      }
    }
    // Skip additional Basic ID messages
    while (i < messages.length && messages[i].header.type == MessageType.basicId) {
      i++;
    }

    // Processing Location
    if (i < messages.length && messages[i].header.type == MessageType.location) {
      var message = messages[i] as Message<Location>;
      entry.write(message.payload.toCsvString());
      i++;
    } else {
      entry.write(DELIM_LOCATION);
    }
    while (i < messages.length && messages[i].header.type == MessageType.location) {
      i++;
    }

    // Skip authentication messages
    while (i < messages.length && messages[i].header.type == MessageType.auth) {
      i++;
    }

    // Processing Self ID
    if (i < messages.length && messages[i].header.type == MessageType.selfId) {
      var message = messages[i] as Message<SelfID>;
      entry.write(message.payload.toCsvString());
      i++;
    } else {
      entry.write(DELIM_SELF_ID);
    }
    while (i < messages.length && messages[i].header.type == MessageType.selfId) {
      i++;
    }

    // Processing System
    if (i < messages.length && messages[i].header.type == MessageType.system) {
      var message = messages[i] as Message<SystemMsg>;
      entry.write(message.payload.toCsvString());
      i++;
    } else {
      entry.write(DELIM_SYSTEM);
    }
    while (i < messages.length && messages[i].header.type == MessageType.system) {
      i++;
    }

    // Processing Operator ID
    if (i < messages.length && messages[i].header.type == MessageType.operatorId) {
      var message = messages[i] as Message<OperatorID>;
      entry.write(message.payload.toCsvString());
    } else {
      entry.write(DELIM_OPERATOR);
    }

    // Add authentication data at the end
    i = 0;
    while (i < messages.length && messages[i].header.type == MessageType.basicId) i++;
    while (i < messages.length && messages[i].header.type == MessageType.location) i++;
    for (int j = 0; j < Constants.MAX_AUTH_DATA_PAGES; j++) {
      if (i < messages.length && messages[i].header.type == MessageType.auth) {
        var message = messages[i] as Message<Authentication>;
        if (message.payload.authDataPage == j) {
          entry.write(message.payload.toCsvString());
          i++;
        } else {
          entry.write(DELIM_AUTHENTICATION);
        }
      } else {
        entry.write(DELIM_AUTHENTICATION);
      }
    }

    return entry;
  }
}
