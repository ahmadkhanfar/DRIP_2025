class Constants {
  // Request Codes for Permissions and Bluetooth/WiFi
  static const int REQUEST_ENABLE_BT = 1;
  static const int FINE_LOCATION_PERMISSION_REQUEST_CODE = 2;
  static const int REQUEST_ENABLE_WIFI = 3;
  static const int REQUEST_BLUETOOTH_PERMISSION_SCAN = 4;
  static const int REQUEST_BLUETOOTH_PERMISSION_CONNECT = 5;
  static const int REQUEST_NEARBY_WIFI_DEVICES_PERMISSION = 6;


  // Delimiter for CSV-like formats
  static const String DELIM = ",";

  // Maximum Sizes for Various Data Fields
  static const int MAX_ID_BYTE_SIZE = 20;
  static const int MAX_STRING_BYTE_SIZE = 23;
  static const int MAX_AUTH_DATA_PAGES = 16;
  static const int MAX_AUTH_PAGE_ZERO_SIZE = 17;
  static const int MAX_AUTH_PAGE_NON_ZERO_SIZE = 23;
  static const int MAX_AUTH_DATA =
      MAX_AUTH_PAGE_ZERO_SIZE + (MAX_AUTH_DATA_PAGES - 1) * MAX_AUTH_PAGE_NON_ZERO_SIZE;
  static const int MAX_MESSAGE_SIZE = 25;
  static const int MAX_MESSAGES_IN_PACK = 9;
  static const int MAX_MESSAGE_PACK_SIZE = MAX_MESSAGE_SIZE * MAX_MESSAGES_IN_PACK;

  // Remote ID Protocol Versions
  static const int MAX_MSG_VERSION = 2;
}
