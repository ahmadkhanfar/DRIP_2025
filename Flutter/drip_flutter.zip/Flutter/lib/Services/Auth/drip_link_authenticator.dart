import 'dart:typed_data';
import 'dart:collection';
import 'package:cryptography/cryptography.dart';
/*
class DRIPLinkAuthenticator {
  // Cache for DETs
  final HashMap<String, Uint8List> detCache = HashMap();

  // Verify signature using Ed25519
  Future<bool> verifySignature(Uint8List message, Uint8List signature, SimplePublicKey publicKey) async {
    final algorithm = Ed25519();
    try {
      return await algorithm.verify(
        message,
        signature: Signature(signature, publicKey: publicKey),
      );
    } catch (e) {
      print("Signature verification failed: $e");
      return false;
    }
  }

  // Validate VNB (Valid Not Before) and VNA (Valid Not After) timestamps
  bool validateTimestamps(int vnb, int vna) {
    int currentTime = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    print("VNB (Valid Not Before): $vnb");
    print("VNA (Valid Not After): $vna");
    print("Current Time: $currentTime");

    return currentTime >= vnb && currentTime <= vna;
  }

  // Reverse DNS Lookup
 /* Future<Uint8List?> reverseDnsLookup(String det) async {
    try {
      String hexDet = det.replaceAll(':', '');
      String reversedDet = '';

      // Reverse the bytes for DNS query
      for (int i = hexDet.length - 2; i >= 0; i -= 2) {
        reversedDet += '${hexDet.substring(i, i + 2)}.';
      }
      String lookupFqdn = '${reversedDet}drip.example.com';

      print("Performing DNS lookup for: $lookupFqdn");

      // Perform DNS query
      var response = await client.lookup(lookupFqdn);
      if (response.isNotEmpty) {
        print("DNS Lookup Result: ${response.first.address}");
        return Uint8List.fromList(response.first.address.codeUnits);
      }
    } catch (e) {
      print("Error during DNS lookup: $e");
    }
    return null;
  }*/

  // Authenticate DRIP Link
  Future<bool> authenticateDRIPLink(Uint8List dripLink, Uint8List parentSignature, Uint8List parentPublicKey) async {
    try {
      // Ensure the DRIP Link is long enough
      if (dripLink.length < 80) {
        print("Invalid DRIP Link: Too short.");
        return false;
      }

      // Extract VNB and VNA (first 8 bytes)
      int vnb = dripLink.buffer.asByteData().getUint32(0, Endian.little);
      int vna = dripLink.buffer.asByteData().getUint32(4, Endian.little);

      // Validate timestamps
      if (!validateTimestamps(vnb, vna)) {
        print("DRIP Link timestamps are invalid.");
        return false;
      }

      // Extract DET from DRIP Link (last 16 bytes)
      Uint8List det = dripLink.sublist(dripLink.length - 16);

      // Check if DET exists in the cache
      if (detCache.containsKey(det)) {
        print("DET found in cache. Authentication successful.");
        return true;
      }

      // If DET not in cache, perform DNS lookup
      Uint8List? dnsResult = await reverseDnsLookup(det.map((e) => e.toRadixString(16).padLeft(2, '0')).join(':'));
      if (dnsResult == null) {
        print("DNS lookup failed. DET not authenticated.");
        return false;
      }

      // Verify parent signature on the DRIP Link
      bool parentVerified = await verifySignature(
        dripLink.sublist(0, dripLink.length - 64), // Exclude parent signature part
        parentSignature,
        SimplePublicKey(parentPublicKey, type: KeyPairType.ed25519),
      );

      if (!parentVerified) {
        print("Parent signature verification failed.");
        return false;
      }

      // Add DET to cache
      detCache[det.map((e) => e.toRadixString(16).padLeft(2, '0')).join(':')] = dnsResult;
      print("DET authenticated and added to cache.");

      return true;
    } catch (e) {
      print("Error authenticating DRIP Link: $e");
      return false;
    }
  }
}
*/