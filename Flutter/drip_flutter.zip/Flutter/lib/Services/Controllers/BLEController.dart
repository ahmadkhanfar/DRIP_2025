import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../Services/Auth/wrapper_authenticator.dart';
import 'package:get/get.dart';

class ScanController extends GetxController {
  final WrapperAuthenticator _authenticator = WrapperAuthenticator();

  var isScanning = false.obs; // Observable for scanning state
  var authResult = "No wrapper data scanned yet.".obs; // Result of authentication
  var connectionState = "Disconnected".obs; // Connection status

  @override
  void onInit() {
    super.onInit();
    checkPermissions();
    startScan();
  }

  /// Check BLE Permissions
  Future<void> checkPermissions() async {
    if (await Permission.bluetoothScan.request().isGranted &&
        await Permission.bluetoothConnect.request().isGranted &&
        await Permission.locationWhenInUse.request().isGranted) {
      print("All permissions granted.");
    } else {
      print("Permissions denied.");
    }
  }

  /// Start Scanning for BLE Devices
  void startScan() async {
    isScanning.value = true;

    try {
      await FlutterBluePlus.startScan(
        timeout: const Duration(seconds: 15),
        androidScanMode: AndroidScanMode.lowLatency,
      );

      FlutterBluePlus.scanResults.listen((results) async {
        if (results.isEmpty) {
          print("No devices found.");
        } else {
          for (ScanResult result in results) {
            print("Device found: ${result.device.name}");
            print(result.advertisementData);

            if (result.device.name == "UAV_Broadcast") {
              await connectToDevice(result.device);
              break; // Stop after connecting to one device
            }
          }
        }
      }).onDone(() {
        isScanning.value = false;
      });
    } catch (e) {
      authResult.value = "Error starting scan: $e";
      isScanning.value = false;
    }
  }

  /// Connect to a BLE Device
  Future<void> connectToDevice(BluetoothDevice device) async {
    try {
      connectionState.value = "Connecting to ${device.name}...";
      await device.connect(autoConnect: false);
      connectionState.value = "Connected to ${device.name}";

      // Request MTU size
      int mtu = await device.requestMtu(512);
      print("MTU set to $mtu");

      // Discover services
      List<BluetoothService> services = await device.discoverServices();
      for (BluetoothService service in services) {
        print("Service UUID: ${service.uuid}");
        for (BluetoothCharacteristic characteristic in service.characteristics) {
          print("Characteristic UUID: ${characteristic.uuid}");
          if (characteristic.uuid.toString() == "d9b54fc1-2f14-4a47-943c-41a6795d58d9") {
            await sendWriteRequest(characteristic);
          }

        }
      }
    } catch (e) {
      print("Error connecting to device: $e");
      connectionState.value = "Connection failed: $e";
    }
  }

  /// Send Write Request to Request Wrapper Data
  Future<void> sendWriteRequest(BluetoothCharacteristic characteristic) async {
    try {
      await characteristic.write(utf8.encode("REQUEST_WRAPPER"));
      List<int> response = await characteristic.read();
      print("Received Wrapper: ${response.map((e) => e.toRadixString(16).padLeft(2, '0')).join(' ')}");

      // Optionally, authenticate the wrapper
      Uint8List wrapper = Uint8List.fromList(response);
      bool isAuthenticated = await _authenticator.authenticateWrapper(wrapper);
      authResult.value = isAuthenticated
          ? "Wrapper authenticated successfully!"
          : "Wrapper authentication failed!";
    } catch (e) {
      print("Error in write request: $e");
    }
  }


  /// Discover Services and Characteristics
  Future<void> discoverServices(BluetoothDevice device) async {
    List<BluetoothService> services = await device.discoverServices();
    for (BluetoothService service in services) {
      print("Service UUID: ${service.uuid}");
      for (BluetoothCharacteristic characteristic in service.characteristics) {
        print("Characteristic UUID: ${characteristic.uuid}");
        if (characteristic.uuid.toString() == "d9b54fc1-2f14-4a47-943c-41a6795d58d9") {
          await enableNotifications(characteristic);
          break;
        }
      }
    }
  }

  /// Enable Notifications for a Characteristic
  Future<void> enableNotifications(
      BluetoothCharacteristic characteristic) async {
    try {
      await characteristic.setNotifyValue(true);
      characteristic.value.listen((value) async {
        Uint8List wrapper = Uint8List.fromList(value);
        print(
            "Received Wrapper: ${wrapper.map((e) => e.toRadixString(16).padLeft(2, '0')).join(' ')}");

        // Authenticate the Wrapper
        bool isAuthenticated =
        await _authenticator.authenticateWrapper(wrapper);

        authResult.value = isAuthenticated
            ? "Wrapper authenticated successfully!"
            : "Wrapper authentication failed!";
      });
    } catch (e) {
      print("Error enabling notifications: $e");
    }
  }

  /// Disconnect from the Device
  Future<void> disconnectDevice(BluetoothDevice device) async {
    try {
      await device.disconnect();
      connectionState.value = "Disconnected from ${device.name}";
    } catch (e) {
      print("Error disconnecting: $e");
    }
  }

  @override
  void onClose() {
    FlutterBluePlus.stopScan();
    super.onClose();
  }
}
