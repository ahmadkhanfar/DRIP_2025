import 'dart:typed_data';

import 'package:get/get.dart';

class helperController extends GetxController {

  /// Helper to Convert Hex to Bytes
  Uint8List hexToBytes(String hex) {
    hex = hex.replaceAll(' ', ''); // Remove any spaces
    if (hex.length % 2 != 0) {
      throw FormatException("Invalid hex string: length must be even");
    }

    final bytes = <int>[];
    for (int i = 0; i < hex.length; i += 2) {
      final byte = int.tryParse(hex.substring(i, i + 2), radix: 16);
      if (byte == null) {
        throw FormatException("Invalid hex string: contains non-hex characters");
      }
      bytes.add(byte);
    }
    return Uint8List.fromList(bytes);
  }


  /// Helper to Encode Hex
  String hexEncode(Uint8List bytes) => bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();


  String convertToHexList(List<int> manufacturerData) {
    if (manufacturerData.isEmpty) return ""; // Handle empty list case
    return manufacturerData
        .map((byte) => (byte & 0xFF).toRadixString(16).padLeft(2, '0').toUpperCase())
        .join(' ');
  }





}