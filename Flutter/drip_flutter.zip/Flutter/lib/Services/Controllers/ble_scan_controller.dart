import 'dart:isolate';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:dnsolve/dnsolve.dart';
import 'package:drip/Services/Controllers/drip_link_auth_controller.dart';
import 'package:drip/Services/Controllers/open_drone_id_manager.dart';
import 'package:drip/Services/Controllers/wrapper_auth_controller.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:async/async.dart';

import '../../Constants/log_message_entry.dart';
import '../../data/AircraftObject.dart';
import '../../data/LocationData.dart';
import '../check_cache.dart';
import 'helper_controller.dart';
import 'map_controller.dart';
import 'open_drone_id_parser.dart';

enum SAMType {
  None,
  Link,
  Wrapper,
  Manifest, // we will not be using
  Frame; // we will not be using

  // Get the corresponding enum value from an integer ID
  static SAMType? fromId(int id) {
    switch (id) {
      case 0:
        return SAMType.None;
      case 1:
        return SAMType.Link;
      case 2:
        return SAMType.Wrapper;
      case 3:
        return SAMType.Manifest;
      case 4:
        return SAMType.Frame;
      default:
        return null; // Return null for unknown IDs
    }
  }

  // Get the integer ID from the enum value
  int get id {
    switch (this) {
      case SAMType.None: // We can use this as a flag ("SOME IS NOT USING THE DRONE IF DRIP WAS A STANDARD").
        return 0;
      case SAMType.Link:
        return 1;
      case SAMType.Wrapper:
        return 2;
      case SAMType.Manifest:
        return 3;
      case SAMType.Frame:
        return 4;
    }
  }
}

class bleScanController extends GetxController {
  // Create a LogMessageEntry instance
  LogMessageEntry logMessageEntry = LogMessageEntry();

  final Map<String, bool> detAuthenticationCache = {};
  String droneDet= "";
  // Define the 128-bit Service UUID
  static  Guid serviceUuid = Guid("0000fffa-0000-1000-8000-00805f9b34fb"); // OpenDroneId Service UUID

  final Uint8List openDroneIdAdCode = Uint8List.fromList([0x0D]);
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    requestPermissions();


  }
  void startScan() {
    FlutterBluePlus.startScan(continuousUpdates: true).then((_) {
    });
    FlutterBluePlus.scanResults.listen((results) async {
      for (ScanResult result in results) {
          result.advertisementData.serviceData.forEach((uuid, data) async {
            print (Guid(uuid.toString()));
            print(uuid);
            // Parse the message data using OpenDroneIdParser
            Uint8List messageData = Uint8List.fromList(data);
            if(data[0] == openDroneIdAdCode[0]){
              print("Drone found");
              await parseAndLogDroneData(messageData, result);
            }




            /* if (data.isNotEmpty && data[14] == openDroneIdAdCode[0]) {
              print('Open Drone ID AD Code detected: ');
              int messageType = data[15]; // Message type is right after the Op Code
              Uint8List messageData = Uint8List.fromList(data.sublist(16)); // Wrapper starts after the Op Code
              switch (SAMType.fromId(messageType)) {
                case SAMType.Wrapper:
                  print('Wrapper message detected.');
                  parseWrapper(messageData);
                  processWrapper(messageData);
                  break;
                case SAMType.Link:
                  print('DRIP Link message detected.');
                  String hexString = _helper.convertToHexList(messageData);
                  Get.find<dripLinkController>().authenticateDripLink(hexString);
                  break;
                default:
                  print('Unsupported SAM type: $messageType');
                  break;
              }

            }*/



          });


      }
    });
  }


  /*void parseAndLogDroneData(Uint8List messageData) {
    print("Parsing Drone Data...");


    // Pass the message data to the OpenDroneIdParser for parsing
// Pass the message data to the OpenDroneIdParser for parsing

    OpenDroneIdDataManager  idManage = OpenDroneIdDataManager((AircraftObject object) {
      // Your logic here to handle the new aircraft
    });
    var parsedData = OpenDroneIdParser.parseData(messageData, 2, DateTime.now().millisecondsSinceEpoch, logMessageEntry, receiverLocation);
    //var rec = idManage.receiveData(23, "macAddress", 123, 0, parsedData!, logMessageEntry, "BT5");
    Message<Payload> payload = parsedData!;
    print(payload.payload);
    print(payload.header);
    print(messageData);




    // Log the parsed data and process it based on its type
    if (parsedData != null) {
      print("Parsed Drone Data: ${parsedData.payload.toString()}");
      print(parsedData.header);
      if (parsedData.payload is SystemMsg){
        print("system found");
        SystemMsg sys = parsedData.payload as SystemMsg;
        print(sys.latitude);
        print(sys.longitude);
        Get.find<map_controller>().updateDroneLocation(sys.latitude, sys.longitude);
      }
      if(parsedData.payload is Location){
        print("location found");


        Location location = parsedData.payload as Location;
        print(location.latitude);
        Get.find<map_controller>().updateDroneLocation(location.latitude, location.longitude);
      }


    } else {
      print("Failed to parse the received data.");
    }
  }*/

  Future<void> parseAndLogDroneData(Uint8List messageData, ScanResult result ) async {
    print("Parsing Drone Data...");
    OpenDroneIdDataManager manager = OpenDroneIdDataManager();
    manager.receiveDataBluetooth(messageData, result, logMessageEntry, "BT5");
  // var receivedData = manager.receiveData(0, "macAddress", 123, 40, parsedData!, logMessageEntry, "BT5");

  }

  Future _printMessageDetails(Payload payload) async {

    OpenDroneIdDataManager manager =  OpenDroneIdDataManager();// Get your manager instance
    manager.aircraft.values.forEach((aircraft) {
    LocationData? location = aircraft.location.value;
    if (location != null) {
    print('Aircraft ${aircraft.macAddress}: Lat ${location.latitude}, Lon ${location.longitude}');
    }
    });

    /*if (payload is BasicId) {
      print("Basic ID Message:");
      print("ID Type: ${payload.idType}");
      print("UA Type: ${payload.uaType}");
      print("UAS ID: ${String.fromCharCodes(payload.uasId)}");
    } else if (payload is Location) {
      print("Location Message:");
      print("Latitude: ${payload.getLatitude()}");
      print("Longitude: ${payload.getLongitude()}");
      print("Altitude: ${payload.getAltitudeGeodetic()} m");
      print("Horizontal Speed: ${payload.getSpeedHori()} m/s");
      Get.find<map_controller>().Latitude.value  = 42.2917000;
      Get.find<map_controller>().Longitude.value = -85.587200;
      Get.find<map_controller>().updateDroneLocation(42.2917000,-85.587200);



    } else if (payload is SystemMsg) {
      print("System Message:");
      print("Operator Latitude: ${payload.getLatitude()}");
      print("Operator Longitude: ${payload.getLongitude()}");
      print("Altitude: ${payload.getOperatorAltitudeGeo()} m");
    } else if (payload is OperatorID) {
      print("Operator ID Message:");
      print("Operator ID Type: ${payload.operatorIdType}");
      print("Operator ID: ${String.fromCharCodes(payload.operatorId)}");
    } else if (payload is Authentication) {
      print("Authentication Message:");
      print("Auth Type: ${payload.authType}");
      print("Data Page: ${payload.authDataPage}");
    } else if (payload is SelfID) {
      print("Self ID Message:");
      print("Description Type: ${payload.descriptionType}");
      print("Operation Desc: ${String.fromCharCodes(payload.operationDescription)}");
    }*/
  }

  Future<void> requestPermissions() async {
    await [
      Permission.bluetooth,
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.location,
    ].request();
  }






 helperController _helper = new helperController();
 Future<String> authenticateWrapper(String wrapperHex) async {
   Uint8List publicKeyBytes = Uint8List(0) ;
   bool isValid = false;
   bool isLink = false;
   try {
     // Record the start time
     final startTime = DateTime.now();
     final wrapperBytes = Uint8List.fromList(_helper.hexToBytes(wrapperHex));
     final signatureBytes = wrapperBytes.sublist(wrapperBytes.length - 64);
     final messageBytes = wrapperBytes.sublist(0, wrapperBytes.length - 64);
     print ("wrapperBytes");
     print (wrapperBytes);
     print("Message (Hex): ${_helper.hexEncode(Uint8List.fromList(messageBytes))}");
     print("Signature (Hex): ${_helper.hexEncode(Uint8List.fromList(signatureBytes))}");
// Extract DET (16 bytes before the signature, after the evidence)
     final detBytes = messageBytes.sublist(messageBytes.length - 16, messageBytes.length);
     final detHex = _helper.hexEncode(Uint8List.fromList(detBytes));
     print("DET (Hex): $detHex");
     if (detAuthenticationCache.containsKey(detHex)) {
       print("Skipping authentication for already authenticated DET: $detHex");
       return "Already Authenticated";
     }
     final publicKeyHex = await checkCache(detHex);
     print("Fetched Public Key: $publicKeyHex");
     // Convert public key from hex to bytes
     publicKeyBytes = Uint8List.fromList(_helper.hexToBytes(publicKeyHex!));
     final publicKey = SimplePublicKey(publicKeyBytes, type: KeyPairType.ed25519);
     final signature = Signature(signatureBytes, publicKey: publicKey);
     isValid = await Ed25519().verify(Uint8List.fromList(messageBytes), signature: signature);
     if (isValid){
       detAuthenticationCache[detHex] = true;
       droneDet = detHex;

     }else{
       detAuthenticationCache[detHex] = false;
     }
     return isValid ? "Authentication successful: Signature is valid." : "Authentication failed: Signature is invalid.";
   } catch (e) {
     return "Error during authentication: $e";
   }
 }


 Future<String?> checkCache(String detHex) async {
   final startTime = DateTime.now();
   final cache = await PublicKeyCache.loadCache();

   // Check if the DET exists in the cache
   if (cache.containsKey(detHex)) {
     print("Public key found in cache for DET: $detHex");
     final endTime = DateTime.now();
     // Calculate the time taken
     final duration = endTime.difference(startTime).inMilliseconds;

     print("Time it took to hit: $duration");
     return cache[detHex];
   }else{
     final endTime = DateTime.now();
     // Calculate the time taken
     final duration = endTime.difference(startTime).inMilliseconds;
     print("Time it took to miss: $duration");
    await reverseDnsLookup (detHex);
   }
 }




 Future<String?> reverseDnsLookup(String detHex) async {
   try {
     // Record the start time
     final startTime = DateTime.now();
     final detDomain = reverseDet(detHex); // Reverse DET to domain format
     final dnsolve = DNSolve();
     final response = await dnsolve.lookup(
         detDomain,
         dnsSec: false,
         type: RecordType.txt,
         provider: DNSProvider.google
     );

     if (response.answer?.records != null) {
       for (final record in response.answer!.records!) {
         if (record.rType == RecordType.txt && record.data.contains("pubkey=")) {
           final publicKey = record.data.split("pubkey=")[1].trim();
           final endTime = DateTime.now();
           // Calculate the time taken
           final duration = endTime.difference(startTime).inMilliseconds;
           // Add the public key to the cache
           final cache = await PublicKeyCache.loadCache();
           print("DNS RESOLVE time: $duration ms");
           cache[detHex] = publicKey;
           // Save the updated cache
           await PublicKeyCache.saveCache(cache);
           print("Saved in Cache Public Key: $publicKey");
           return publicKey;


         }
       }
     }
     return null;
   } catch (e) {
     return null;
   }
 }



  String reverseDet(String detHex) {
    // Validate that the input string contains only valid hexadecimal characters
    final hexPattern = RegExp(r'^[0-9a-fA-F]+$');
    if (!hexPattern.hasMatch(detHex)) {
      throw FormatException("Invalid DET format: $detHex");
    }

    // Split the DET into nibbles (single hex characters)
    final nibbles = detHex.split('');

    // Reverse the nibble order and join with dots
    final reversedNibbles = nibbles.reversed.join('.').toLowerCase();

    // Append the domain
    return "$reversedNibbles.vertexpal.com.";
  }









  /// Parses the dynamic wrapper and extracts its components.
 Map<String, dynamic> parseWrapper(Uint8List wrapper) {
   //testStaticLocation();
   final ByteData byteData = ByteData.sublistView(wrapper);

   // Extract fixed components
   int vnb = byteData.getUint32(0, Endian.little);
   int vna = byteData.getUint32(4, Endian.little);

   // Calculate payload size
   int payloadStartIndex = 8; // VNB (4 bytes) + VNA (4 bytes)
   int detStartIndex = wrapper.length - 80; // DET (16 bytes) + Signature (64 bytes)
   int payloadEndIndex = detStartIndex; // Payload ends where DET starts
   int payloadSize = payloadEndIndex - payloadStartIndex;

   // Extract payload
   Uint8List payload = wrapper.sublist(payloadStartIndex, payloadEndIndex);

   // Extract DET
   Uint8List det = wrapper.sublist(detStartIndex, detStartIndex + 16);

   // Extract Signature
   Uint8List signature = wrapper.sublist(detStartIndex + 16, wrapper.length);

   // Parse payload if necessary
   final parsedPayload = parseF3411Message(payload);

   // Return parsed components
   return {
     "VNB": vnb,
     "VNA": vna,
     "payload": parsedPayload,
     "DET": det,
     "signature": signature,
   };
 }

 /// Parses the F3411 payload and extracts geolocation and other details.
 Map<String, dynamic> parseF3411Message(Uint8List payload) {
   final ByteData byteData = ByteData.sublistView(payload);

   // Extract fields from the payload
   double latitudeRaw = byteData.getFloat32(0, Endian.little);
   double longitudeRaw = byteData.getFloat32(4, Endian.little);
   // to keep data live

   Get.find<map_controller>().Latitude.value  = latitudeRaw;
   Get.find<map_controller>().Longitude.value = longitudeRaw;
   int altitude = byteData.getUint16(8, Endian.little);
   int velocity = byteData.getUint16(10, Endian.little);

   print("Raw Payload Bytes: ${payload.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ')}");

   // Apply dynamic scaling

   print("Location");


   Get.find<map_controller>().updateDroneLocation(latitudeRaw, longitudeRaw);

   print(latitudeRaw);
   print(longitudeRaw);
   print(velocity);


   return {
     "latitude": latitudeRaw,
     "longitude": longitudeRaw,
     "altitude": altitude,
     "velocity": velocity,
   };

 }



 void processWrapper(Uint8List wrapper) async {

     String hexString = _helper.convertToHexList(wrapper);
     await authenticateWrapper(hexString).then((authResult) {
        print("Authentication Result: $authResult");
      });
 }





}
