import 'dart:core';
import 'dart:typed_data';
import 'package:drip/Services/Controllers/map_controller.dart';
import 'package:drip/Services/Controllers/open_drone_id_parser.dart';
import 'package:drip/Services/Controllers/open_drone_id_parser.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'dart:convert';
import 'dart:async';

import '../../Constants/Constants.dart';
import '../../Constants/log_message_entry.dart';
import '../../data/AircraftObject.dart';
import '../../data/AuthenticationData.dart';
import '../../data/Connection.dart';
import '../../data/Identification.dart';
import '../../data/LocationData.dart';
import '../../data/OperatorID.dart';
import '../../data/SelfIdData.dart';
import '../../data/SystemData.dart';
import 'open_drone_id_parser.dart';

// Define AircraftObject class with necessary fields (similar to Java)


/*class AircraftObject {
  final String macAddress;
  int rssi;
  int timestamp;
  String transportType;
  Identification identification1;
  Identification identification2;
  LocationData location;
   AuthenticationData authentication;
   SelfIdData selfid;
   SystemData system;
   OperatorIdData operatorid;

  AircraftObject(this.macAddress)
      : rssi = 0,
        timestamp = 0,
        transportType = '',
        identification1 = Identification(),
        location = LocationData(),
        authentication = AuthenticationData(),
        selfid = SelfIdData(),
        system = SystemData(),
        identification2 = Identification(),
        operatorid = OperatorIdData();

}*/

Location receiverLocation = Location();  // San Francisco example
typedef AircraftCallback = void Function(AircraftObject object);

class OpenDroneIdDataManager {
  final Map<int, AircraftObject> aircraft = {}; // Store AircraftObjects in a map with macAddress as the key

  final StreamController<AircraftObject> onNewAircraftStream = StreamController.broadcast();

    // Using the function type for callback
  OpenDroneIdDataManager();// Callback function type

  void receiveDataBluetooth(Uint8List data, ScanResult result, LogMessageEntry logMessageEntry, String transportType) {
    // Get the MAC address from the device
    String macAddress = result.device.id.toString();
    String macAddressCleaned = macAddress.replaceAll(":", ""); // Remove colons
    int macAddressLong = int.parse(macAddressCleaned, radix: 16);  // Convert to long
    print(data);
    // Parse the data using the OpenDroneIdParser.parseData method
    final timestamp = result.timeStamp is int
        ? result.timeStamp as int
        : DateTime.now().millisecondsSinceEpoch; // Use current time as fallback// You can update based on actual timestamp available
    var message = OpenDroneIdParser.parseData(data, 2, timestamp, logMessageEntry, receiverLocation);

    // Check if the message was successfully parsed
    if (message == null) {
      print("Message is null");
      return;
    }

    // Process the data using receiveData
    receiveData(timestamp, macAddress, macAddressLong, result.rssi, message, logMessageEntry, transportType);
  }


  void receiveData(
      int timeNano,
      String macAddress,
      int macAddressLong,
      int rssi,
      Message message,
      LogMessageEntry logMessageEntry,
      String transportType) {

    // Handle connection
    bool newAircraft = false;
    AircraftObject? ac = aircraft[macAddressLong];
    if (ac == null) {
      ac = createNewAircraft(macAddress, macAddressLong);
      newAircraft = true;
    }

    // Get current time and calculate delta from last seen
    int currentTime = DateTime.now().millisecondsSinceEpoch;

    ac.getConnection!.msgDelta.value = currentTime - ac.getConnection!.lastSeen.value;
    ac.getConnection!.lastSeen.value = currentTime;
    ac.getConnection!.rssi.value = rssi;
    ac.getConnection!.transportType.value = transportType;
    ac.getConnection!.setTimestamp(timeNano);
    ac.getConnection!.setMsgVersion(message.header.version);
    ac.connection.value = ac.getConnection;

      if (newAircraft) {
        aircraft[macAddressLong] = ac;
        onNewAircraftStream.add(ac); // Notify the UI with the new AircraftObject
      }


    if (message.header.type == MessageType.messagePack) {
      handleMessagePack(ac, message, timeNano, logMessageEntry, message.msgCounter);
    } else {
      handleMessages(ac, message);
    }

    // Restore the msgVersion in case the messages embedded in the pack had a different value
    logMessageEntry.setMsgVersion(ac.connection.value!.getMsgVersion());
  }


  void handleMessages(AircraftObject ac, Message message) {
    // Handle message based on type
    switch (message.header.type) {
      case MessageType.basicId:
          handleBasicId(ac, message.payload);
        break;
      case MessageType.location:
        handleLocation(ac, message.payload);
        break;
      case MessageType.auth:
        handleAuthentication(ac, message.payload);
        break;
      case MessageType.selfId:
        handleSelfId(ac, message.payload);
        break;
      case MessageType.system:
        handleSystem(ac, message.payload);
        break;
      case MessageType.operatorId:
        handleOperatorId(ac, message.payload);
      default:
        print("Unsupported message type: ${message.header.type}");
        break;
    }
  }

  AircraftObject createNewAircraft(String macAddress, int macAddressLong) {
    // Create a new AircraftObject
    AircraftObject ac = AircraftObject(macAddressLong);

    // Create and initialize the connection object
    Connection connection = Connection();
    connection.firstSeen.value = DateTime.now().millisecondsSinceEpoch; // Equivalent to System.currentTimeMillis()
    connection.macAddress.value = macAddress;
    ac.connection.value = connection;

    // Initialize all the required fields with new objects
    ac.identification1.value = Identification();
    ac.identification2.value = Identification();
    ac.location.value = LocationData();
    ac.authentication.value = AuthenticationData();
    ac.selfid.value  = SelfIdData();
    ac.system.value = SystemData();
    ac.operatorid.value = OperatorIdData();

    return ac;  // Return the created AircraftObject
  }


  void handleBasicId(AircraftObject ac, Payload message) {
    BasicId raw = message as BasicId;
    Identification data = Identification();

    //data.msgCounter.value = message.msgCounter;
    //data.timestamp.value = message.timestamp;

    data.setUaType(raw.uaType);
    data.setIdType(raw.idType);
    data.setUasId(raw.uasId);

    // This implementation can receive up to two different types of Basic ID messages
    // Find a free slot to store the current message or overwrite old data of the same type
    Identification? id1 = ac.identification1.value;
    Identification? id2 = ac.identification2.value;

    if (id1 == null || id2 == null) return; // If both are null, we skip updating

    IdTypeEnum type1 = id1.idType;
    IdTypeEnum type2 = id2.idType;

    if (type1 == IdTypeEnum.None || type1 == data.idType) {
      ac.identification1.value = data;

    } else {
      if (type2 == IdTypeEnum.None || type2 == data.idType) {
        ac.identification2.value = data;
      } else {
        print('Discarded Basic ID message of type: ${data.idType}. '
            'Already have ${type1.toString()} and ${type2.toString()}');
      }
    }


    print(ac.identification1.value);
    print(ac.identification2.value);
    print(ac.identification1.value!.uasId);
    print(data.getUasIdAsString());
    print("UAS ID");

  }


  void handleLocation(AircraftObject ac, Payload message) {
    Location raw = message as Location;
    LocationData data = LocationData();

    // Set the message counter and timestamp
    //data.setMsgCounter(message.msgCounter);
    //data.setTimestamp(message.timestamp);

    // Set the location-specific fields
    data.setStatus(raw.status);
    data.setHeightType(raw.heightType);
    data.setDirection(raw.getDirection()); // Assuming currentDirection is a getter
    data.setSpeedHorizontal(raw.getSpeedHori());
    data.setSpeedVertical(raw.getSpeedVert());
    data.setLatitude(raw.getLatitude());
    data.setLongitude(raw.getLongitude());
    data.setAltitudePressure(raw.getAltitudePressure());
    data.setAltitudeGeodetic(raw.getAltitudeGeodetic());
    data..setHeight(raw.getHeight());
    data.setHorizontalAccuracy(raw.horizontalAccuracy);
    data.setVerticalAccuracy(raw.verticalAccuracy);
    data.setBaroAccuracy(raw.baroAccuracy);
    data.setSpeedAccuracy(raw.speedAccuracy);
    data.setTimestamp(raw.timestamp);
    data.setTimeAccuracy(raw.getTimeAccuracy());
    data.setDistance(raw.distance);
    // Set the location data in the Aircraft object

    ac.updateLocation(raw.getLatitude(), raw.getLongitude());  // Update the location
    ac.location.value = data;
  }


  void handleAuthentication(AircraftObject ac, Payload message) {
    // Handle Authentication Message
    Authentication raw = message as Authentication;
    AuthenticationData data = AuthenticationData();

    //data.setMsgCounter(message.msgCounter);
    //data.setTimestamp(message.timestamp);

    data.setAuthType(raw.authType);
    data.setAuthDataPage(raw.authDataPage);

    if (raw.authDataPage == 0) {
      data.setAuthLastPageIndex(raw.authLastPageIndex);
      data.setAuthLength(raw.authLength);
      data.setAuthTimestamp(raw.authTimestamp);
    }

    data.setAuthData(raw.authData);
    ac.combineAuthentication(data);

    print(ac.location.value);
  }

  void handleSelfId(AircraftObject ac, Payload message) {
    // Handle SelfID Message

    SelfID raw = message as SelfID;
    SelfIdData data = SelfIdData();

    // Set message counter and timestamp
   // data.setMsgCounter(message.msgCounter);
   // data.setTimestamp(message.timestamp);

    // Set description type and operation description
    data.setDescriptionType(raw.descriptionType);
    data.setOperationDescription(raw.operationDescription);

    // Set the self-id data
    ac.selfid.value = data;
  }

  void handleSystem(AircraftObject ac, Payload message) {
    // Handle System Message

    SystemMsg raw = message as SystemMsg;
    SystemData data = SystemData();

    // Set message counter and timestamp
    //data.setMsgCounter(message.msgCounter);
   // data.setTimestamp(message.timestamp);

    // Set operator location type and classification type
    data.setOperatorLocationType(raw.operatorLocationType);
    data.setClassificationType(raw.classificationType);

    // Set operator latitude and longitude
    data.setOperatorLatitude(raw.getLatitude());
    data.setOperatorLongitude(raw.getLongitude());

    print(raw.getLatitude());
    print(raw.getLongitude());
    Get.find<map_controller>().Latitude.value  = data.operatorLatitude.value;
    Get.find<map_controller>().Longitude.value = data.operatorLongitude.value;
    Get.find<map_controller>().updateDroneLocation( data.operatorLatitude.value,data.operatorLongitude.value);
    print("System");

    // Set area details
    data.setAreaCount(raw.areaCount);
    data.setAreaRadius(raw.getAreaRadius());
    data.setAreaCeiling(raw.getAreaCeiling());
    data.setAreaFloor(raw.getOperatorAltitudeGeo());

    // Set category and class values
    data.setCategory(raw.category);
    data.setClassValue(raw.classValue);

    // Set operator altitude and system timestamp
    data.setOperatorAltitudeGeo(raw.getOperatorAltitudeGeo());
    data.setSystemTimestamp(raw.systemTimestamp);

    // Update the system data in the aircraft object
    ac.system.value = data;
  }

  void handleOperatorId(AircraftObject ac, Payload message) {
    // Handle OperatorID Message

    OperatorID raw = message as OperatorID;
    OperatorIdData data = OperatorIdData();

    // Set message counter and timestamp
   // data.setMsgCounter(message.msgCounter);
    //data.setTimestamp(message.timestamp);

    // Set operator ID type and operator ID
    data.setOperatorIdType(raw.operatorIdType);
    data.setOperatorId(raw.operatorId);

    // Update the operator ID in the aircraft object
    ac.operatorid.value = data;
  }

  void handleMessagePack(
      AircraftObject ac,
      Message message,
      int timestamp,
      LogMessageEntry logMessageEntry,
      int msgCounter,
      ) {
    final raw = message.payload as MessagePack;
    if (raw == null) return;

    if (raw.messageSize != Constants.MAX_MESSAGE_SIZE ||
        raw.messagesInPack <= 0 ||
        raw.messagesInPack > Constants.MAX_MESSAGES_IN_PACK) {
      return;
    }

    for (int i = 0; i < raw.messagesInPack; i++) {
      final offset = i * raw.messageSize;
      final data = Uint8List.sublistView(
        raw.messages,
        offset.toInt(),
        offset.toInt() + raw.messageSize,
      );
      print("data after offset");
      print(data);

      final subMessage = OpenDroneIdParser.parseMessage(
        data,
        0,
        timestamp,
        logMessageEntry,
        receiverLocation,
        msgCounter,
      );

      if (subMessage == null) return;

      handleMessages(ac, subMessage);
    }
  }


// Add any additional methods as needed for your application
}

