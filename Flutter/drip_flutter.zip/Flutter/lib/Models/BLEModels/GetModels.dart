import 'package:get/get.dart';

class GeoModels{
  String Det;
  RxDouble lat;
  RxDouble long;
  double velocity;
  GeoModels({
    required this.Det,
    required this.lat,
    required this.long,
    required this.velocity
});
}