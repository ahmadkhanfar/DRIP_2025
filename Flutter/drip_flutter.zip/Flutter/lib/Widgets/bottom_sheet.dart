import 'package:drip/Services/Controllers/ble_scan_controller.dart';
import 'package:drip/Services/Controllers/drip_link_auth_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';

import '../Services/Controllers/map_controller.dart';

void showDroneInfoBottomSheet(BuildContext context) {
  final mapController = Get.find<map_controller>();

  showModalBottomSheet(
    context: context,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (BuildContext context) {
      // Retrieve the current drone ID

      // Retrieve the parent DET and authentication status from the cache
      Map<String, dynamic>? dripLinkDetails = Get.find<dripLinkController>().dripLinkCache[Get.find<bleScanController>().droneDet];
      String parentDet = dripLinkDetails?["parentDet"] ?? "Unknown";
      bool isAuthenticated = dripLinkDetails?["isAuthenticated"] ?? false;
      return Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Drone Information",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),

            _infoRow("Drone ID: ", Get.find<bleScanController>().droneDet),
            _infoRow("Parent DET: ", parentDet),
            _infoRow("is Authenticated?: ", isAuthenticated.toString()),
            Obx(() => _infoRow("Latitude", mapController.Latitude.value.toStringAsFixed(6))),
            Obx(() => _infoRow("Longitude", mapController.Longitude.value.toStringAsFixed(6))),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the bottom sheet
              },
              child: Text("Close"),
            ),
          ],
        ),
      );
    },
  );
}

Widget _infoRow(String label, String value) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 4.0),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontWeight: FontWeight.w500)),
        Text(value, style: TextStyle(color: Colors.grey[700])),
      ],
    ),
  );
}
