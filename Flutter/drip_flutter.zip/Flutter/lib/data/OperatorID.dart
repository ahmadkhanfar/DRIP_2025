import 'package:drip/data/MessageData.dart';
import 'package:get/get.dart';
import '../Constants/Constants.dart';


class OperatorIdData extends MessageData {
  var operatorIdType = 0.obs;
  var operatorId = RxList<int>();

  OperatorIdData() {
    operatorIdType.value = 0;
    operatorId.value = [];
  }

  void setOperatorIdType(int value) {
    if (value < 0) value = 0;
    if (value > 255) value = 255;
    operatorIdType.value = value;
  }

  int getOperatorIdType() => operatorIdType.value;

  void setOperatorId(List<int> value) {
    if (value.length <= Constants.MAX_ID_BYTE_SIZE) {
      operatorId.value = value;
    }
  }

  List<int> getOperatorId() => operatorId.value;

  String getOperatorIdAsString() {
    if (operatorId.isNotEmpty) {
      for (var c in operatorId) {
        if ((c <= 31 || c >= 127) && c != 0) {
          return "Invalid String";
        }
      }
      return String.fromCharCodes(operatorId);
    }
    return "";
  }
}
