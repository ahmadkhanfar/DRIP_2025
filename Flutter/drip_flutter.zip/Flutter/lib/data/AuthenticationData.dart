import 'dart:typed_data';
import 'package:drip/Constants/Constants.dart';
import 'package:drip/data/MessageData.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart'; // For timestamp formatting

// Enum for Auth Type
enum AuthTypeEnum {
  None,
  UAS_ID_Signature,
  Operator_ID_Signature,
  Message_Set_Signature,
  Network_Remote_ID,
  Specific_Authentication,
  Private_Use_0xA,
  Private_Use_0xB,
  Private_Use_0xC,
  Private_Use_0xD,
  Private_Use_0xE,
  Private_Use_0xF
}

class AuthenticationData extends MessageData {
  // Reactive Variables
  final Rx<AuthTypeEnum> authType = AuthTypeEnum.None.obs;
  final RxInt authDataPage = 0.obs;
  final RxInt authLastPageIndex = 0.obs;
  final RxInt authLength = 0.obs;
  final RxInt authTimestamp = 0.obs;
  final Rx<Uint8List> authData = Uint8List(0).obs;

  // Constructor
  AuthenticationData();

  // Convert integer to AuthTypeEnum
  void setAuthType(int value) {
    switch (value) {
      case 1:
        authType.value = AuthTypeEnum.UAS_ID_Signature;
        break;
      case 2:
        authType.value = AuthTypeEnum.Operator_ID_Signature;
        break;
      case 3:
        authType.value = AuthTypeEnum.Message_Set_Signature;
        break;
      case 4:
        authType.value = AuthTypeEnum.Network_Remote_ID;
        break;
      case 5:
        authType.value = AuthTypeEnum.Specific_Authentication;
        break;
      case 0xA:
        authType.value = AuthTypeEnum.Private_Use_0xA;
        break;
      case 0xB:
        authType.value = AuthTypeEnum.Private_Use_0xB;
        break;
      case 0xC:
        authType.value = AuthTypeEnum.Private_Use_0xC;
        break;
      case 0xD:
        authType.value = AuthTypeEnum.Private_Use_0xD;
        break;
      case 0xE:
        authType.value = AuthTypeEnum.Private_Use_0xE;
        break;
      case 0xF:
        authType.value = AuthTypeEnum.Private_Use_0xF;
        break;
      default:
        authType.value = AuthTypeEnum.None;
    }
  }

  // **Getters (Now Returning `int` Instead of String Where Applicable)**

  /// Returns the **authentication data page** as an `int`
  int get getAuthDataPage => authDataPage.value;

  /// Returns the **last page index** as an `int`
  int get getAuthLastPageIndex => authLastPageIndex.value;

  /// Returns the **length of authentication data** as an `int`
  int get getAuthLength => authLength.value;

  /// Returns the **timestamp of authentication** as an `int`
  int get getAuthTimestamp => authTimestamp.value;

  /// Returns the **authentication data in bytes**
  Uint8List get getAuthData => authData.value;

  // **Formatted Outputs (As String)**

  /// Returns the **authentication last page index** as a formatted string
  String getAuthLastPageIndexAsString() {
    return "$getAuthLastPageIndex pages";
  }

  /// Returns the **authentication data length** as a formatted string
  String getAuthLengthAsString() {
    return "$getAuthLength bytes";
  }

  /// Returns the **authentication timestamp** as a formatted date string
  String getAuthTimestampAsString() {
    if (getAuthTimestamp == 0) {
      return "Unknown";
    }
    DateTime dateTime =
    DateTime.fromMillisecondsSinceEpoch((1546300800 + getAuthTimestamp) * 1000);
    return DateFormat('yyyy-MM-dd HH:mm:ss').format(dateTime);
  }

  /// Returns **authentication data as a hex string**
  String getAuthenticationDataAsString() {
    return getAuthData.map((byte) => byte.toRadixString(16).padLeft(2, '0')).join(' ').toUpperCase();
  }

  // **Setters with Validation**
  void setAuthDataPage(int value) {
    authDataPage.value = value.clamp(0, Constants.MAX_AUTH_DATA_PAGES - 1);
  }

  void setAuthLastPageIndex(int value) {
    authLastPageIndex.value = value.clamp(0, Constants.MAX_AUTH_DATA_PAGES - 1);
  }

  void setAuthLength(int value) {
    authLength.value = value.clamp(0, Constants.MAX_AUTH_DATA);
  }

  void setAuthTimestamp(int value) {
    authTimestamp.value = value;
  }

  void setAuthData(Uint8List value) {
    authData.value = value;
  }
}


