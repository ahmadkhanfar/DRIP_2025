import 'dart:typed_data';
import 'package:get/get.dart';
import '../Constants/Constants.dart';
import 'AuthenticationData.dart';
import 'Connection.dart';
import 'Identification.dart';
import 'LocationData.dart';
import 'OperatorID.dart';
import 'SelfIdData.dart';
import 'SystemData.dart';

class AircraftObject {
   Rx<Connection?> connection = Rx<Connection?>(null);
   Rxn<Identification> identification1 = Rxn<Identification>();
   Rxn<Identification> identification2 = Rxn<Identification>();
   Rxn<Identification> id1Shadow = Rxn<Identification>();
   Rxn<Identification> id2Shadow = Rxn<Identification>();
   Rx<LocationData?> location = Rx<LocationData?>(null);
   Rx<AuthenticationData?> authentication = Rx<AuthenticationData?>(null);
   Rx<SelfIdData?> selfid = Rx<SelfIdData?>(null);
   Rx<SystemData?> system = Rx<SystemData?>(null);
   Rx<OperatorIdData?> operatorid = Rx<OperatorIdData?>(null);

  final int macAddress;

  AircraftObject(this.macAddress);

  int getMacAddress() => macAddress;
  Connection? get getConnection => connection.value;
  Identification? get getIdentification1 => identification1.value;
  Identification? get getIdentification2 => identification2.value;
  LocationData? get getLocation => location.value;
  AuthenticationData? get getAuthentication => authentication.value;
  SelfIdData? get getSelfID => selfid.value;
  SystemData? get getSystem => system.value;
  OperatorIdData? get getOperatorID => operatorid.value;


   // Method to update location directly
   void updateLocation(double latitude, double longitude) {
     location.value?.latitude.value = latitude;
     location.value?.longitude.value = longitude;
   }

  // Save fields from the first authentication page
  int _authLastPageIndexSave = 0;
  int _authLengthSave = 0;
  int _authTimestampSave = 0;

  // Combine authentication data pages into one buffer
  final Uint8List authDataCombined = Uint8List(Constants.MAX_AUTH_DATA);

  AuthenticationData combineAuthentication(AuthenticationData newData) {
    AuthenticationData? currData = authentication.value ?? AuthenticationData();

    currData.msgCounter = newData.msgCounter;
    currData.timestamp = newData.authTimestamp;
    currData.msgVersion = newData.msgVersion;

    int offset = 0;
    int amount = Constants.MAX_AUTH_PAGE_ZERO_SIZE;
    if (newData.authDataPage == 0) {
      _authLastPageIndexSave = newData.getAuthLastPageIndex;
      _authLengthSave = newData.getAuthLength;
      _authTimestampSave = newData.getAuthTimestamp;
    } else {
      offset = Constants.MAX_AUTH_PAGE_ZERO_SIZE + (newData.getAuthDataPage - 1) * Constants.MAX_AUTH_PAGE_NON_ZERO_SIZE;
      amount = Constants.MAX_AUTH_PAGE_NON_ZERO_SIZE;
    }

    authDataCombined.setRange(
      offset,
      offset + amount,
      newData.authData.value.sublist(0, amount),
    );

    currData.authType.value= newData.authType.value;
    currData.authLastPageIndex.value = _authLastPageIndexSave;
    currData.authLength.value  = _authLengthSave;
    currData.authTimestamp.value = _authTimestampSave;
    currData.authData.value = authDataCombined;

    authentication.value = currData;
    return currData;
  }

  int idToShow = 0;

  /// **Update the shadow Basic ID every 3 seconds**
  void updateShadowBasicId() {
    switch (idToShow) {
      case 0:
        id1Shadow.value = identification1.value;
        idToShow++;
        break;
      case 3:
        if (identification2.value != null &&
            identification2.value!.idType != IdTypeEnum.None) {
          id2Shadow.value = identification2.value;
        }
        idToShow++;
        break;
      case 6:
        idToShow = 0;
        break;
      default:
        idToShow++;
    }
  }

  @override
  String toString() {
    return "AircraftObject{macAddress=$macAddress, identification1=$identification1, identification2=$identification2}";
  }
}


