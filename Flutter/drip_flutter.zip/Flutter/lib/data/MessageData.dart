import 'dart:typed_data';
import 'package:get/get.dart';

import '../Constants/Constants.dart';

class MessageData {
  RxInt msgCounter = 0.obs;
  RxInt msgVersion = 0.obs;
  RxInt timestamp = 0.obs;

  MessageData();

  MessageData.fromBytes(Uint8List bytes) {
    ByteData byteData = ByteData.sublistView(bytes);
    msgCounter.value = byteData.getUint8(0);
    msgVersion.value = byteData.getUint8(1);
    timestamp.value = byteData.getUint32(2, Endian.little);
  }

  void setMsgCounter(int value) => msgCounter.value = value;
  int getMsgCounter() => msgCounter.value;
  String getMsgCounterAsString() => msgCounter.value.toString().padLeft(3, '0');

  void setTimestamp(int value) => timestamp.value = value;
  int getTimestamp() => timestamp.value;
  String getTimestampAsString() {
    final int msSinceEvent = DateTime.now().millisecondsSinceEpoch - timestamp.value;
    final DateTime actualTime = DateTime.fromMillisecondsSinceEpoch(msSinceEvent);
    return actualTime.toString();
  }

  void setMsgVersion(int value) => msgVersion.value = value;
  int getMsgVersion() => msgVersion.value;
  String getMsgVersionAsString() => "v.${msgVersion.value}";
  bool msgVersionUnsupported() => msgVersion.value > Constants.MAX_MSG_VERSION;
}
