import 'package:drip/data/MessageData.dart';
import 'package:get/get.dart';
import 'dart:typed_data';

enum StatusEnum {
  Undeclared,
  Ground,
  Airborne,
  Emergency,
  Remote_ID_System_Failure;

  static StatusEnum fromInt(int value) {
    return StatusEnum.values[value.clamp(0, StatusEnum.values.length - 1)];
  }
}

enum HeightTypeEnum {
  Takeoff,
  Ground;

  static HeightTypeEnum fromInt(int value) {
    return value == 1 ? HeightTypeEnum.Ground : HeightTypeEnum.Takeoff;
  }
}

enum HorizontalAccuracyEnum {
  Unknown,
  kilometers_18_52,
  kilometers_7_408,
  kilometers_3_704,
  kilometers_1_852,
  meters_926,
  meters_555_6,
  meters_185_2,
  meters_92_6,
  meters_30,
  meters_10,
  meters_3,
  meters_1;

  static HorizontalAccuracyEnum fromInt(int value) {
    return HorizontalAccuracyEnum.values[value.clamp(0, HorizontalAccuracyEnum.values.length - 1)];
  }
}

enum VerticalAccuracyEnum {
  Unknown,
  meters_150,
  meters_45,
  meters_25,
  meters_10,
  meters_3,
  meters_1;

  static VerticalAccuracyEnum fromInt(int value) {
    return VerticalAccuracyEnum.values[value.clamp(0, VerticalAccuracyEnum.values.length - 1)];
  }
}

enum SpeedAccuracyEnum {
  Unknown,
  meter_per_second_10,
  meter_per_second_3,
  meter_per_second_1,
  meter_per_second_0_3;

  static SpeedAccuracyEnum fromInt(int value) {
    return SpeedAccuracyEnum.values[value.clamp(0, SpeedAccuracyEnum.values.length - 1)];
  }
}


class LocationData extends MessageData {
  Rx<StatusEnum> status = StatusEnum.Undeclared.obs;
  Rx<HeightTypeEnum> heightType = HeightTypeEnum.Takeoff.obs;
  RxDouble direction = 361.0.obs;
  RxDouble speedHorizontal = 255.0.obs;
  RxDouble speedVertical = 63.0.obs;
  RxDouble latitude = 0.0.obs;
  RxDouble longitude = 0.0.obs;
  RxDouble altitudePressure = (-1000.0).obs;
  RxDouble altitudeGeodetic = (-1000.0).obs;
  RxDouble height = (-1000.0).obs;
  Rx<HorizontalAccuracyEnum> horizontalAccuracy = HorizontalAccuracyEnum.Unknown.obs;
  Rx<VerticalAccuracyEnum> verticalAccuracy = VerticalAccuracyEnum.Unknown.obs;
  Rx<VerticalAccuracyEnum> baroAccuracy = VerticalAccuracyEnum.Unknown.obs;
  Rx<SpeedAccuracyEnum> speedAccuracy = SpeedAccuracyEnum.Unknown.obs;
  RxDouble locationTimestamp = 0xFFFF.toDouble().obs;
  RxDouble timeAccuracy = 0.0.obs;
  RxDouble distance = 0.0.obs;

  LocationData();

  /// **Factory method to create `LocationData` object from bytes**
  factory LocationData.fromBytes(Uint8List data) {
    ByteData byteData = ByteData.sublistView(data);

    return LocationData()
      ..status.value = StatusEnum.fromInt(byteData.getUint8(0))
      ..heightType.value = HeightTypeEnum.fromInt(byteData.getUint8(1))
      ..direction.value = byteData.getUint16(2, Endian.little).toDouble()
      ..speedHorizontal.value = byteData.getUint16(4, Endian.little).toDouble()
      ..speedVertical.value = byteData.getInt16(6, Endian.little).toDouble()
      ..latitude.value = byteData.getFloat32(8, Endian.little)
      ..longitude.value = byteData.getFloat32(12, Endian.little)
      ..altitudePressure.value = byteData.getFloat32(16, Endian.little)
      ..altitudeGeodetic.value = byteData.getFloat32(20, Endian.little)
      ..height.value = byteData.getFloat32(24, Endian.little)
      ..horizontalAccuracy.value = HorizontalAccuracyEnum.fromInt(byteData.getUint8(28))
      ..verticalAccuracy.value = VerticalAccuracyEnum.fromInt(byteData.getUint8(29))
      ..baroAccuracy.value = VerticalAccuracyEnum.fromInt(byteData.getUint8(30))
      ..speedAccuracy.value = SpeedAccuracyEnum.fromInt(byteData.getUint8(31))
      ..locationTimestamp.value = byteData.getUint32(32, Endian.little).toDouble()
      ..timeAccuracy.value = byteData.getFloat32(36, Endian.little)
      ..distance.value = byteData.getFloat32(40, Endian.little);
  }

  /// **Convert to JSON**
  Map<String, dynamic> toJson() {
    return {
      "status": status.value.index,
      "heightType": heightType.value.index,
      "direction": direction.value,
      "speedHorizontal": speedHorizontal.value,
      "speedVertical": speedVertical.value,
      "latitude": latitude.value,
      "longitude": longitude.value,
      "altitudePressure": altitudePressure.value,
      "altitudeGeodetic": altitudeGeodetic.value,
      "height": height.value,
      "horizontalAccuracy": horizontalAccuracy.value.index,
      "verticalAccuracy": verticalAccuracy.value.index,
      "baroAccuracy": baroAccuracy.value.index,
      "speedAccuracy": speedAccuracy.value.index,
      "locationTimestamp": locationTimestamp.value,
      "timeAccuracy": timeAccuracy.value,
      "distance": distance.value,
    };
  }


  // Getter and setter for Status
  StatusEnum getStatus() => status.value;

  void setStatus(int statusCode) {
    switch (statusCode) {
      case 1:
        status.value = StatusEnum.Ground;
        break;
      case 2:
        status.value = StatusEnum.Airborne;
        break;
      case 3:
        status.value = StatusEnum.Emergency;
        break;
      case 4:
        status.value = StatusEnum.Remote_ID_System_Failure;
        break;
      default:
        status.value = StatusEnum.Undeclared;
        break;
    }
  }


  void setHorizontalAccuracy(int accuracy) {
    switch (accuracy) {
      case 1:
        this.horizontalAccuracy.value = HorizontalAccuracyEnum.kilometers_18_52;
        break;
      case 2:
        this.horizontalAccuracy.value  = HorizontalAccuracyEnum.kilometers_7_408;
        break;
      case 3:
        this.horizontalAccuracy.value  = HorizontalAccuracyEnum.kilometers_3_704;
        break;
      case 4:
        this.horizontalAccuracy.value  = HorizontalAccuracyEnum.kilometers_1_852;
        break;
      case 5:
        this.horizontalAccuracy.value  = HorizontalAccuracyEnum.meters_926;
        break;
      case 6:
        this.horizontalAccuracy.value  = HorizontalAccuracyEnum.meters_555_6;
        break;
      case 7:
        this.horizontalAccuracy.value  = HorizontalAccuracyEnum.meters_185_2;
        break;
      case 8:
        this.horizontalAccuracy.value  = HorizontalAccuracyEnum.meters_92_6;
        break;
      case 9:
        this.horizontalAccuracy.value  = HorizontalAccuracyEnum.meters_30;
        break;
      case 10:
        this.horizontalAccuracy.value  = HorizontalAccuracyEnum.meters_10;
        break;
      case 11:
        this.horizontalAccuracy.value  = HorizontalAccuracyEnum.meters_3;
        break;
      case 12:
        this.horizontalAccuracy.value  = HorizontalAccuracyEnum.meters_1;
        break;
      default:
        this.horizontalAccuracy.value  = HorizontalAccuracyEnum.Unknown;
        break;
    }
  }

  // Convert integer to VerticalAccuracyEnum
  VerticalAccuracyEnum intToVerticalAccuracy(int accuracy) {
    switch (accuracy) {
      case 1:
        return VerticalAccuracyEnum.meters_150;
      case 2:
        return VerticalAccuracyEnum.meters_45;
      case 3:
        return VerticalAccuracyEnum.meters_25;
      case 4:
        return VerticalAccuracyEnum.meters_10;
      case 5:
        return VerticalAccuracyEnum.meters_3;
      case 6:
        return VerticalAccuracyEnum.meters_1;
      default:
        return VerticalAccuracyEnum. Unknown;
    }
  }

  // Setter for vertical accuracy
  void setVerticalAccuracy(int verticalAccuracy) {
    this.verticalAccuracy.value = intToVerticalAccuracy(verticalAccuracy);
  }


  // Getter and setter for Height Type
  HeightTypeEnum getHeightType() => heightType.value;

  void setHeightType(int heightTypeValue) {
  heightType.value = heightTypeValue == 1 ? HeightTypeEnum.Ground : HeightTypeEnum.Takeoff;
  }




  // Method to calculate direction
  static double calcDirection(int value, int EW) {
    if (EW == 0) {
      return value.toDouble(); // East direction
    } else {
      return value + 180.0; // West direction, adding 180 degrees
    }
  }
  String getDirectionAsString() {
    if (direction != 361) {
      return "${direction.toStringAsFixed(0)} deg";
    } else {
      return "Unknown";
    }
  }

  // Method to get altitude pressure as a string



  // Setter to ensure valid range for altitude pressure
  void setAltitudePressure(double altitudePressure) {
    if (altitudePressure < -1000 || altitudePressure > 31767) {
      altitudePressure = -1000; // Invalid value
    }
    this.altitudePressure.value = altitudePressure;
  }

  // Setter to ensure valid range for altitude geodetic
  void setAltitudeGeodetic(double altitudeGeodetic) {
    if (altitudeGeodetic < -1000 || altitudeGeodetic > 31767) {
      altitudeGeodetic = -1000; // Invalid value
    }
    this.altitudeGeodetic.value = altitudeGeodetic;
  }

  void setDirection(double directionValue) {
    if (directionValue < 0 || directionValue > 360) {
      direction = 361.0.obs; // Invalid value
    } else {
      direction = directionValue.obs;
    }
  }

  // Getter and setter for Speed Horizontal
  double getSpeedHorizontal() => speedHorizontal.value;

  String getSpeedHorizontalAsString() {
    if (speedHorizontal != 255) {
      return "${speedHorizontal.toStringAsFixed(2)} m/s";
    } else {
      return "Unknown";
    }
  }

  String getSpeedHorizontalLessPreciseAsString() {
    if (speedHorizontal != 255) {
      return "${speedHorizontal.toStringAsFixed(0)} m/s";
    } else {
      return "Unknown";
    }
  }

  void setSpeedHorizontal(double speed) {
    if (speed < 0 || speed > 254.25) {
      speedHorizontal = 255.0.obs; // Invalid value
    } else {
      speedHorizontal = speed.obs;
    }
  }

  // Getter and setter for Speed Vertical
  double getSpeedVertical() => speedVertical.value;

  String getSpeedVerticalAsString() {
    if (speedVertical != 63) {
      return "${speedVertical.toStringAsFixed(2)} m/s";
    } else {
      return "Unknown";
    }
  }

  void setSpeedVertical(double speed) {
    if (speed < -62 || speed > 62) {
      speedVertical = 63.0.obs; // Invalid value
    } else {
      speedVertical = speed.obs;
    }
  }

  // Setter for latitude with validation
  setLatitude(double latitude) {
    if (latitude < -90 || latitude > 90) {
      latitude = 0;
      longitude.value = 0; // Both set to zero as per the specification
    } else {
      latitude = latitude;
    }
  }

  // Setter for longitude with validation
  setLongitude(double longitude) {
    if (longitude < -180 || longitude > 180) {
      latitude.value = 0;
      longitude = 0; // Both set to zero as per the specification
    } else {
      longitude = longitude;
    }
  }




  // Setter for height with validation
  setHeight(double height) {
    if (height < -1000 || height > 31767) {
      height = -1000; // Invalid value as per specification
    } else {
      height = height;
    }
  }

  // Getter for baro accuracy
  VerticalAccuracyEnum getBaroAccuracy() {
    return baroAccuracy.value;
  }

  // Setter for baro accuracy
  void setBaroAccuracy(int verticalAccuracy) {
    this.baroAccuracy.value = intToVerticalAccuracy(verticalAccuracy);
  }

  // Convert integer to SpeedAccuracyEnum
  SpeedAccuracyEnum intToSpeedAccuracy(int accuracy) {
    switch (accuracy) {
      case 1:
        return SpeedAccuracyEnum.meter_per_second_10;
      case 2:
        return SpeedAccuracyEnum.meter_per_second_3;
      case 3:
        return SpeedAccuracyEnum.meter_per_second_1;
      case 4:
        return SpeedAccuracyEnum.meter_per_second_0_3;
      default:
        return SpeedAccuracyEnum.Unknown;
    }
  }
  // Setter for speed accuracy
  void setSpeedAccuracy(int speedAccuracy) {
    switch (speedAccuracy) {
      case 1:
        this.speedAccuracy.value = SpeedAccuracyEnum.meter_per_second_10;
        break;
      case 2:
        this.speedAccuracy.value  = SpeedAccuracyEnum.meter_per_second_3;
        break;
      case 3:
        this.speedAccuracy.value  = SpeedAccuracyEnum.meter_per_second_1;
        break;
      case 4:
        this.speedAccuracy.value  = SpeedAccuracyEnum.meter_per_second_0_3;
        break;
      default:
        this.speedAccuracy.value  = SpeedAccuracyEnum.Unknown;
        break;
    }
  }

  // Setter for location timestamp
  void setLocationTimestamp(double locationTimestamp) {
    if (locationTimestamp < 0) {
      locationTimestamp = 0;
    }
    if (locationTimestamp != 0xFFFF && locationTimestamp > 36000) {
      locationTimestamp = 36000; // Max one hour is allowed. Unit is 0.1s
    }
    this.locationTimestamp.value = locationTimestamp;
  }

  // Getter for location timestamp
  double getLocationTimestamp() {
    return locationTimestamp.value;
  }

  // Setter for distance
  void setDistance(double distance) {
    this.distance.value = distance;
  }

  void setTimeAccuracy(double timeAccuracy) {
    if (timeAccuracy < 0) {
      timeAccuracy = 0;
    }
    if (timeAccuracy > 1.5) {
      timeAccuracy = 1.5; // 1.5s is the maximum value in the specification
    }
    this.timeAccuracy.value = timeAccuracy;
  }






  @override
  String toString() {
    return toJson().toString();
  }
}
