package com.wmu.drip.drip

import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.BluetoothLeScanner
import android.os.Handler
import android.os.Looper
import android.util.Log

class MainActivity : FlutterActivity() {
    private val CHANNEL = "ble/raw_data"
    private var bluetoothLeScanner: BluetoothLeScanner? = null
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "startScanning" -> {
                    startBLEScan(result)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }

    private fun startBLEScan(result: MethodChannel.Result) {
        if (bluetoothAdapter == null || !bluetoothAdapter!!.isEnabled) {
            result.error("UNAVAILABLE", "Bluetooth not available or disabled", null)
            return
        }

        bluetoothLeScanner = bluetoothAdapter!!.bluetoothLeScanner

        if (bluetoothLeScanner == null) {
            result.error("UNAVAILABLE", "Bluetooth LE Scanner not available", null)
            return
        }



        val scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val scanRecord = result.scanRecord
                val rawData = scanRecord?.bytes
                val deviceName = result.device.name ?: "Unknown Device"
                val deviceAddress = result.device.address

                // Extract Manufacturer Data
                val manufacturerData = scanRecord?.manufacturerSpecificData
                val manufacturerMap = mutableMapOf<Int, String>()
                if (manufacturerData != null) {
                    for (i in 0 until manufacturerData.size()) {
                        manufacturerMap[manufacturerData.keyAt(i)] = manufacturerData.valueAt(i)?.toHexString() ?: ""
                    }
                }

                // Extract Service Data
                val serviceData = scanRecord?.serviceData
                val serviceDataMap = mutableMapOf<String, String>()
                serviceData?.forEach { (uuid, data) ->
                    serviceDataMap[uuid.toString()] = data?.toHexString() ?: ""
                }

                // Extract Service UUIDs
                val serviceUuids = scanRecord?.serviceUuids?.map { it.uuid.toString() } ?: listOf()

                val dataMap = mapOf(
                    "deviceName" to deviceName,
                    "deviceAddress" to deviceAddress,
                    "rawData" to rawData?.toHexString(),
                    "manufacturerData" to manufacturerMap,
                    "serviceData" to serviceDataMap,
                    "serviceUuids" to serviceUuids
                )

                // Send data to Flutter
                Handler(Looper.getMainLooper()).post {
                    flutterEngine?.dartExecutor?.binaryMessenger?.let { messenger ->
                        MethodChannel(messenger, CHANNEL).invokeMethod("onScanResult", dataMap)
                    }
                }
            }



            private fun ByteArray.toHexString(): String {
                return joinToString("") { "%02x".format(it) }
            }


            override fun onScanFailed(errorCode: Int) {
                Log.e("BLE_SCAN", "Scan failed with error: $errorCode")
            }
        }

        bluetoothLeScanner!!.startScan(scanCallback)
        result.success("Scanning started")
    }
}
