<?php

$conn = mysqli_connect("localhost", "phpmyadmin", "Akansrya2123!@#","drip");

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}


 
?>