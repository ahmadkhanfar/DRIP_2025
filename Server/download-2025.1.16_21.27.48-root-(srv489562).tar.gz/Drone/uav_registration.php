<?php
header('Content-Type: application/json');
require('connection.php');
date_default_timezone_set('Asia/Jerusalem'); 
$data = array("message" => "", "status" => false, "DET"  => "");
$rawPostData = file_get_contents("php://input");
$dataC = json_decode($rawPostData, true);
$data['DET'] = "";
error_log("Raw POST Data: " . $rawPostData); // Log raw data for verification
if (isset($dataC['ParentDET']) && isset($dataC['pk']) && isset($dataC['prK'])) {
    $DET = $dataC['ParentDET']; 
    $pk = $dataC['pk'];
    $prK = $dataC['prK'];
	$sign = $dataC['parentSignature'];
    $dt2 = date("Y-m-d H:i:s");
	$name = "WMU";
	$drip_link = $dataC['dripLink'];

    $insert = mysqli_query($conn, "INSERT INTO hda (hda_id,hda_name, public_key, private_key, drip_link_sign, drip_link, created_date) VALUES ('$DET','$name' , '$pk', '$prK', '$sign', '$drip_link' ,'$dt2')");

    if ($insert) {
        $data['message'] = "HDA INSERTED";
        $data['status'] = true;
    } else {
        $data['message'] = "HDA FAILED TO INSERT";
    }
}else if (isset($dataC['DET']) && isset($dataC['pk']) && isset($dataC['hda'])){
	 
   $DET = $dataC['DET']; 
    $pk = $dataC['pk'];
	$hda = $dataC['hda'];
	$prK = $dataC['prK'];
    $dt2 = date("Y-m-d H:i:s");
	date_default_timezone_set('Asia/Jerusalem'); 
	$wrapper = $dataC['wrapper'];
	// Example additional data to sign
    $validNotBefore = time(); // Current Unix timestamp
    $validNotAfter = $validNotBefore + 300; // 5 minutes validity
     	$wmu = "WMU";
	$get_det = mysqli_fetch_assoc(mysqli_query($conn, "select * from hda where hda_name = '$wmu'")); 
	$hda_det = $get_det['hda_id'];
 // Concatenate data to be signed (HDA DET + UAV DET + UAV Public Key + Validity Periods)
    $dataToSign = hex2bin($hda_det) . hex2bin($DET) . hex2bin($pk) .
                  pack('V', $validNotBefore) . pack('V', $validNotAfter);

    // HDA Private Key (securely stored)
    $hdaPrivateKey = hex2bin('48167550213a954ff6a5be20dec52b6483788752f359c6480181226120957bb33e373f3064e6da5a1a3248df708ba95bf405d13b12a169fc5017c5cdeb33baed');

    // Generate the signature using Sodium
    $signature = sodium_crypto_sign_detached($dataToSign, $hdaPrivateKey);
    $signatureHex = bin2hex($signature);


    $insert = mysqli_query($conn, "INSERT INTO det_endorsements (det_id,hda_id, public_key,private_key, signature, wrapper, created_date ) VALUES ('$DET', '$hda','$pk' ,'$prK', '$signatureHex', '$wrapper', '$dt2')");

    if ($insert) {
       
    	 $dnsStatus = addDetToDns($DET, $pk);
    
        if ($dnsStatus) {
        	
            $data['message'] = "DET INSERTED AND DNS UPDATED";
        
            $data['status'] = true;
        	$data['signature'] = $signatureHex;

        	$data['hda_det'] = $get_det['hda_id'];
        	$data['vna'] = $validNotAfter;
            $data['vnb'] = $validNotBefore;
        } else {
            $data['message'] = "DET INSERTED BUT DNS UPDATE FAILED";
            $data['status'] = false;
        }
    
    } else {
        $data['message'] = "DET FAILED TO INSERT";


}

} else {
    $data['message'] = "Potential attack or malformed request.";
    error_log("Decoded JSON: " . print_r($dataC, true)); // Debug log for decoded JSON
}



// Function to add DET to DNS

function addDetToDns($det, $publicKey) {
    $zoneFilePath = "/etc/bind/db.vertexpal.com"; // Path to your zone file
    $reverseDet = reverseDet($det);
    $txtRecord = "$reverseDet TXT \"pubkey=$publicKey\"\n";

    try {
    	$startTime = microtime(true);
        // Check if the DET already exists in the DNS file
        if (isDetInDns($reverseDet, $zoneFilePath)) {
            error_log("DET $reverseDet already exists in DNS.");
            return "DET already exists in DNS.";
        }

        // Append the TXT record to the zone file
        file_put_contents($zoneFilePath, $txtRecord, FILE_APPEND);

        // Reload the DNS server
        exec("sudo systemctl reload bind9", $output, $returnCode);
    
    	$endTime = microtime(true);
    	$elapsedTime = $endTime - $startTime;
        $elapsedTimeMs = round($elapsedTime * 1000, 2); 
    	error_log("DNS registration time: {$elapsedTimeMs} ms");


        if ($returnCode === 0) {
            return "DET successfully added to DNS.";
        } else {
            error_log("Failed to reload DNS: " . implode("\n", $output));
            return "Failed to reload DNS.";
        }
    } catch (Exception $e) {
        error_log("Error updating DNS: " . $e->getMessage());
        return "Error updating DNS.";
    }
}

// Function to check if DET already exists in DNS
function isDetInDns($reverseDet, $zoneFilePath) {
    try {
        // Read the zone file
        $zoneFileContent = file_get_contents($zoneFilePath);

        // Check if the DET exists
        return strpos($zoneFileContent, $reverseDet) !== false;
    } catch (Exception $e) {
        error_log("Error reading DNS file: " . $e->getMessage());
        return false;
    }
}

// Function to reverse DET
function reverseDet($det) {
    return implode('.', array_reverse(str_split($det, 2))) . ".vertexpal.com.";
}



// Output JSON response
echo json_encode(array($data));
?>
