#!/bin/bash
echo "Checking for updates..."
sudo apt-get update && sudo apt-get upgrade -y
echo "Updates applied successfully."
