<?php
// Enable error reporting for debugging (optional, disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if data is received via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the raw POST data
    $postData = file_get_contents("php://input");

    // Decode the JSON payload
    $data = json_decode($postData, true);

    // Validate if required fields are present
    if (isset($data['wrapper']) && isset($data['pk'])) {
        $wrapper_hex = $data['wrapper']; // Wrapper data in hex
        $public_key_hex = $data['pk'];   // Public key in hex
        $signature_length = 64;         // Signature length in bytes

        // Function to convert hex string to binary data
        function hex_to_bytes($hex) {
            return hex2bin($hex);
        }

        // Convert hex data to binary
        $wrapper_bytes = hex_to_bytes($wrapper_hex);
        $public_key_bytes = hex_to_bytes($public_key_hex);

        // Extract signature and message from the wrapper
        $signature_bytes = substr($wrapper_bytes, -$signature_length); // Last 64 bytes
        $message_bytes = substr($wrapper_bytes, 0, -$signature_length); // All except last 64 bytes

        // Log extracted data (optional, for debugging)
        file_put_contents("log.txt", "Message Length: " . strlen($message_bytes) . "\n", FILE_APPEND);
        file_put_contents("log.txt", "Signature Length: " . strlen($signature_bytes) . "\n", FILE_APPEND);

        // Verify the signature
        try {
            $is_valid = sodium_crypto_sign_verify_detached($signature_bytes, $message_bytes, $public_key_bytes);
            if ($is_valid) {
                echo json_encode([
                    "status" => "success",
                    "message" => "Signature is valid. Authentication successful."
                ]);
            } else {
                echo json_encode([
                    "status" => "error",
                    "message" => "Signature verification failed. Authentication unsuccessful."
                ]);
            }
        } catch (Exception $e) {
            echo json_encode([
                "status" => "error",
                "message" => "An error occurred during verification: " . $e->getMessage()
            ]);
        }
    } else {
        // Handle missing fields in the payload
        echo json_encode([
            "status" => "error",
            "message" => "Invalid data: 'wrapper' and 'pk' fields are required."
        ]);
    }
} else {
    // Handle invalid request method
    echo json_encode([
        "status" => "error",
        "message" => "Invalid request method. Use POST."
    ]);
}
?>
