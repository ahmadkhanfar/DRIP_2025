import 'dart:convert';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';

class BLEController extends GetxController {
  final FlutterBluePlus flutterBlue = FlutterBluePlus();

  var isScanning = false.obs;
  var devices = <BluetoothDevice>[].obs;
  var receivedData = <String>[].obs;

  @override
  void onInit() {
    super.onInit();
    requestPermissions().then((_) => startScanning());
  }

  // Request BLE permissions
  Future<void> requestPermissions() async {
    await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.location,
    ].request();
  }

  // Start scanning for BLE devices
  void startScanning() async {
    devices.clear();
    receivedData.clear();
    isScanning.value = true;

    // Start BLE scan
    print("Starting BLE Scan...");
    await FlutterBluePlus.startScan(timeout: const Duration(seconds: 30));

    // Listen to scan results
    FlutterBluePlus.scanResults.listen((results) {
      for (ScanResult r in results) {
        print("Device Found: ${r.device.name} - ${r.device.id}");
        if (!devices.contains(r.device)) {
          devices.add(r.device);
        }
      }
    });

    // Stop scanning after timeout
    isScanning.value = false;
    print("BLE Scan Complete");
  }

  // Connect to the ESP32 and request the wrapper
  void requestWrapper(BluetoothDevice device) async {
    try {
      print("Connecting to ${device.name}...");
      await device.connect();

      List<BluetoothService> services = await device.discoverServices();
      for (BluetoothService service in services) {
        print("Service Found: ${service.uuid}");
        if (service.uuid.toString().toLowerCase() ==
            "4fafc201-1fb5-459e-8fcc-c5c9c331914b") { // Match SERVICE_UUID
          for (BluetoothCharacteristic characteristic
          in service.characteristics) {
            print("Characteristic Found: ${characteristic.uuid}");
            if (characteristic.uuid.toString().toLowerCase() ==
                "d9b54fc1-2f14-4a47-943c-41a6795d58d9") { // Match CHARACTERISTIC_UUID

              // Write 'REQUEST_WRAPPER' to the characteristic
              print("Sending 'REQUEST_WRAPPER'...");
              await characteristic.write(utf8.encode("REQUEST_WRAPPER"));

              // Read the response (wrapper data)
              print("Reading response...");
              var value = await characteristic.read();
              String wrapperData = value
                  .map((e) => e.toRadixString(16).padLeft(2, '0'))
                  .join();
              print("Received Wrapper Data: $wrapperData");

              // Add the received wrapper data to the observable list
              receivedData.add(wrapperData);
              return; // Exit after processing the desired characteristic
            }
          }
        }
      }
      print("Target Service/Characteristic not found.");
    } catch (e) {
      print("Error: $e");
    } finally {
      await device.disconnect();
      print("Disconnected from ${device.name}");
    }
  }
}
