import 'package:flutter_blue_plus/flutter_blue_plus.dart';

class DRIPModel {
  String advName;
  int txPowerLevel;
  int appearance;
  bool connectable;
  Map<int, List<int>> manufacturerData;
  Map<Guid, List<int>>  serviceData;
  List<Guid>? serviceUuids;


  DRIPModel({
    required this.advName,
    required this.txPowerLevel,
    required this.appearance,
    required this.connectable,
    required this. manufacturerData,
    required this.serviceUuids,
    required this.serviceData,
});

  factory DRIPModel.fromJson(Map<String, dynamic> jsonData){

    return DRIPModel(
        advName: jsonData['advName'],
        txPowerLevel : jsonData['txPowerLevel'],
      appearance : jsonData['appearance'],
      connectable: jsonData['connectable'],
      serviceUuids: jsonData ['serviceUuids'],
      serviceData: jsonData ['serviceData'],
      manufacturerData : jsonData ['manufacturerData'],
    );

  }
}