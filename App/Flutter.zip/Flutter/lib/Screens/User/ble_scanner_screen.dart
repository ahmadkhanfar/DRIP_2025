import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../Services/Controllers/ble_contoller.dart';


class BLEScannerScreen extends StatelessWidget {
  const BLEScannerScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final BLEController bleController = Get.put(BLEController());

    return Scaffold(
      appBar: AppBar(
        title: const Text('ESP32 BLE Wrapper'),
      ),
      body: Column(
        children: [
          Obx(() => ElevatedButton(
            onPressed: bleController.isScanning.value
                ? null
                : bleController.startScanning,
            child: Text(bleController.isScanning.value
                ? 'Scanning...'
                : 'Start Scanning'),
          )),
          const SizedBox(height: 20),
          const Text(
            'Available Devices:',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: Obx(() => ListView.builder(
              itemCount: bleController.devices.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(bleController.devices[index].name.isNotEmpty
                      ? bleController.devices[index].name
                      : "Unknown Device"),
                  subtitle: Text(bleController.devices[index].id.toString()),
                  trailing: ElevatedButton(
                    onPressed: () {
                      bleController.requestWrapper(
                          bleController.devices[index]);
                    },
                    child: const Text("Request Wrapper"),
                  ),
                );
              },
            )),
          ),
          const SizedBox(height: 20),
          const Text(
            'Received Data:',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: Obx(() => ListView.builder(
              itemCount: bleController.receivedData.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(bleController.receivedData[index]),
                );
              },
            )),
          ),
        ],
      ),
    );
  }
}
