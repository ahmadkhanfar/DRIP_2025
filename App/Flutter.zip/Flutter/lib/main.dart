import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_rx/src/rx_workers/rx_workers.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:typed_data';
import 'package:dnsolve/dnsolve.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';

const platform = MethodChannel('ble/raw_data');


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {

  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BLE Scanner',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const BLEHomePage(),
    );
  }
}

class BLEHomePage extends StatefulWidget {
  const BLEHomePage({Key? key}) : super(key: key);

  @override
  _BLEHomePageState createState() => _BLEHomePageState();
}

class _BLEHomePageState extends State<BLEHomePage> {

  final FlutterBluePlus flutterBlue = FlutterBluePlus();
  final List<BluetoothDevice> devicesList = [];
  BluetoothDevice? connectedDevice;
  BluetoothCharacteristic? targetCharacteristic;


  final String serviceUUID = "6E400001-B5A3-F303-E0A9-E50E24DCCA9E";
  final String characteristicUUID = "6E400003-B5A3-F303-E0A9-E50E24DCCA9E";
  final String dripLinkCharacteristicUUID = "6E400004-B5A3-F303-E0A9-E50E24DCCA9E";


  String receivedData = "";
  bool isScanning = false;



  @override
  void initState() {
    super.initState();
    // Define a cache to store DET-to-public-key mappings

    requestPermissions();
    startScanAndPrintData();
  }

  Future<void> startScanAndPrintData() async {
    platform.setMethodCallHandler((call) async {
      if (call.method == 'onScanResult') {
        final Map<dynamic, dynamic> data = call.arguments;
        print('Device Name: ${data['deviceName']}');
        print('Device Address: ${data['deviceAddress']}');
        print('Raw Data: ${data['rawData']}');
        print('manufacturerData: ${data['manufacturerData']}');
        print('serviceData: ${data['serviceData']}');
        print('serviceUuids: ${data['serviceUuids']}');
      }
    });

    try {
      await platform.invokeMethod('startScanning');
    } on PlatformException catch (e) {
      print('Error: ${e.message}');
    }
  }

  void startScan() {
    setState(() {
      isScanning = true;
      devicesList.clear();
    });

    // Start scanning
    FlutterBluePlus.startScan(timeout: const Duration(seconds: 30)).then((_) {
      setState(() {
        isScanning = false;
      });
    });

    // Listen to scan results
    FlutterBluePlus.scanResults.listen((results) {
      for (ScanResult result in results) {
        // Check if Manufacturer Data contains the 0xD1 type
        final manufacturerData = result.advertisementData.manufacturerData;

        if(result.device.platformName.contains("EXT_BLE_TEST")) {
          print(result.device);
          print(manufacturerData);
          processManufacturerData(manufacturerData);

          print(result.advertisementData);
          print(result.advertisementData);
          // next we need to conevrt the manfu to hex






        }
        if (manufacturerData.isNotEmpty) {


          // Extract the custom data for type 0xD1
          if (manufacturerData.containsKey(9169)) {
            final wrapperBytes = manufacturerData[9169];
            final wrapperHex = hexEncode(Uint8List.fromList(wrapperBytes!));

            print("Wrapper Received: $wrapperHex");

            // Update UI with Wrapper data
            setState(() {
              receivedData = "Wrapper Received: $wrapperHex";
            });

            // Authenticate the Wrapper
            authenticateWrapper(wrapperHex, null).then((authResult) {
              setState(() {
                receivedData += "\nAuth Result: $authResult";
              });
              print("Authentication Result: $authResult");
            });
          }
        }

        // Add unique devices to the list
        if (!devicesList.contains(result.device)) {
          setState(() {
            devicesList.add(result.device);
          });
        }
      }
    });
  }


  void processManufacturerData(Map<int, List<int>> manufacturerData) {
    // Iterate over the map to handle all key-value pairs
    manufacturerData.forEach((key, value) {
      // Convert the value (List<int>) to a hex string
      String hexString = convertToHexList(value);

      // Print the key (manufacturer ID) and its corresponding hex data
      print('Manufacturer ID: $key');
      print('Manufacturer Data (Hex): $hexString');
    });
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("BLE Scanner"),
        actions: [
          if (connectedDevice != null)
            IconButton(
              icon: const Icon(Icons.cancel),
              onPressed: (){},
            )
        ],
      ),
      body: connectedDevice == null
          ? buildScanningView()
          : buildConnectedDeviceView(),
      floatingActionButton: connectedDevice == null
          ? FloatingActionButton(
        onPressed: isScanning ? null : startScan,
        child: Icon(isScanning ? Icons.hourglass_empty : Icons.search),
      )
          : null,
    );
  }

  Widget buildScanningView() {
    if (devicesList.isEmpty && !isScanning) {
      return const Center(
        child: Text(
          "No devices found. Tap the search button to scan again.",
          style: TextStyle(fontSize: 16),
        ),
      );
    }

    return ListView.builder(
      itemCount: devicesList.length,
      itemBuilder: (context, index) {
        BluetoothDevice device = devicesList[index];
        return ListTile(
          title: Text(device.name.isNotEmpty ? device.name : "Unknown Device"),
          subtitle: Text(device.id.toString()),
          onTap: () => (){},
        );
      },
    );
  }

  Widget buildConnectedDeviceView() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          "Connected to ${connectedDevice!.name}",
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        const Text("Received Data:"),
        Text(
          receivedData.isNotEmpty ? receivedData : "No data received yet.",
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: (){},
          child: const Text("Disconnect"),
        ),
      ],
    );
  }
}

Future<void> requestPermissions() async {
  await [
    Permission.bluetooth,
    Permission.bluetoothScan,
    Permission.bluetoothConnect,
    Permission.location,
  ].request();
}

Future<String> authenticateWrapper(String wrapperHex,BluetoothCharacteristic? dripLinkCharacteristic) async {


  Uint8List publicKeyBytes = Uint8List(0) ;
  bool isValid = false;
  bool isLink = false;
  try {
    // Record the start time
    final startTime = DateTime.now();
    final wrapperBytes = Uint8List.fromList(hexToBytes(wrapperHex));
    final signatureBytes = wrapperBytes.sublist(wrapperBytes.length - 64);
    final messageBytes = wrapperBytes.sublist(0, wrapperBytes.length - 64);

    print("Message (Hex): ${hexEncode(Uint8List.fromList(messageBytes))}");
    print("Signature (Hex): ${hexEncode(Uint8List.fromList(signatureBytes))}");
// Extract DET (16 bytes before the signature, after the evidence)
    final detBytes = messageBytes.sublist(messageBytes.length - 16, messageBytes.length);
    final detHex = hexEncode(Uint8List.fromList(detBytes));
    print("DET (Hex): $detHex");
    // Listen for DRIP Link if characteristic is available
    if (dripLinkCharacteristic != null) {
      final dripLinkValue =
      await listenDripLinkFromCharacteristic(dripLinkCharacteristic, 1);
      if (dripLinkValue == null) {
        print("DRIP Link received: $dripLinkValue");
        Uint8List dripLinkBytes = hexToBytes(dripLinkValue!);
        publicKeyBytes = dripLinkBytes.sublist(24, 56);


        isLink = true;

        //return await authenticateDripLink(dripLinkValue);
      }else {

        // Fetch the public key via reverse DNS lookup
        final publicKeyHex = await reverseDnsLookup(detHex);
        if (publicKeyHex == null) {
          print("Failed to fetch public key for DET: $detHex");
          return "Error: Public key not found.";
        }
        print("Fetched Public Key: $publicKeyHex");
        // Convert public key from hex to bytes
        publicKeyBytes = Uint8List.fromList(hexToBytes(publicKeyHex));
      }


      final publicKey = SimplePublicKey(publicKeyBytes, type: KeyPairType.ed25519);
      final signature = Signature(signatureBytes, publicKey: publicKey);
      isValid = await Ed25519().verify(Uint8List.fromList(messageBytes), signature: signature);
      // Record the end time
      final endTime = DateTime.now();
      // Calculate the time taken
      final duration = endTime.difference(startTime).inMilliseconds;
      isLink ? print("Wrapper Authentication time Using DRIP LINK : $duration ms") :print("Wrapper Authentication time Using DNS / Cache : $duration ms") ;
    }


    return isValid ? "Authentication successful: Signature is valid." : "Authentication failed: Signature is invalid.";
  } catch (e) {
    return "Error during authentication: $e";
  }
}


Future<String?> listenDripLinkFromCharacteristic(
    BluetoothCharacteristic dripLinkCharacteristic, int timeoutInSeconds) async {

  final completer = Completer<String?>();
  final startDRIPTime = DateTime.now();
  await dripLinkCharacteristic.setNotifyValue(true);
  dripLinkCharacteristic.value.listen((value) {

    final receivedDripLink = utf8.decode(value);
    final elapsedTime = DateTime.now().difference(startDRIPTime).inMilliseconds;
    print("Time taken to receive DRIP Link: ${elapsedTime}ms");
    print("DRIP Link received: $receivedDripLink");
    if (!completer.isCompleted) {
      completer.complete(receivedDripLink);
    }
  });

  // Handle timeout
  Future.delayed(Duration(seconds: 0), () {
    if (!completer.isCompleted) {
      print("Timeout waiting for DRIP Link");
      completer.complete(null);
    }
  });

  return completer.future;
}

/// Helper to Encode Hex
String hexEncode(Uint8List bytes) => bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();

/// Helper to Convert Hex to Bytes
Uint8List hexToBytes(String hex) {
  final bytes = <int>[];
  for (int i = 0; i < hex.length; i += 2) {
    bytes.add(int.parse(hex.substring(i, i + 2), radix: 16));
  }
  return Uint8List.fromList(bytes);
}



Future<String?> checkCache(String detHex) async {
  final startTime = DateTime.now();
  final cache = await PublicKeyCache.loadCache();


  // Check if the DET exists in the cache
  if (cache.containsKey(detHex)) {
    print("Public key found in cache for DET: $detHex");
    final endTime = DateTime.now();
    // Calculate the time taken
    final duration = endTime.difference(startTime).inMilliseconds;

    print("Time it took to hit: $duration");
    return cache[detHex];
  }else{
    final endTime = DateTime.now();
    // Calculate the time taken
    final duration = endTime.difference(startTime).inMilliseconds;
    print("Time it took to miss: $duration");
    reverseDnsLookup (detHex);
  }
}


Future<String?> reverseDnsLookup(String detHex) async {
  try {
    // Record the start time
    final startTime = DateTime.now();
    final detDomain = reverseDet(detHex); // Reverse DET to domain format
    final dnsolve = DNSolve();
    final response = await dnsolve.lookup(
        detDomain,
        dnsSec: false,
        type: RecordType.txt,
        provider: DNSProvider.google
    );

    if (response.answer?.records != null) {
      for (final record in response.answer!.records!) {
        if (record.rType == RecordType.txt && record.data.contains("pubkey=")) {
          final publicKey = record.data.split("pubkey=")[1].trim();
          final endTime = DateTime.now();
          // Calculate the time taken
          final duration = endTime.difference(startTime).inMilliseconds;
          // Add the public key to the cache
          final cache = await PublicKeyCache.loadCache();
          print("DNS RESOLVE time: $duration ms");
          cache[detHex] = publicKey;
          // Save the updated cache
          await PublicKeyCache.saveCache(cache);
          print("Saved in Cache Public Key: $publicKey");
          return publicKey;


        }
      }
    }
    return null;
  } catch (e) {
    return null;
  }
}
String reverseDet(String detHex) {

  // Convert DET into a list of bytes (2 characters per byte)
  final bytes = <String>[];
  for (int i = 0; i < detHex.length; i += 2) {
    bytes.add(detHex.substring(i, i + 2));
  }

  // Reverse the byte order and join with dots
  final reversedBytes = bytes.reversed.join('.').toLowerCase();

  // Append the domain
  return "$reversedBytes.vertexpal.com";
}



String extractPublicKeyFromDnsResponse(String response) {
  // Parse the public key from the DNS TXT response
  final regex = RegExp(r'pubkey=([0-9a-fA-F]+)');
  final match = regex.firstMatch(response);
  if (match != null) {
    return match.group(1) ?? "Invalid response format.";
  } else {
    return "Public key not found in response.";
  }
}


class PublicKeyCache {
  static const String _cacheKey = "publicKeyCache";

  // Load the cache from persistent storage
  static Future<Map<String, String>> loadCache() async {
    final prefs = await SharedPreferences.getInstance();
    final cacheString = prefs.getString(_cacheKey);
    if (cacheString != null) {
      return Map<String, String>.from(jsonDecode(cacheString));
    }
    return {};
  }

  // Save the cache to persistent storage
  static Future<void> saveCache(Map<String, String> cache) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_cacheKey, jsonEncode(cache));
  }
}


void parseDripLink(String dripLinkHex,   Uint8List dripLinkBytes) {
  // Convert hex string to bytes


  // Extract fields
  Uint8List validNotBeforeBytes = dripLinkBytes.sublist(0, 4);
  Uint8List validNotAfterBytes = dripLinkBytes.sublist(4, 8);
  Uint8List uavDetBytes = dripLinkBytes.sublist(8, 24);
  Uint8List uavPublicKeyBytes = dripLinkBytes.sublist(24, 56);
  Uint8List parentDetBytes = dripLinkBytes.sublist(56, 72);
  Uint8List parentSignatureBytes = dripLinkBytes.sublist(72, 136);

  // Convert fields to readable formats
  int validNotBefore = ByteData.sublistView(validNotBeforeBytes).getUint32(0, Endian.little);
  int validNotAfter = ByteData.sublistView(validNotAfterBytes).getUint32(0, Endian.little);
  String uavDetHex = hexEncode(uavDetBytes);
  String uavPublicKeyHex = hexEncode(uavPublicKeyBytes);
  String parentDetHex = hexEncode(parentDetBytes);
  String parentSignatureHex = hexEncode(parentSignatureBytes);

  print("Valid Not Before: $validNotBefore");
  print("Valid Not After: $validNotAfter");
  print("UAV DET: $uavDetHex");
  print("UAV Public Key: $uavPublicKeyHex");
  print("Parent DET: $parentDetHex");
  print("Parent Signature: $parentSignatureHex");
}





/*Future<bool> authenticateUAV(
    String detHex, String wrapperSignatureHex, String uavPublicKeyHex) async {
  try {
    // Convert inputs to bytes
    Uint8List detBytes = hexToBytes(detHex);
    Uint8List signatureBytes = hexToBytes(wrapperSignatureHex);
    Uint8List uavPublicKeyBytes = hexToBytes(uavPublicKeyHex);

    // Load UAV public key
    final publicKey = SimplePublicKey(uavPublicKeyBytes, type: KeyPairType.ed25519);

    // Verify the UAV Signature
    final signature = Signature(signatureBytes, publicKey: publicKey);
    final isValid = await Ed25519().verify(detBytes, signature: signature);

    print(isValid ? "UAV Signature is valid." : "UAV Signature is invalid.");
    return isValid;
  } catch (e) {
    print("Error authenticating UAV: $e");
    return false;
  }
}*/


bool validateTimestamps(int validNotBefore, int validNotAfter) {
  int currentTimestamp = DateTime.now().millisecondsSinceEpoch ~/ 1000;
  if (currentTimestamp >= validNotBefore && currentTimestamp <= validNotAfter) {
    print("Timestamps are valid.");
    return true;
  } else {
    print("Timestamps are invalid.");
    return false;
  }
}

String convertToHexList(List<int> manufacturerData) {
  // Convert each byte to a 2-character hexadecimal string
  String hexString = manufacturerData.map((byte) => byte.toRadixString(16).padLeft(2, '0')).join(' ');
  return hexString;
}

Future<String> authenticateDripLink(String dripLinkHex) async {
  try {
    final startTime = DateTime.now();



    // Parse the DRIP Link
    Uint8List dripLinkBytes = hexToBytes(dripLinkHex);
    const String hdaPublicKeyHex = "3e373f3064e6da5a1a3248df708ba95bf405d13b12a169fc5017c5cdeb33baed";

    // Extract fields from the DRIP Link
    Uint8List validNotBeforeBytes = dripLinkBytes.sublist(0, 4);
    Uint8List validNotAfterBytes = dripLinkBytes.sublist(4, 8);
    Uint8List uavDetBytes = dripLinkBytes.sublist(8, 24);
    Uint8List uavPublicKeyBytes = dripLinkBytes.sublist(24, 56);
    Uint8List parentDetBytes = dripLinkBytes.sublist(56, 72);
    Uint8List parentSignatureBytes = dripLinkBytes.sublist(72, 136);

    // Convert fields to readable formats
    int validNotBefore = ByteData.sublistView(validNotBeforeBytes).getUint32(0, Endian.little);
    int validNotAfter = ByteData.sublistView(validNotAfterBytes).getUint32(0, Endian.little);
    String uavDetHex = hexEncode(uavDetBytes);
    String uavPublicKeyHex = hexEncode(uavPublicKeyBytes);
    String parentDetHex = hexEncode(parentDetBytes);
    String parentSignatureHex = hexEncode(parentSignatureBytes);


    print("Parsed DRIP Link Fields:");
    print("Valid Not Before: $validNotBefore");
    print("Valid Not After: $validNotAfter");
    print("UAV DET: $uavDetHex");
    print("UAV Public Key: $uavPublicKeyHex");
    print("Parent DET: $parentDetHex");
    print("Parent Signature: $parentSignatureHex");

    // Step 1: Validate timestamps
    /*if (!validateTimestamps(validNotBefore, validNotAfter)) {
      return "Invalid timestamps in DRIP Link.";
    }*/


    print(" HDA Public Key: $hdaPublicKeyHex");

    // Step 3: Verify Parent Signature
    bool isParentSignatureValid = await verifyParentSignature(parentDetHex: parentDetHex,
        parentSignatureHex: parentSignatureHex,
        uavDetHex: uavDetHex,
        uavPublicKeyHex: uavPublicKeyHex,
        hdaPublicKeyHex: hdaPublicKeyHex,
        validNotAfter: validNotAfter,
        validNotBefore: validNotBefore

    );
    if (!isParentSignatureValid) {
      return "Parent Signature verification failed.";
    }

    print("Parent Signature verified successfully.");
    final elapsedTime = DateTime.now().difference(startTime).inMilliseconds;
    print("Time taken to authenticate received DRIP Link: ${elapsedTime}ms");


    // Step 4: Authenticate the UAV
    /* bool isUAVAuthenticated = await authenticateUAV(
      uavDetHex,
      parentSignatureHex, // Wrapper signature is generally needed for full UAV authentication
      uavPublicKeyHex,
    );
    if (!isUAVAuthenticated) {
      return "UAV authentication failed.";
    }

    print("UAV authentication successful.");
*/
    // If all steps pass
    return "DRIP Link authenticated successfully.";
  } catch (e) {
    print("Error during DRIP Link authentication: $e");
    return "Error during DRIP Link authentication: $e";
  }
}



Future<bool> verifyParentSignature({
  required String uavDetHex,
  required String parentDetHex,
  required String uavPublicKeyHex,
  required String parentSignatureHex,
  required String hdaPublicKeyHex,
  required int validNotBefore,
  required int validNotAfter,
}) async {
  try {
    // Convert hex strings to bytes
    Uint8List uavDetBytes = hexToBytes(uavDetHex);
    Uint8List parentDetBytes = hexToBytes(parentDetHex);
    Uint8List uavPublicKeyBytes = hexToBytes(uavPublicKeyHex);
    Uint8List parentSignatureBytes = hexToBytes(parentSignatureHex);
    Uint8List hdaPublicKeyBytes = hexToBytes(hdaPublicKeyHex);

    // Concatenate data to be verified (HDA DET + UAV DET + UAV Public Key + Validity Periods)
    Uint8List validityPeriodBytes = Uint8List(8)
      ..buffer.asByteData().setUint32(0, validNotBefore, Endian.little)
      ..buffer.asByteData().setUint32(4, validNotAfter, Endian.little);

    Uint8List dataToVerify = Uint8List.fromList(
      parentDetBytes + uavDetBytes + uavPublicKeyBytes + validityPeriodBytes,
    );

    // Verify the signature
    final publicKey = SimplePublicKey(hdaPublicKeyBytes, type: KeyPairType.ed25519);
    final signature = Signature(parentSignatureBytes, publicKey: publicKey);

    bool isValid = await Ed25519().verify(dataToVerify, signature: signature);

    print(isValid ? "Parent Signature is valid." : "Parent Signature is invalid.");
    return isValid;
  } catch (e) {
    print("Error verifying Parent Signature: $e");
    return false;
  }
}


