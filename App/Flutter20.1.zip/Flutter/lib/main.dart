
import 'package:drip/Screens/User/home_screen.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import 'Services/Controllers/ble_scan_controller.dart';
import 'Services/Controllers/map_controller.dart';
import 'Services/Controllers/wrapper_auth_controller.dart';
const platform = MethodChannel('ble/raw_data');
void main() {
  Get.lazyPut(() => wrapperController());
  Get.lazyPut(() => bleScanController());
  Get.lazyPut(() => map_controller());

  runApp(const MyApp());
}
class MyApp extends StatelessWidget {

  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BLE Scanner',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomeScreen(),
    );
  }
}








