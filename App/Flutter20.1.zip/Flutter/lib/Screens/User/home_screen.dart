

import 'package:drip/Services/Controllers/ble_scan_controller.dart';
import 'package:drip/Services/Controllers/map_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart';
import 'package:get/get.dart';

import '../../Widgets/bottom_sheet.dart';

class HomeScreen extends StatelessWidget {

  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final mapController = Get.find<map_controller>();
    return Scaffold(

      body: SafeArea(
          child: GetBuilder<map_controller>(
          builder:(controller) {
            return Column(
              children: [
                Expanded(
                  child: OSMFlutter(
                    controller: mapController.mapController,
                    onGeoPointClicked:(GeoPoint geoPoint) {
                      // Check if the tapped marker matches the drone's location
                      final droneInfo = mapController.getDroneInfo(geoPoint);
                      if (droneInfo != null) {
                        showDroneInfoBottomSheet(context);
                      }
                    },
                    osmOption: OSMOption(
                      showZoomController: true,
                      userLocationMarker: UserLocationMaker(
                        personMarker: MarkerIcon(
                          icon: Icon(
                            Icons.airplanemode_active, // Use the airplane icon
                            color: Colors.red,
                            size: 48,
                          ),
                        ),
                        directionArrowMarker: MarkerIcon(
                          icon: Icon(
                            Icons.airplanemode_active, // Optional direction marker
                            color: Colors.blue,
                            size: 48,
                          ),
                        ),

                      ),
                    ),
                  ),
                ),

              ],);


          }))

      );
  }
}
