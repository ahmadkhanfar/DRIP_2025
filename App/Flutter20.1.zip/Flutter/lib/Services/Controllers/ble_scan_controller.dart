import 'dart:isolate';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:dnsolve/dnsolve.dart';
import 'package:drip/Services/Controllers/wrapper_auth_controller.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:async/async.dart';

import '../check_cache.dart';
import 'helper_controller.dart';
import 'map_controller.dart';

class bleScanController extends GetxController {
  final Map<String, bool> detAuthenticationCache = {};
  String droneDet= "";
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    requestPermissions();

  }
  void startScan() {
    FlutterBluePlus.startScan(continuousUpdates: true).then((_) {
    });
    FlutterBluePlus.scanResults.listen((results) async {
      for (ScanResult result in results) {
        final manufacturerData = result.advertisementData.manufacturerData;
        if(result.device.platformName.contains("EXT_BLE_TEST")) {
          manufacturerData.forEach((key, value) {
            Uint8List wrapper = Uint8List.fromList(value);
            parseWrapper(wrapper);
          });
         processManufacturerData(manufacturerData);
        }
      }
    });
  }
  Future<void> requestPermissions() async {
    await [
      Permission.bluetooth,
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.location,
    ].request();
  }

 helperController _helper = new helperController();
 Future<String> authenticateWrapper(String wrapperHex) async {
   Uint8List publicKeyBytes = Uint8List(0) ;
   bool isValid = false;
   bool isLink = false;
   try {
     // Record the start time
     final startTime = DateTime.now();
     final wrapperBytes = Uint8List.fromList(_helper.hexToBytes(wrapperHex));
     final signatureBytes = wrapperBytes.sublist(wrapperBytes.length - 64);
     final messageBytes = wrapperBytes.sublist(0, wrapperBytes.length - 64);
     print ("wrapperBytes");
     print (wrapperBytes);
     print("Message (Hex): ${_helper.hexEncode(Uint8List.fromList(messageBytes))}");
     print("Signature (Hex): ${_helper.hexEncode(Uint8List.fromList(signatureBytes))}");
// Extract DET (16 bytes before the signature, after the evidence)
     final detBytes = messageBytes.sublist(messageBytes.length - 16, messageBytes.length);
     final detHex = _helper.hexEncode(Uint8List.fromList(detBytes));
     print("DET (Hex): $detHex");
     if (detAuthenticationCache.containsKey(detHex)) {
       print("Skipping authentication for already authenticated DET: $detHex");
       return "Already Authenticated";
     }
     final publicKeyHex = await checkCache(detHex);
     print("Fetched Public Key: $publicKeyHex");
     // Convert public key from hex to bytes
     publicKeyBytes = Uint8List.fromList(_helper.hexToBytes(publicKeyHex!));
     final publicKey = SimplePublicKey(publicKeyBytes, type: KeyPairType.ed25519);
     final signature = Signature(signatureBytes, publicKey: publicKey);
     isValid = await Ed25519().verify(Uint8List.fromList(messageBytes), signature: signature);
     if (isValid){
       detAuthenticationCache[detHex] = true;
       droneDet = detHex;

     }else{
       detAuthenticationCache[detHex] = false;
     }
     return isValid ? "Authentication successful: Signature is valid." : "Authentication failed: Signature is invalid.";
   } catch (e) {
     return "Error during authentication: $e";
   }
 }


 Future<String?> checkCache(String detHex) async {
   final startTime = DateTime.now();
   final cache = await PublicKeyCache.loadCache();

   // Check if the DET exists in the cache
   if (cache.containsKey(detHex)) {
     print("Public key found in cache for DET: $detHex");
     final endTime = DateTime.now();
     // Calculate the time taken
     final duration = endTime.difference(startTime).inMilliseconds;

     print("Time it took to hit: $duration");
     return cache[detHex];
   }else{
     final endTime = DateTime.now();
     // Calculate the time taken
     final duration = endTime.difference(startTime).inMilliseconds;
     print("Time it took to miss: $duration");
    await reverseDnsLookup (detHex);
   }
 }




 Future<String?> reverseDnsLookup(String detHex) async {
   try {
     // Record the start time
     final startTime = DateTime.now();
     final detDomain = reverseDet(detHex); // Reverse DET to domain format
     final dnsolve = DNSolve();
     final response = await dnsolve.lookup(
         detDomain,
         dnsSec: false,
         type: RecordType.txt,
         provider: DNSProvider.google
     );

     if (response.answer?.records != null) {
       for (final record in response.answer!.records!) {
         if (record.rType == RecordType.txt && record.data.contains("pubkey=")) {
           final publicKey = record.data.split("pubkey=")[1].trim();
           final endTime = DateTime.now();
           // Calculate the time taken
           final duration = endTime.difference(startTime).inMilliseconds;
           // Add the public key to the cache
           final cache = await PublicKeyCache.loadCache();
           print("DNS RESOLVE time: $duration ms");
           cache[detHex] = publicKey;
           // Save the updated cache
           await PublicKeyCache.saveCache(cache);
           print("Saved in Cache Public Key: $publicKey");
           return publicKey;


         }
       }
     }
     return null;
   } catch (e) {
     return null;
   }
 }



 String reverseDet(String detHex) {

   // Convert DET into a list of bytes (2 characters per byte)
   final bytes = <String>[];
   for (int i = 0; i < detHex.length; i += 2) {
     bytes.add(detHex.substring(i, i + 2));
   }

   // Reverse the byte order and join with dots
   final reversedBytes = bytes.reversed.join('.').toLowerCase();

   // Append the domain
   return "$reversedBytes.vertexpal.com";
 }







 /// Parses the dynamic wrapper and extracts its components.
 Map<String, dynamic> parseWrapper(Uint8List wrapper) {
   //testStaticLocation();
   final ByteData byteData = ByteData.sublistView(wrapper);

   // Extract fixed components
   int vnb = byteData.getUint32(0, Endian.little);
   int vna = byteData.getUint32(4, Endian.little);

   // Calculate payload size
   int payloadStartIndex = 8; // VNB (4 bytes) + VNA (4 bytes)
   int detStartIndex = wrapper.length - 80; // DET (16 bytes) + Signature (64 bytes)
   int payloadEndIndex = detStartIndex; // Payload ends where DET starts
   int payloadSize = payloadEndIndex - payloadStartIndex;

   // Extract payload
   Uint8List payload = wrapper.sublist(payloadStartIndex, payloadEndIndex);

   // Extract DET
   Uint8List det = wrapper.sublist(detStartIndex, detStartIndex + 16);

   // Extract Signature
   Uint8List signature = wrapper.sublist(detStartIndex + 16, wrapper.length);

   // Parse payload if necessary
   final parsedPayload = parseF3411Message(payload);

   // Return parsed components
   return {
     "VNB": vnb,
     "VNA": vna,
     "payload": parsedPayload,
     "DET": det,
     "signature": signature,
   };
 }

 /// Parses the F3411 payload and extracts geolocation and other details.
 Map<String, dynamic> parseF3411Message(Uint8List payload) {
   final ByteData byteData = ByteData.sublistView(payload);

   // Extract fields from the payload
   double latitudeRaw = byteData.getFloat32(0, Endian.little);
   double longitudeRaw = byteData.getFloat32(4, Endian.little);
   // to keep data live

   Get.find<map_controller>().Latitude.value  = latitudeRaw;
   Get.find<map_controller>().Longitude.value = longitudeRaw;
   int altitude = byteData.getUint16(8, Endian.little);
   int velocity = byteData.getUint16(10, Endian.little);

   print("Raw Payload Bytes: ${payload.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ')}");

   // Apply dynamic scaling

   print("Location");


   Get.find<map_controller>().updateDroneLocation(latitudeRaw, longitudeRaw);

   print(latitudeRaw);
   print(longitudeRaw);
   print(velocity);


   return {
     "latitude": latitudeRaw,
     "longitude": longitudeRaw,
     "altitude": altitude,
     "velocity": velocity,
   };

 }



 void processManufacturerData(Map<int, List<int>> manufacturerData) async {
   // Iterate over the map to handle all key-value pairs
   manufacturerData.forEach((key, value) async {
     // Prepend the constant 02 to the received manufacturer data
     List<int> adjustedValue =   value;
     // Convert the adjusted value (List<int>) to a hex string
     String hexString = _helper.convertToHexList(adjustedValue);
     //print("Adjusted Data (Hex): $hexString");
     //final result = await authenticateWrapper (hexString,null);
     //print("Auth Result: $result");
     // Authenticate the wrapper with the adjusted data
     await authenticateWrapper(hexString).then((authResult) {

        print("Authentication Result: $authResult");
      });
     // Print the key (manufacturer ID) and its corresponding hex data
     //print('Manufacturer ID: $key');
     //print('Manufacturer Data (Adjusted Hex): $hexString');
   });
 }





}