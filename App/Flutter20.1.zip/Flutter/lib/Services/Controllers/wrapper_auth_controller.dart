
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:dnsolve/dnsolve.dart';
import 'package:drip/Services/Controllers/map_controller.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart';
import 'package:get/get.dart';

import '../check_cache.dart';
import 'helper_controller.dart';




class wrapperController extends GetxController {











}


