import 'package:drip/Services/Controllers/ble_scan_controller.dart';
import 'package:drip/Services/Controllers/wrapper_auth_controller.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class map_controller extends GetxController{
  bleScanController _bleScanController =  Get.find<bleScanController>();

  RxDouble Latitude = 0.0.obs;
  RxDouble Longitude = 0.0.obs;

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();


  }



  GeoPoint? droneMarkerLocation; // Track the existing drone marker's location.
  DateTime? _lastMapUpdateTime;
  final Duration mapUpdateInterval = Duration(milliseconds: 500);
  MapController mapController =  MapController(
    initMapWithUserPosition: UserTrackingOption(
      enableTracking: false, // Disable tracking
      unFollowUser: false,   // No auto-following of the user
    ),
  );
  List<GeoPoint> droneLocations = [];
  void updateDroneLocation(double latitude, double longitude) async {
    final now = DateTime.now();
    // Check if enough time has passed since the last update
    if (_lastMapUpdateTime == null || now.difference(_lastMapUpdateTime!) >= mapUpdateInterval) {
      _lastMapUpdateTime = now;
      if (droneMarkerLocation != null) {
        await mapController.removeMarker(droneMarkerLocation!);
      }

      // Update the existing marker's location
      droneMarkerLocation = GeoPoint(latitude: latitude, longitude: longitude);
      await mapController.changeLocation(droneMarkerLocation!);

      print("Map updated: Latitude $latitude, Longitude $longitude");
    }
  }


  Map<String, dynamic>? getDroneInfo(GeoPoint geoPoint) {

    if (droneMarkerLocation != null &&
        geoPoint.latitude == droneMarkerLocation!.latitude &&
        geoPoint.longitude == droneMarkerLocation!.longitude) {
       return {
        "latitude": Latitude,
        "longitude": Longitude,
      };// Return the drone's information


    }
    return null; // No matching drone found
  }


  Future<void> clearSharedPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear(); // This removes all keys and values.
    print("SharedPreferences cache cleared.");
  }


@override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
    _bleScanController.startScan();
  }


}