import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:drip/Services/Controllers/helper_controller.dart';
import 'package:drip/Services/Controllers/wrapper_auth_controller.dart';
import 'package:get/get.dart';

class dripLinkController extends GetxController{

 helperController _helper = new helperController();
  void parseDripLink(String dripLinkHex,   Uint8List dripLinkBytes) {
    // Convert hex string to bytes


    // Extract fields
    Uint8List validNotBeforeBytes = dripLinkBytes.sublist(0, 4);
    Uint8List validNotAfterBytes = dripLinkBytes.sublist(4, 8);
    Uint8List uavDetBytes = dripLinkBytes.sublist(8, 24);
    Uint8List uavPublicKeyBytes = dripLinkBytes.sublist(24, 56);
    Uint8List parentDetBytes = dripLinkBytes.sublist(56, 72);
    Uint8List parentSignatureBytes = dripLinkBytes.sublist(72, 136);

    // Convert fields to readable formats
    int validNotBefore = ByteData.sublistView(validNotBeforeBytes).getUint32(0, Endian.little);
    int validNotAfter = ByteData.sublistView(validNotAfterBytes).getUint32(0, Endian.little);
    String uavDetHex = _helper.hexEncode(uavDetBytes);
    String uavPublicKeyHex = _helper.hexEncode(uavPublicKeyBytes);
    String parentDetHex = _helper.hexEncode(parentDetBytes);
    String parentSignatureHex = _helper.hexEncode(parentSignatureBytes);

    print("Valid Not Before: $validNotBefore");
    print("Valid Not After: $validNotAfter");
    print("UAV DET: $uavDetHex");
    print("UAV Public Key: $uavPublicKeyHex");
    print("Parent DET: $parentDetHex");
    print("Parent Signature: $parentSignatureHex");
  }



 Future<String> authenticateDripLink(String dripLinkHex) async {
   try {
     final startTime = DateTime.now();



     // Parse the DRIP Link
     Uint8List dripLinkBytes = _helper.hexToBytes(dripLinkHex);
     const String hdaPublicKeyHex = "3e373f3064e6da5a1a3248df708ba95bf405d13b12a169fc5017c5cdeb33baed";

     // Extract fields from the DRIP Link
     Uint8List validNotBeforeBytes = dripLinkBytes.sublist(0, 4);
     Uint8List validNotAfterBytes = dripLinkBytes.sublist(4, 8);
     Uint8List uavDetBytes = dripLinkBytes.sublist(8, 24);
     Uint8List uavPublicKeyBytes = dripLinkBytes.sublist(24, 56);
     Uint8List parentDetBytes = dripLinkBytes.sublist(56, 72);
     Uint8List parentSignatureBytes = dripLinkBytes.sublist(72, 136);

     // Convert fields to readable formats
     int validNotBefore = ByteData.sublistView(validNotBeforeBytes).getUint32(0, Endian.little);
     int validNotAfter = ByteData.sublistView(validNotAfterBytes).getUint32(0, Endian.little);
     String uavDetHex = _helper.hexEncode(uavDetBytes);
     String uavPublicKeyHex = _helper.hexEncode(uavPublicKeyBytes);
     String parentDetHex = _helper.hexEncode(parentDetBytes);
     String parentSignatureHex = _helper.hexEncode(parentSignatureBytes);


     print("Parsed DRIP Link Fields:");
     print("Valid Not Before: $validNotBefore");
     print("Valid Not After: $validNotAfter");
     print("UAV DET: $uavDetHex");
     print("UAV Public Key: $uavPublicKeyHex");
     print("Parent DET: $parentDetHex");
     print("Parent Signature: $parentSignatureHex");

     // Step 1: Validate timestamps
     /*if (!validateTimestamps(validNotBefore, validNotAfter)) {
      return "Invalid timestamps in DRIP Link.";
    }*/


     print(" HDA Public Key: $hdaPublicKeyHex");

     // Step 3: Verify Parent Signature
     bool isParentSignatureValid = await verifyParentSignature(parentDetHex: parentDetHex,
         parentSignatureHex: parentSignatureHex,
         uavDetHex: uavDetHex,
         uavPublicKeyHex: uavPublicKeyHex,
         hdaPublicKeyHex: hdaPublicKeyHex,
         validNotAfter: validNotAfter,
         validNotBefore: validNotBefore

     );
     if (!isParentSignatureValid) {
       return "Parent Signature verification failed.";
     }

     print("Parent Signature verified successfully.");
     final elapsedTime = DateTime.now().difference(startTime).inMilliseconds;
     print("Time taken to authenticate received DRIP Link: ${elapsedTime}ms");


     // Step 4: Authenticate the UAV
     /* bool isUAVAuthenticated = await authenticateUAV(
      uavDetHex,
      parentSignatureHex, // Wrapper signature is generally needed for full UAV authentication
      uavPublicKeyHex,
    );
    if (!isUAVAuthenticated) {
      return "UAV authentication failed.";
    }

    print("UAV authentication successful.");
*/
     // If all steps pass
     return "DRIP Link authenticated successfully.";
   } catch (e) {
     print("Error during DRIP Link authentication: $e");
     return "Error during DRIP Link authentication: $e";
   }
 }




 Future<bool> verifyParentSignature({
   required String uavDetHex,
   required String parentDetHex,
   required String uavPublicKeyHex,
   required String parentSignatureHex,
   required String hdaPublicKeyHex,
   required int validNotBefore,
   required int validNotAfter,
 }) async {
   try {
     // Convert hex strings to bytes
     Uint8List uavDetBytes = _helper.hexToBytes(uavDetHex);
     Uint8List parentDetBytes = _helper.hexToBytes(parentDetHex);
     Uint8List uavPublicKeyBytes = _helper.hexToBytes(uavPublicKeyHex);
     Uint8List parentSignatureBytes = _helper.hexToBytes(parentSignatureHex);
     Uint8List hdaPublicKeyBytes = _helper.hexToBytes(hdaPublicKeyHex);

     // Concatenate data to be verified (HDA DET + UAV DET + UAV Public Key + Validity Periods)
     Uint8List validityPeriodBytes = Uint8List(8)
       ..buffer.asByteData().setUint32(0, validNotBefore, Endian.little)
       ..buffer.asByteData().setUint32(4, validNotAfter, Endian.little);

     Uint8List dataToVerify = Uint8List.fromList(
       parentDetBytes + uavDetBytes + uavPublicKeyBytes + validityPeriodBytes,
     );

     // Verify the signature
     final publicKey = SimplePublicKey(hdaPublicKeyBytes, type: KeyPairType.ed25519);
     final signature = Signature(parentSignatureBytes, publicKey: publicKey);

     bool isValid = await Ed25519().verify(dataToVerify, signature: signature);

     print(isValid ? "Parent Signature is valid." : "Parent Signature is invalid.");
     return isValid;
   } catch (e) {
     print("Error verifying Parent Signature: $e");
     return false;
   }
 }




 String extractPublicKeyFromDnsResponse(String response) {
   // Parse the public key from the DNS TXT response
   final regex = RegExp(r'pubkey=([0-9a-fA-F]+)');
   final match = regex.firstMatch(response);
   if (match != null) {
     return match.group(1) ?? "Invalid response format.";
   } else {
     return "Public key not found in response.";
   }
 }









}