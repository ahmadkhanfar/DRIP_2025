import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class PublicKeyCache {
  static const String _cacheKey = "publicKeyCache";

  // Load the cache from persistent storage
  static Future<Map<String, String>> loadCache() async {
    final prefs = await SharedPreferences.getInstance();
    final cacheString = prefs.getString(_cacheKey);
    if (cacheString != null) {
      return Map<String, String>.from(jsonDecode(cacheString));
    }
    return {};
  }

  // Save the cache to persistent storage
  static Future<void> saveCache(Map<String, String> cache) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_cacheKey, jsonEncode(cache));
  }
}

