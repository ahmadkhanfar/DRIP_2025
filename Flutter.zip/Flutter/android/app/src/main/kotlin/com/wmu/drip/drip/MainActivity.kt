package com.wmu.drip.drip
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.content.Context
import android.os.BatteryManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.BluetoothLeScanner
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.content.Intent
import android.content.IntentFilter
class MainActivity : FlutterActivity() {
    private val CHANNEL = "ble/raw_data"
    private val BATTERY_CHANNEL = "battery_info"
    private var bluetoothLeScanner: BluetoothLeScanner? = null
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "startScanning" -> {
                    startBLEScan(result)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, BATTERY_CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "getBatteryStats") {
                val batteryStats = getBatteryStats()
                result.success(batteryStats)
            } else {
                result.notImplemented()
            }
        }

    }


    private fun getBatteryStats(): Map<String, Any> {
        val batteryStats = mutableMapOf<String, Any>()

        // Registering a receiver to get battery information
        val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus: Intent? = registerReceiver(null, intentFilter)

        batteryStatus?.let { intent ->
            // Retrieve battery voltage
            val voltage: Int = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
            if (voltage != -1) {
                batteryStats["voltage"] = voltage / 1000.0 // Convert mV to V
            }

            // Retrieve battery current (requires API level 21+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val batteryManager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val currentNow: Int = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
                if (currentNow != Int.MIN_VALUE) {
                    batteryStats["currentNow"] = currentNow // Convert µA to mA
                }


                    val currentAvg: Int = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE)
                    if (currentAvg != Int.MIN_VALUE) {
                        batteryStats["currentAvg"] = currentAvg // Convert µA to mA
                    }

            }
        }

        return batteryStats
    }

    private fun startBLEScan(result: MethodChannel.Result) {
        if (bluetoothAdapter == null || !bluetoothAdapter!!.isEnabled) {
            result.error("UNAVAILABLE", "Bluetooth not available or disabled", null)
            return
        }

        bluetoothLeScanner = bluetoothAdapter!!.bluetoothLeScanner

        if (bluetoothLeScanner == null) {
            result.error("UNAVAILABLE", "Bluetooth LE Scanner not available", null)
            return
        }



        val scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val scanRecord = result.scanRecord
                val rawData = scanRecord?.bytes
                val deviceName = result.device.name ?: "Unknown Device"
                val deviceAddress = result.device.address

                // Extract Manufacturer Data
                val manufacturerData = scanRecord?.manufacturerSpecificData
                val manufacturerMap = mutableMapOf<Int, String>()
                if (manufacturerData != null) {
                    for (i in 0 until manufacturerData.size()) {
                        manufacturerMap[manufacturerData.keyAt(i)] = manufacturerData.valueAt(i)?.toHexString() ?: ""
                    }
                }

                // Extract Service Data
                val serviceData = scanRecord?.serviceData
                val serviceDataMap = mutableMapOf<String, String>()
                serviceData?.forEach { (uuid, data) ->
                    serviceDataMap[uuid.toString()] = data?.toHexString() ?: ""
                }

                // Extract Service UUIDs
                val serviceUuids = scanRecord?.serviceUuids?.map { it.uuid.toString() } ?: listOf()

                val dataMap = mapOf(
                    "deviceName" to deviceName,
                    "deviceAddress" to deviceAddress,
                    "rawData" to rawData?.toHexString(),
                    "manufacturerData" to manufacturerMap,
                    "serviceData" to serviceDataMap,
                    "serviceUuids" to serviceUuids
                )

                // Send data to Flutter
                Handler(Looper.getMainLooper()).post {
                    flutterEngine?.dartExecutor?.binaryMessenger?.let { messenger ->
                        MethodChannel(messenger, CHANNEL).invokeMethod("onScanResult", dataMap)
                    }
                }
            }



            private fun ByteArray.toHexString(): String {
                return joinToString("") { "%02x".format(it) }
            }


            override fun onScanFailed(errorCode: Int) {
                Log.e("BLE_SCAN", "Scan failed with error: $errorCode")
            }
        }

        bluetoothLeScanner!!.startScan(scanCallback)
        result.success("Scanning started")
    }
}
