import 'package:drip/Services/Controllers/ble_scan_controller.dart';
import 'package:drip/Services/Controllers/drip_link_auth_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';

import '../Services/Controllers/map_controller.dart';
import '../Services/Controllers/open_drone_id_manager.dart';

void showDroneInfoBottomSheet(BuildContext context, GeoPoint geo) {
  final mapController = Get.find<map_controller>();



  showModalBottomSheet(
    context: context,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (BuildContext context) {
      // Retrieve the current drone ID

      final droneId = detAuthenticationCache.entries.elementAt(0).key; // Single Drone for Now


      if (droneId.isEmpty) {
        print("No drone ID available.");

      }

      final dripDetails = dripLinkCache[droneId];
      final isAuthenticated = detAuthenticationCache[droneId] ?? false;
      final parentDet = dripDetails?["parentDet"] ?? "Unknown";
      final craftLocation = OpenDroneIdDataManager.aircraft.entries.elementAt(0).value.location.value;
      print("AIRCRA");
      print(OpenDroneIdDataManager.aircraft.entries);
      final lat = craftLocation?.latitude.value.toStringAsFixed(6) ?? "Unknown";
      final lon = craftLocation?.longitude.value.toStringAsFixed(6) ?? "Unknown";
      List<int> wrapper = OpenDroneIdDataManager.aircraft.entries.elementAt(0).value.authDataCombined;
      String hexString = wrapper.map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase()).join(' ');

      return Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Drone Information",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            //Get.find<bleScanController>().droneDet
            _infoRow("Drone ID:", droneId),
            _infoRow("Parent DET: ", parentDet),
            _infoRow("is Authenticated?: ", isAuthenticated.toString()),
             _infoRow("Latitude", geo.latitude.toString()),
            //mapController.Longitude.value.toStringAsFixed(6)
            _infoRow("Longitude", geo.longitude.toString()),
            SizedBox(height: 16),
            _infoScrollableRow(
              "Received AUTH",hexString

            ),




            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the bottom sheet
              },
              child: Text("Close"),
            ),
          ],
        ),
      );
    },
  );
}

Widget _infoScrollableRow(String label, String value) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 4.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontWeight: FontWeight.w500)),
        SizedBox(height: 4),
        Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(6),
          ),
          padding: EdgeInsets.all(8),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: SelectableText(
              value,
              style: TextStyle(color: Colors.grey[700], fontFamily: 'monospace'),
            ),
          ),
        ),
      ],
    ),
  );
}
Widget _infoVerticalRow(String label, List<int> bytes) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 4.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontWeight: FontWeight.w500)),
        SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: bytes.asMap().entries.map((entry) {
              final index = entry.key;
              final value = entry.value;
              return Text("[$index]  0x${value.toRadixString(16).padLeft(2, '0').toUpperCase()}");
            }).toList(),
          ),
        ),
      ],
    ),
  );
}

Widget _infoRow(String label, String value) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 4.0),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontWeight: FontWeight.w500)),
        Text(value, style: TextStyle(color: Colors.grey[700])),
      ],
    ),
  );
}
