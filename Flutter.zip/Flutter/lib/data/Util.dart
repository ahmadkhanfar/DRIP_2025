import 'package:get/get.dart';

/// Represents the difference between two sets: added and removed items
class SetDifference<T> {
  final Set<T> added;
  final Set<T> removed;

  SetDifference(Set<T> newSet, Set<T> oldSet)
      : added = _difference(newSet, oldSet),
        removed = _difference(oldSet, newSet);

  static Set<T> _difference<T>(Set<T> set, Set<T> other) {
    return set.difference(other);
  }
}

/// Observer-like class to detect changes in a reactive set
class DiffObserver<T> extends GetxController {
  RxSet<T> lastSet = <T>{}.obs;

  /// Call this method when the observed set changes
  void onChanged(Set<T> newSet) {
    final difference = SetDifference(newSet, lastSet); // No need for Util.SetDifference

    if (difference.added.isNotEmpty) {
      onAdded(difference.added);
    }
    if (difference.removed.isNotEmpty) {
      onRemoved(difference.removed);
    }

    lastSet.assignAll(newSet);
  }

  /// Override this method to handle added items
  void onAdded(Set<T> added) {}

  /// Override this method to handle removed items
  void onRemoved(Set<T> removed) {}
}
