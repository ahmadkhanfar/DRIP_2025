import 'package:drip/data/MessageData.dart';
import 'package:get/get.dart';

enum OperatorLocationType {
  TakeOff,
  Dynamic, // Live GNSS Location
  Fixed,   // Fixed Location
  Invalid,
}

enum ClassificationType {
  Undeclared,
  EU, // European Union
}

enum Category {
  Undeclared,
  EU_Open,
  EU_Specific,
  EU_Certified,
}

enum ClassValue {
  Undeclared,
  EU_Class_0,
  EU_Class_1,
  EU_Class_2,
  EU_Class_3,
  EU_Class_4,
  EU_Class_5,
  EU_Class_6,
}

class SystemData  extends MessageData{
  Rx<OperatorLocationType> operatorLocationType = OperatorLocationType.Invalid.obs;
  Rx<ClassificationType> classificationType = ClassificationType.Undeclared.obs;
  RxDouble operatorLatitude = 0.0.obs;
  RxDouble operatorLongitude = 0.0.obs;
  RxInt areaCount = 0.obs;
  RxInt areaRadius = 0.obs;
  RxDouble areaCeiling = (-1000.0).obs;
  RxDouble areaFloor = (-1000.0).obs;
  Rx<Category> category = Category.Undeclared.obs;
  Rx<ClassValue> classValue = ClassValue.Undeclared.obs;
  RxDouble operatorAltitudeGeo = (-1000.0).obs;
  RxInt systemTimestamp = 0.obs;

  SystemData() {
    operatorLocationType.value = OperatorLocationType.Invalid;
    classificationType.value = ClassificationType.Undeclared;
    operatorLatitude.value = 0.0;
    operatorLongitude.value = 0.0;
    areaCount.value = 0;
    areaRadius.value = 0;
    areaCeiling.value = -1000.0;
    areaFloor.value = -1000.0;
    category.value = Category.Undeclared;
    classValue.value = ClassValue.Undeclared;
    operatorAltitudeGeo.value = -1000.0;
    systemTimestamp.value = 0;
  }

  void setOperatorLocationType(int type) {
    switch (type) {
      case 0:
        operatorLocationType.value = OperatorLocationType.TakeOff;
        break;
      case 1:
        operatorLocationType.value = OperatorLocationType.Dynamic;
        break;
      case 2:
        operatorLocationType.value = OperatorLocationType.Fixed;
        break;
      default:
        operatorLocationType.value = OperatorLocationType.Invalid;
        break;
    }
  }

  void setClassificationType(int type) {
    classificationType.value = type == 1 ? ClassificationType.EU : ClassificationType.Undeclared;
  }

  void setOperatorLatitude(double latitude) {
    if (latitude < -90 || latitude > 90) {
      operatorLatitude.value = 0.0;
      operatorLongitude.value = 0.0;
    } else {
      operatorLatitude.value = latitude;
    }
  }

   double getOperatorLatitude() { return operatorLatitude.value; }

  void setOperatorLongitude(double longitude) {
    if (longitude < -180 || longitude > 180) {
      operatorLatitude.value = 0.0;
      operatorLongitude.value = 0.0;
    } else {
      operatorLongitude.value = longitude;
    }
  }



  void setAreaCount(int count) => areaCount.value = count;
  void setAreaRadius(int radius) => areaRadius.value = radius;
  void setAreaCeiling(double ceiling) => areaCeiling.value = ceiling;
  void setAreaFloor(double floor) => areaFloor.value = floor;
  void setOperatorAltitudeGeo(double altitude) => operatorAltitudeGeo.value = altitude;
  void setSystemTimestamp(int timestamp) => systemTimestamp.value = timestamp;

  void setCategory(int value) {
    if (classificationType.value == ClassificationType.EU) {
      switch (value) {
        case 1:
          category.value = Category.EU_Open;
          break;
        case 2:
          category.value = Category.EU_Specific;
          break;
        case 3:
          category.value = Category.EU_Certified;
          break;
        default:
          category.value = Category.Undeclared;
          break;
      }
    } else {
      category.value = Category.Undeclared;
    }
  }

  void setClassValue(int value) {
    if (classificationType.value == ClassificationType.EU) {
      switch (value) {
        case 1:
          classValue.value = ClassValue.EU_Class_0;
          break;
        case 2:
          classValue.value = ClassValue.EU_Class_1;
          break;
        case 3:
          classValue.value = ClassValue.EU_Class_2;
          break;
        case 4:
          classValue.value = ClassValue.EU_Class_3;
          break;
        case 5:
          classValue.value = ClassValue.EU_Class_4;
          break;
        case 6:
          classValue.value = ClassValue.EU_Class_5;
          break;
        case 7:
          classValue.value = ClassValue.EU_Class_6;
          break;
        default:
          classValue.value = ClassValue.Undeclared;
          break;
      }
    } else {
      classValue.value = ClassValue.Undeclared;
    }
  }
}
