import 'package:get/get.dart';
import 'dart:convert';

import 'MessageData.dart';

class Connection extends MessageData {
  RxInt rssi = 0.obs;
  RxString transportType = ''.obs;
  RxString macAddress = ''.obs;
  RxInt lastSeen = 0.obs;
  RxInt firstSeen = 0.obs;
  RxInt msgDelta = 0.obs;

  Connection({
    int? rssi,
    String? transportType,
    String? macAddress,
    int? lastSeen,
    int? firstSeen,
    int? msgDelta,
  }) {
    this.rssi.value = rssi ?? 0;
    this.transportType.value = transportType ?? "";
    this.macAddress.value = macAddress ?? "";
    this.lastSeen.value = lastSeen ?? 0;
    this.firstSeen.value = firstSeen ?? 0;
    this.msgDelta.value = msgDelta ?? 0;
  }

  /// **Convert `msgDelta` to a formatted string**
  String getMsgDeltaAsString() {
    if (msgDelta.value < 1000) {
      return "$msgDelta ms";
    } else {
      double seconds = msgDelta.value / 1000.0;
      return "${seconds.toStringAsFixed(1)} s";
    }
  }

  /// **Factory method to create a Connection object from JSON**
  factory Connection.fromJson(Map<String, dynamic> json) {
    return Connection(
      rssi: json['rssi'],
      transportType: json['transportType'],
      macAddress: json['macAddress'],
      lastSeen: json['lastSeen'],
      firstSeen: json['firstSeen'],
      msgDelta: json['msgDelta'],
    );
  }

  /// **Convert the Connection object to JSON**
  Map<String, dynamic> toJson() {
    return {
      'rssi': rssi.value,
      'transportType': transportType.value,
      'macAddress': macAddress.value,
      'lastSeen': lastSeen.value,
      'firstSeen': firstSeen.value,
      'msgDelta': msgDelta.value,
    };
  }

  @override
  String toString() {
    return jsonEncode(toJson());
  }
}
