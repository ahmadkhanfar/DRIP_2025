import 'dart:convert';
import 'dart:typed_data';
import 'package:drip/data/MessageData.dart';
import 'package:get/get.dart';

import '../Constants/Constants.dart';


/// **Enum for UA Type (Drone Type)**
enum UaTypeEnum {
  None,
  Aeroplane,
  Helicopter_or_Multirotor,
  Gyroplane,
  Hybrid_Lift,
  Ornithopter,
  Glider,
  Kite,
  Free_balloon,
  Captive_balloon,
  Airship,
  Free_fall_parachute,
  Rocket,
  Tethered_powered_aircraft,
  Ground_obstacle,
  Other;

  /// **Convert integer to Enum**
  static UaTypeEnum fromInt(int value) {
    return UaTypeEnum.values[value.clamp(0, UaTypeEnum.values.length - 1)];
  }
}


/// **Enum for ID Type**
enum IdTypeEnum {
  None,
  Serial_Number,
  CAA_Registration_ID,
  UTM_Assigned_ID,
  Specific_Session_ID;

  /// **Convert integer to Enum**
  static IdTypeEnum fromInt(int value) {
    return IdTypeEnum.values[value.clamp(0, IdTypeEnum.values.length - 1)];
  }
}



class Identification  extends MessageData{


  UaTypeEnum uaType = UaTypeEnum.None;
  IdTypeEnum idType = IdTypeEnum.None;
  List<int> uasId = <int>[];

  Identification({
    UaTypeEnum? uaType,
    IdTypeEnum? idType,
    Uint8List? uasId,
  }) {
    this.uaType = uaType ?? UaTypeEnum.None;
    this.idType = idType ?? IdTypeEnum.None;
    this.uasId.assignAll(uasId ?? Uint8List(0));
  }




  /// **Factory method to parse bytes into Identification object**
  factory Identification.fromBytes(Uint8List data) {
    int uaTypeValue = data[0] & 0xFF;
    int idTypeValue = data[1] & 0xFF;
    Uint8List uasIdBytes = data.sublist(2);

    return Identification(
      uaType: UaTypeEnum.fromInt(uaTypeValue),
      idType: IdTypeEnum.fromInt(idTypeValue),
      uasId: uasIdBytes,
    );
  }

  /// **Get UAS ID as a human-readable string**

  /// **Convert to JSON**
  Map<String, dynamic> toJson() {
    return {
      "uaType": uaType.index,
      "idType": idType.index,
      "uasId": getUasIdAsString(),
    };
  }

  // Getter for uaType
  void setUaType(int uaTypeValue) {
    switch (uaTypeValue) {
      case 1:
        uaType = UaTypeEnum.Aeroplane;
        break;
      case 2:
        uaType = UaTypeEnum.Helicopter_or_Multirotor;
        break;
      case 3:
        uaType = UaTypeEnum.Gyroplane;
        break;
      case 4:
        uaType = UaTypeEnum.Hybrid_Lift;
        break;
      case 5:
        uaType = UaTypeEnum.Ornithopter;
        break;
      case 6:
        uaType = UaTypeEnum.Glider;
        break;
      case 7:
        uaType = UaTypeEnum.Kite;
        break;
      case 8:
        uaType = UaTypeEnum.Free_balloon;
        break;
      case 9:
        uaType = UaTypeEnum.Captive_balloon;
        break;
      case 10:
        uaType = UaTypeEnum.Airship;
        break;
      case 11:
        uaType = UaTypeEnum.Free_fall_parachute;
        break;
      case 12:
        uaType = UaTypeEnum.Rocket;
        break;
      case 13:
        uaType = UaTypeEnum.Tethered_powered_aircraft;
        break;
      case 14:
        uaType = UaTypeEnum.Ground_obstacle;
        break;
      case 15:
        uaType = UaTypeEnum.Other;
        break;
      default:
        uaType = UaTypeEnum.None;
        break;
    }
  }

  UaTypeEnum get uaTypeValue => uaType;

  // Getter for idType
  IdTypeEnum get getIdType => idType;

  // Setter for idType
  void setIdType(int idTypeValue) {
    switch (idTypeValue) {
      case 1:
        idType = IdTypeEnum.Serial_Number;
        break;
      case 2:
        idType = IdTypeEnum.CAA_Registration_ID;
        break;
      case 3:
        idType = IdTypeEnum.UTM_Assigned_ID;
        break;
      case 4:
        idType = IdTypeEnum.Specific_Session_ID;
        break;
      default:
        idType = IdTypeEnum.None;
        break;
    }
  }


  // Setter for uasId with validation based on MAX_ID_BYTE_SIZE
  void setUasId(List<int> id) {
    if (id.length <= Constants.MAX_ID_BYTE_SIZE) {
      uasId = id;
      print(uasId);
    }else{
      print("unable to add UAS ID");
    }


  }


  // Getter for uasId
  List<int> get getUasId => uasId;

  // Method to get uasId as a string based on idType
  String getUasIdAsString() {
    if (uasId.isNotEmpty) {
      if (idType == IdTypeEnum.Serial_Number || idType == IdTypeEnum.CAA_Registration_ID) {
        for (var c in uasId) {
          if (c <= 31 || c >= 127) {
            return "Invalid ID String";
          }
        }
        return String.fromCharCodes(uasId);
      } else if (idType == IdTypeEnum.UTM_Assigned_ID || idType == IdTypeEnum.Specific_Session_ID) {
        StringBuffer sb = StringBuffer();
        sb.write("0x");
        for (var b in uasId) {
          sb.write(b.toRadixString(16).padLeft(2, '0').toUpperCase());
        }
        print("UAS ID AFTER");
        print(sb.toString());
        return sb.toString();

      }
    }else{
      //print ("EMPTY US ID");
    }
    return "";
  }








  @override
  String toString() => jsonEncode(toJson());
}



