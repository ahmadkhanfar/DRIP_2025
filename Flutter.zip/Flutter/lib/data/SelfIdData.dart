import 'package:drip/data/MessageData.dart';
import 'package:get/get.dart';
import '../Constants/Constants.dart';
enum DescriptionType {
  Text,
  Emergency,
  ExtendedStatus,
  Invalid
}

class SelfIdData extends MessageData {
  Rx<DescriptionType> descriptionType = DescriptionType.Text.obs;
  RxList<int> operationDescription = <int>[].obs; // Using List<int> instead of byte array

  SelfIdData() {
    descriptionType.value = DescriptionType.Text;
    operationDescription.value = [];
  }

  void setDescriptionType(int type) {
    switch (type) {
      case 0:
        descriptionType.value = DescriptionType.Text;
        break;
      case 1:
        descriptionType.value = DescriptionType.Emergency;
        break;
      case 2:
        descriptionType.value = DescriptionType.ExtendedStatus;
        break;
      default:
        descriptionType.value = DescriptionType.Invalid;
        break;
    }
  }

  void setOperationDescription(List<int> description) {
    if (description.length <= Constants.MAX_STRING_BYTE_SIZE) {
      operationDescription.value = description;
    }
  }

  String getOperationDescriptionAsString() {
    if (operationDescription.isNotEmpty) {
      for (var c in operationDescription) {
        if ((c <= 31 || c >= 127) && c != 0) {
          return "Invalid String";
        }
      }
      return String.fromCharCodes(operationDescription);
    }
    return "";
  }
}
