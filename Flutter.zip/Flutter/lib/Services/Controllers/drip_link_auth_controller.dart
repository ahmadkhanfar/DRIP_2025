import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:drip/Services/Controllers/helper_controller.dart';
import 'package:drip/Services/Controllers/wrapper_auth_controller.dart';
import 'package:get/get.dart';

class dripLinkController extends GetxController{

  helperController _helper = Get.find<helperController>();
  /*void parseDripLink(String dripLinkHex,   Uint8List dripLinkBytes) {
    // Convert hex string to bytes


    // Extract fields
    Uint8List validNotBeforeBytes = dripLinkBytes.sublist(0, 4);
    Uint8List validNotAfterBytes = dripLinkBytes.sublist(4, 8);
    Uint8List uavDetBytes = dripLinkBytes.sublist(8, 24);
    Uint8List uavPublicKeyBytes = dripLinkBytes.sublist(24, 56);
    Uint8List parentDetBytes = dripLinkBytes.sublist(56, 72);
    Uint8List parentSignatureBytes = dripLinkBytes.sublist(72, 136);

    // Convert fields to readable formats
    int validNotBefore = ByteData.sublistView(validNotBeforeBytes).getUint32(0, Endian.little);
    int validNotAfter = ByteData.sublistView(validNotAfterBytes).getUint32(0, Endian.little);
    String uavDetHex = _helper.hexEncode(uavDetBytes);
    String uavPublicKeyHex = _helper.hexEncode(uavPublicKeyBytes);
    String parentDetHex = _helper.hexEncode(parentDetBytes);
    String parentSignatureHex = _helper.hexEncode(parentSignatureBytes);

    print("Valid Not Before: $validNotBefore");
    print("Valid Not After: $validNotAfter");
    print("UAV DET: $uavDetHex");
    print("UAV Public Key: $uavPublicKeyHex");
    print("Parent DET: $parentDetHex");
    print("Parent Signature: $parentSignatureHex");
  }*/










}