import 'package:drip/Services/Controllers/ble_scan_controller.dart';
import 'package:drip/Services/Controllers/open_drone_id_manager.dart';
import 'package:drip/Services/Controllers/wrapper_auth_controller.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../data/AircraftObject.dart';

class map_controller extends GetxController{

  bleScanController _bleScanController =  Get.find<bleScanController>();
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }

  GeoPoint? droneMarkerLocation; // Track the existing drone marker's location.
  DateTime? _lastMapUpdateTime;
  final Duration mapUpdateInterval = Duration(milliseconds: 500);
  MapController mapController =  MapController(
    initMapWithUserPosition: UserTrackingOption(
      enableTracking: false, // Disable tracking
      unFollowUser: false,   // No auto-following of the user
    ),
  );

  Map<int, AircraftObject> localCraft = {};

  // NEW CODE

  String? getDroneIdByGeoPoint(GeoPoint tappedPoint) {
    for (var entry in localCraft.entries) {
      final drone = entry.value;
      final location = drone.location.value!;
      final lat = location.latitude.value;
      final lon = location.longitude.value;

      if ((lat - tappedPoint.latitude).abs() < 0.0001 &&
          (lon - tappedPoint.longitude).abs() < 0.0001) {
        return entry.key.toString(); // return the drone's ID
      }
    }
    return null;
  }

  // Method to show all drones on the map
  void showAllDronesOnMap() {
    // Iterate over all aircraft in the map (aircraft[macAddressLong])
    OpenDroneIdDataManager.aircraft.forEach((macAddressLong, aircraftObject) {
      // Get the current location of the drone (e.g., from the AircraftObject)
      localCraft[macAddressLong] = aircraftObject;
      GeoPoint location = GeoPoint(latitude: 0, longitude: 0);
      if(aircraftObject.location.value != null ){
        print("NULL LOCATION FOR");
        print(macAddressLong);

      }else{
         location = GeoPoint(latitude: aircraftObject.location.value!.latitude.value, longitude: aircraftObject.location.value!.longitude.value);
      }
    // Assuming location is a GeoPoint

      // Add a marker on the map at the drone's location
      addMarkerForDrone(location);
    });
  }


  // Method to add a marker on the map for a specific drone
  void addMarkerForDrone(GeoPoint location) {
    // Add marker at the given location (latitude, longitude)
    mapController.addMarker(location);  // `addMarker` is a method from flutter_osm_plugin
  }

  /*Map<String, dynamic>? getDroneInfo(GeoPoint geoPoint) {

    if (droneMarkerLocation != null &&
        geoPoint.latitude == droneMarkerLocation!.latitude &&
        geoPoint.longitude == droneMarkerLocation!.longitude) {
       return {
        "latitude": Latitude,
        "longitude": Longitude,
      };// Return the drone's information



    return null; // No matching drone found
  }*/


  /*void updateDroneLocation(double latitude, double longitude) async {
    print("updated drone");

    print(latitude);
    print(longitude);
    final now = DateTime.now();
    // Check if enough time has passed since the last update
    if (_lastMapUpdateTime == null || now.difference(_lastMapUpdateTime!) >= mapUpdateInterval) {
      _lastMapUpdateTime = now;
      if (droneMarkerLocation != null) {
        await mapController.removeMarker(droneMarkerLocation!);
      }

      // Update the existing marker's location
      droneMarkerLocation = GeoPoint(latitude: latitude, longitude: longitude);
      await mapController.changeLocation(droneMarkerLocation!);

      print("Map updated: Latitude $latitude, Longitude $longitude");
    }
  }*/

  void updateDroneLocation(int droneId, double latitude, double longitude) async {

    print("UPDATING DRONE LOCATION");
    final now = DateTime.now();
    if (_lastMapUpdateTime == null || now.difference(_lastMapUpdateTime!) >= mapUpdateInterval) {
      _lastMapUpdateTime = now;
      if (localCraft.containsKey(droneId)) {
        print("DRON FOUND IN UPDATING");
        final existing = localCraft[droneId]!;
        existing.location.value!.latitude.value = latitude;
        existing.location.value!.longitude.value = longitude;
      }

      await mapController.setStaticPosition([GeoPoint(latitude: latitude, longitude: longitude)], droneId.toString());
       // Notify GetBuilder to rebuild the map with new positions
      print("Drone $droneId location updated to: $latitude, $longitude");
    }
  }








  Future<void> clearSharedPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear(); // This removes all keys and values.
    print("SharedPreferences cache cleared.");
  }

@override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
    _bleScanController.startScan();

  }


}