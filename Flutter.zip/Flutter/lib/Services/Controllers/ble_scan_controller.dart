import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:dnsolve/dnsolve.dart';
import 'package:drip/Services/Controllers/drip_link_auth_controller.dart';
import 'package:drip/Services/Controllers/open_drone_id_manager.dart';
import 'package:drip/Services/Controllers/wrapper_auth_controller.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:async/async.dart';

import '../../Constants/log_message_entry.dart';
import '../../data/AircraftObject.dart';
import '../../data/LocationData.dart';
import '../check_cache.dart';
import 'helper_controller.dart';
import 'map_controller.dart';
import 'open_drone_id_parser.dart';

enum SAMType {
  None,
  Link,
  Wrapper,
  Manifest, // we will not be using
  Frame; // we will not be using

  // Get the corresponding enum value from an integer ID
  static SAMType? fromId(int id) {
    switch (id) {
      case 0:
        return SAMType.None;
      case 1:
        return SAMType.Link;
      case 2:
        return SAMType.Wrapper;
      case 3:
        return SAMType.Manifest;
      case 4:
        return SAMType.Frame;
      default:
        return null; // Return null for unknown IDs
    }
  }

  // Get the integer ID from the enum value
  int get id {
    switch (this) {
      case SAMType.None: // We can use this as a flag ("SOME IS NOT USING THE DRONE IF DRIP WAS A STANDARD").
        return 0;
      case SAMType.Link:
        return 1;
      case SAMType.Wrapper:
        return 2;
      case SAMType.Manifest:
        return 3;
      case SAMType.Frame:
        return 4;
    }
  }
}

class bleScanController extends GetxController {
  // Create a LogMessageEntry instance
  LogMessageEntry logMessageEntry = LogMessageEntry();



  // Define the 128-bit Service UUID
  static  Guid serviceUuid = Guid("0000fffa-0000-1000-8000-00805f9b34fb"); // OpenDroneId Service UUID

  final Uint8List openDroneIdAdCode = Uint8List.fromList([0x0D]);
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    requestPermissions();


  }

  DateTime lastProcessed = DateTime.fromMillisecondsSinceEpoch(0);

  void startScan() {
    FlutterBluePlus.startScan(continuousUpdates: true).then((_) {

    });

    FlutterBluePlus.scanResults.listen((results) async {
      DateTime now = DateTime.now();
      if (now.difference(lastProcessed).inMilliseconds < 1000) {
        // Skip this batch of results
        return;
      }
      lastProcessed = now; // Update timestamp

      fetchBatteryStats();
      for (ScanResult result in results) {
          result.advertisementData.serviceData.forEach((uuid, data) async {

            print (Guid(uuid.toString()));
            print(uuid);
            // Parse the message data using OpenDroneIdParser
            Uint8List messageData = Uint8List.fromList(data);
            if(data[0] == openDroneIdAdCode[0]){
              print("Drone found");
              await parseAndLogDroneData(messageData, result);
            }

          });


      }
    });
  }


  /*void parseAndLogDroneData(Uint8List messageData) {
    print("Parsing Drone Data...");


    // Pass the message data to the OpenDroneIdParser for parsing
// Pass the message data to the OpenDroneIdParser for parsing

    OpenDroneIdDataManager  idManage = OpenDroneIdDataManager((AircraftObject object) {
      // Your logic here to handle the new aircraft
    });
    var parsedData = OpenDroneIdParser.parseData(messageData, 2, DateTime.now().millisecondsSinceEpoch, logMessageEntry, receiverLocation);
    //var rec = idManage.receiveData(23, "macAddress", 123, 0, parsedData!, logMessageEntry, "BT5");
    Message<Payload> payload = parsedData!;
    print(payload.payload);
    print(payload.header);
    print(messageData);




    // Log the parsed data and process it based on its type
    if (parsedData != null) {
      print("Parsed Drone Data: ${parsedData.payload.toString()}");
      print(parsedData.header);
      if (parsedData.payload is SystemMsg){
        print("system found");
        SystemMsg sys = parsedData.payload as SystemMsg;
        print(sys.latitude);
        print(sys.longitude);
        Get.find<map_controller>().updateDroneLocation(sys.latitude, sys.longitude);
      }
      if(parsedData.payload is Location){
        print("location found");


        Location location = parsedData.payload as Location;
        print(location.latitude);
        Get.find<map_controller>().updateDroneLocation(location.latitude, location.longitude);
      }


    } else {
      print("Failed to parse the received data.");
    }
  }*/



  Future<void> parseAndLogDroneData(Uint8List messageData, ScanResult result ) async {
    print("Parsing Drone Data...");
    OpenDroneIdDataManager manager = OpenDroneIdDataManager();
    await manager.receiveDataBluetooth(messageData, result, logMessageEntry, "BT5");
  }

  static const MethodChannel batteryChannel = MethodChannel('battery_info');


  Future<void> fetchBatteryStats() async {
    try {
      final batteryStats = await batteryChannel.invokeMethod<Map<dynamic, dynamic>>('getBatteryStats');
      if (batteryStats != null) {
        double voltage = batteryStats['voltage'];
        int currentNow = batteryStats['currentNow'];
        int currentAvg = batteryStats['currentAvg'];

        print(" Voltage: ${voltage.toStringAsFixed(2)} V");
        print(" Current Draw: ${currentNow.toStringAsFixed(2)} mA");
        print(" Current AVG Draw: ${currentAvg.toStringAsFixed(2)} mA");
      } else {
        print(" Failed to fetch battery stats.");
      }
    } on PlatformException catch (e) {
      print("⚠️ Error fetching battery stats: ${e.message}");
    }
  }

  Future<void> requestPermissions() async {
    await [
      Permission.bluetooth,
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.location,
    ].request();
  }


}


