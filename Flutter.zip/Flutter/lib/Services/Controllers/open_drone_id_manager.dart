import 'dart:core';
import 'dart:isolate';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';
import 'package:dnsolve/dnsolve.dart';
import 'package:drip/Services/Controllers/map_controller.dart';
import 'package:drip/Services/Controllers/open_drone_id_parser.dart';
import 'package:drip/Services/Controllers/open_drone_id_parser.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'dart:convert';
import 'dart:async';

import '../../Constants/Constants.dart';
import '../../Constants/log_message_entry.dart';
import '../../data/AircraftObject.dart';
import '../../data/AuthenticationData.dart';
import '../../data/Connection.dart';
import '../../data/Identification.dart';
import '../../data/LocationData.dart';
import '../../data/OperatorID.dart';
import '../../data/SelfIdData.dart';
import '../../data/SystemData.dart';
import '../check_cache.dart';
import 'helper_controller.dart';
import 'open_drone_id_parser.dart';



final Map<String, bool> detAuthenticationCache = {};
final Map<String, Map<String, dynamic>> dripLinkCache = {};




// Define AircraftObject class with necessary fields (similar to Java)
Location receiverLocation = Location();  // San Francisco example
typedef AircraftCallback = void Function(AircraftObject object);

final Set<String> _authInProgress = {};



class OpenDroneIdDataManager {

  String droneDet= "";
  static final  Map<int, AircraftObject> aircraft = {}; // Store AircraftObjects in a map with macAddress as the key
  final StreamController<AircraftObject> onNewAircraftStream = StreamController.broadcast();

    // Using the function type for callback
  OpenDroneIdDataManager();// Callback function type

  /*void receiveDataBluetooth(Uint8List data, ScanResult result, LogMessageEntry logMessageEntry, String transportType) {
    // Get the MAC address from the device
    String macAddress = result.device.id.toString();
    String macAddressCleaned = macAddress.replaceAll(":", ""); // Remove colons
    int macAddressLong = int.parse(macAddressCleaned, radix: 16);  // Convert to long
    // Parse the data using the OpenDroneIdParser.parseData method
    final timestamp = result.timeStamp is int
        ? result.timeStamp as int
        : DateTime.now().millisecondsSinceEpoch; // Use current time as fallback// You can update based on actual timestamp available
    var message = OpenDroneIdParser.parseData(data,2, timestamp, logMessageEntry, receiverLocation);

    print("MESSAGE");
    // Check if the message was successfully parsed
    if (message == null) {
      print("Message is null");
      return;
    }

    // Process the data using receiveData
    receiveData(timestamp, macAddress, macAddressLong, result.rssi, message, logMessageEntry, transportType);


  }*/


  /*void receiveDataBluetooth(Uint8List data, ScanResult result, LogMessageEntry logMessageEntry, String transportType) async {
    final timestamp = result.timeStamp is int
        ? result.timeStamp as int
        : DateTime.now().millisecondsSinceEpoch;

    await compute(_processBluetoothDataIsolate, {
      "data": data,
      "macAddress": result.device.id.toString(),
      "rssi": result.rssi,
      "timestamp": timestamp,
      "transportType": transportType,
      "log": logMessageEntry,
    });
  }*/

  Future<void> receiveDataBluetooth(Uint8List data, ScanResult result, LogMessageEntry logMessageEntry, String transportType) async {
    String macAddress = result.device.id.toString();
    String macAddressCleaned = macAddress.replaceAll(":", "");
    int macAddressLong = int.parse(macAddressCleaned, radix: 16);
    final timestamp = result.timeStamp is int
        ? result.timeStamp as int
        : DateTime.now().millisecondsSinceEpoch;

    // Offload only the parsing to a separate isolate
    final parsedMessage = await Isolate.run(() {
      return OpenDroneIdParser.parseData(
        data,
        2,
        timestamp,
        logMessageEntry,
        receiverLocation,
      );
    });

    if (parsedMessage == null) {
      print("Parsed message is null");
      return;
    }

    // Back in the main isolate: safe to call Get.find() and update UI
    await receiveData(timestamp, macAddress, macAddressLong, result.rssi, parsedMessage, logMessageEntry, transportType);
  }


  Future<void> _processBluetoothDataIsolate(Map<String, dynamic> args) async {
    final Uint8List data = args["data"];
    final String macAddress = args["macAddress"];
    final int rssi = args["rssi"];
    final int timestamp = args["timestamp"];
    final String transportType = args["transportType"];
    final LogMessageEntry logMessageEntry = args["log"];

    final String macAddressCleaned = macAddress.replaceAll(":", "");
    final int macAddressLong = int.parse(macAddressCleaned, radix: 16);

    final Message? message = OpenDroneIdParser.parseData(data, 2, timestamp, logMessageEntry, receiverLocation);

    if (message == null) {
      print("Message is null in isolate");
      return;
    }

    // NOTE: You must make sure `OpenDroneIdDataManager().receiveData(...)` is safe for isolate use.
    // If it uses any shared `Get.find()` state or non-thread-safe logic, it must be moved to main isolate.
    final manager = OpenDroneIdDataManager();
     await manager.receiveData(timestamp, macAddress, macAddressLong, rssi, message, logMessageEntry, transportType);
  }


  Future<void> receiveData(
      int timeNano,
      String macAddress,
      int macAddressLong,
      int rssi,
      Message message,
      LogMessageEntry logMessageEntry,
      String transportType) async {

    // Handle connction
    bool newAircraft = false;
    AircraftObject? ac = aircraft[macAddressLong];
    print(aircraft.containsKey(macAddressLong));
    print(aircraft);
    print(macAddressLong);
    print(macAddress);
    print("NEW OR OLD AC");
    print(ac);

    if (ac == null) {
      ac = createNewAircraft(macAddress, macAddressLong);
      print("NEW AIR CRAFT");
      print(ac);
      newAircraft = true;
    }else{

      print("ALREADY AIR CRAFT");
      print(aircraft[macAddressLong]);
    }

    // Get current time and calculate delta from last seen
    int currentTime = DateTime.now().millisecondsSinceEpoch;

    ac.getConnection!.msgDelta.value = currentTime - ac.getConnection!.lastSeen.value;
    ac.getConnection!.lastSeen.value = currentTime;
    ac.getConnection!.rssi.value = rssi;
    ac.getConnection!.transportType.value = transportType;
    ac.getConnection!.setTimestamp(timeNano);
    ac.getConnection!.setMsgVersion(message.header.version);
    ac.connection.value = ac.getConnection;

      if (newAircraft) {
        aircraft[macAddressLong] = ac;
        onNewAircraftStream.add(ac); // Notify the UI with the new AircraftObject
      }
      print("NEW AIRCRAFT IN LIST");
      print(aircraft[macAddressLong]);
      print("NEW AIRCRAFT AUTH");
      print(ac.authentication.value!.getAuthenticationDataAsString());
      print(ac.authDataCombined);
      print("AUTH LENGHT");
      print(ac.authentication.value!.authLength);


    if (message.header.type == MessageType.messagePack) {
      handleMessagePack(ac, message, timeNano, logMessageEntry, message.msgCounter);
    } else {
      handleMessages(ac, message);
    }

    ac.isAuth(ac.identification1.value!, ac.authentication.value!);
    //print("AFTER EVERYTING");

    //final bytes = ac.evidence.buffer.asUint8List(ac.evidence.offsetInBytes, ac.evidence.lengthInBytes);
    //print("EVIDENCE AFTER EVERTHING");

    //print(bytes);

    // Restore the msgVersion in case the messages embedded in the pack had a different value

    // NOW WE PASS THE EVID + AuthValues, we inster evid in index 7 and so on.
    final int targetLength = ac.authentication.value!.authLength.value;

    /*final Uint8List fixedAuthDataCombined = Uint8List.fromList(
      ac.authDataCombined.length >= targetLength
          ? ac.authDataCombined.sublist(0, targetLength )
          : ac.authDataCombined + List.filled(targetLength - ac.authDataCombined.length, 0),
    );*/
    //print("FIXED DATA COMBINE");
    //print( ac.authDataCombined.sublist(1,89));
    final Uint8List safeAuth = Uint8List.fromList(ac.authDataCombined);
    final ByteData safeEvidence = ByteData.sublistView(
        Uint8List.fromList(ac.evidence.buffer.asUint8List())
    );


    //print(await authenticateWrapper(ac.authDataCombined.sublist(1,89), ac.evidence ));
    print("SAFE DATA COMBINE");
    print(safeAuth.sublist(1, 89));
    if(safeAuth.elementAt(0) == 2){
      print("Header is Wrapper");
      print(await authenticateWrapper(safeAuth.sublist(1, 89), safeEvidence));
    }else if (safeAuth.elementAt(0) == 1){
      await authenticateDripLink(safeAuth.sublist(1, 138));
      print ("DRIP LINK HEADER");

    }

    logMessageEntry.setMsgVersion(ac.connection.value!.getMsgVersion());
  }



  void handleMessages(AircraftObject ac, Message message) {
    // Handle message based on type
    switch (message.header.type) {
      case MessageType.basicId:
        //var byteData = handleEvidence (message);
       // var byteData = handleEvidence (message);
        //ac.evidence = byteData;
        final data = message.rawBytes;
        for (int i = 0; i < 25; i++) {
          ac.evidence.setUint8(i, data[i]);
        }
        handleBasicId(ac, message.payload);
        break;
      case MessageType.location:
        final data = message.rawBytes;
        for (int i = 0; i < 25; i++) {
          ac.evidence.setUint8(25 + i, data[i]);
        }
        handleLocation(ac, message.payload);
        break;
      case MessageType.auth:
        handleAuthentication(ac, message.payload);
        break;
      case MessageType.selfId:

        handleSelfId(ac, message.payload);
        break;
      case MessageType.system:
        final data = message.rawBytes;
        for (int i = 0; i < 25; i++) {
          ac.evidence.setUint8(50 + i, data[i]);
        }
        handleSystem(ac, message.payload);
        break;
      case MessageType.operatorId:

        handleOperatorId(ac, message.payload);
      default:
        print("Unsupported message type: ${message.header.type}");
        break;
    }

  }

  AircraftObject createNewAircraft(String macAddress, int macAddressLong) {
    // Create a new AircraftObject
    AircraftObject ac = AircraftObject(macAddressLong);

    // Create and initialize the connection object
    Connection connection = Connection();
    connection.firstSeen.value = DateTime.now().millisecondsSinceEpoch; // Equivalent to System.currentTimeMillis()
    connection.macAddress.value = macAddress;
    ac.connection.value = connection;

    // Initialize all the required fields with new objects
    ac.identification1.value = Identification();
    ac.identification2.value = Identification();
    ac.location.value = LocationData();
    ac.authentication.value = AuthenticationData();
    ac.selfid.value  = SelfIdData();
    ac.system.value = SystemData();
    ac.operatorid.value = OperatorIdData();

    return ac;  // Return the created AircraftObject
  }


  void handleBasicId(AircraftObject ac, Payload message) {
    BasicId raw = message as BasicId;
    Identification data = Identification();

    //data.msgCounter.value = message.msgCounter;
    //data.timestamp.value = message.timestamp;

    data.setUaType(raw.uaType);
    data.setIdType(raw.idType);
    data.setUasId(raw.uasId);

    // This implementation can receive up to two different types of Basic ID messages
    // Find a free slot to store the current message or overwrite old data of the same type
    Identification? id1 = ac.identification1.value;
    Identification? id2 = ac.identification2.value;

    if (id1 == null || id2 == null) return; // If both are null, we skip updating

    IdTypeEnum type1 = id1.idType;
    IdTypeEnum type2 = id2.idType;

    if (type1 == IdTypeEnum.None || type1 == data.idType) {
      ac.identification1.value = data;

    } else {
      if (type2 == IdTypeEnum.None || type2 == data.idType) {
        ac.identification2.value = data;
      } else {
        print('Discarded Basic ID message of type: ${data.idType}. '
            'Already have ${type1.toString()} and ${type2.toString()}');
      }
    }


    print(ac.identification1.value);
    print(ac.identification2.value);
    print(ac.identification1.value!.uasId);
    print(data.getUasIdAsString());
    print("UAS ID");

  }


  void handleLocation(AircraftObject ac, Payload message) {
    Location raw = message as Location;
    LocationData data = LocationData();
    // Set the message counter and timestamp
    //data.setMsgCounter(message.msgCounter);
    //data.setTimestamp(message.timestamp);
    // Set the location-specific fields
    data.setStatus(raw.status);
    data.setHeightType(raw.heightType);
    data.setDirection(raw.getDirection()); // Assuming currentDirection is a getter
    data.setSpeedHorizontal(raw.getSpeedHori());
    data.setSpeedVertical(raw.getSpeedVert());
    data.setLatitude(raw.getLatitude());
    data.setLongitude(raw.getLongitude());
    data.setAltitudePressure(raw.getAltitudePressure());
    data.setAltitudeGeodetic(raw.getAltitudeGeodetic());
    data..setHeight(raw.getHeight());
    data.setHorizontalAccuracy(raw.horizontalAccuracy);
    data.setVerticalAccuracy(raw.verticalAccuracy);
    data.setBaroAccuracy(raw.baroAccuracy);
    data.setSpeedAccuracy(raw.speedAccuracy);
    data.setTimestamp(raw.timestamp);
    data.setTimeAccuracy(raw.getTimeAccuracy());
    data.setDistance(raw.distance);
    // Set the location data in the Aircraft object
    ac.updateLocation(raw.getLatitude(), raw.getLongitude());  // Update the location
    print("RAW LAT");
    print(raw.getLatitude());
    print("RAW LONG");
    print(raw.getLongitude());

    Get.find<map_controller>().updateDroneLocation(ac.getMacAddress(), raw.getLatitude(), raw.getLongitude());


    //Get.find<map_controller>().Longitude.value =  raw.getLongitude();
    //Get.find<map_controller>().updateDroneLocation( raw.getLatitude(),raw.getLongitude());
    ac.location.value = data;

    print("LOCATION DATA");
    print (message);
  }


  void handleAuthentication(AircraftObject ac, Payload message) {
    // Handle Authentication Message
    Authentication raw = message as Authentication;
    AuthenticationData data = AuthenticationData();

    //data.setMsgCounter(message.msgCounter);
    //data.setTimestamp(message.timestamp);

    data.setAuthType(raw.authType);
    data.setAuthDataPage(raw.authDataPage);

    if (raw.authDataPage == 0) {
      data.setAuthLastPageIndex(raw.authLastPageIndex);
      data.setAuthLength(raw.authLength);
      data.setAuthTimestamp(raw.authTimestamp);
    }

    data.setAuthData(raw.authData);
    print("HANDEL AUTH DATA");
    print(raw.authData);

    ac.combineAuthentication(data);

  }

  void handleSelfId(AircraftObject ac, Payload message) {
    // Handle SelfID Message

    SelfID raw = message as SelfID;
    SelfIdData data = SelfIdData();

    // Set message counter and timestamp
   // data.setMsgCounter(message.msgCounter);
   // data.setTimestamp(message.timestamp);

    // Set description type and operation description
    data.setDescriptionType(raw.descriptionType);
    data.setOperationDescription(raw.operationDescription);

    // Set the self-id data
    ac.selfid.value = data;
  }

  void handleSystem(AircraftObject ac, Payload message) {
    // Handle System Message

    SystemMsg raw = message as SystemMsg;
    SystemData data = SystemData();

    // Set message counter and timestamp
    //data.setMsgCounter(message.msgCounter);
   // data.setTimestamp(message.timestamp);

    // Set operator location type and classification type
    data.setOperatorLocationType(raw.operatorLocationType);
    data.setClassificationType(raw.classificationType);

    // Set operator latitude and longitude
    data.setOperatorLatitude(raw.getLatitude());
    data.setOperatorLongitude(raw.getLongitude());

    print(raw.getLatitude());
    print(raw.getLongitude());
   // Get.find<map_controller>().Latitude.value  = data.operatorLatitude.value;
    //Get.find<map_controller>().Longitude.value = data.operatorLongitude.value;
    //Get.find<map_controller>().updateDroneLocation( data.operatorLatitude.value,data.operatorLongitude.value);
    print("System");

    // Set area details
    data.setAreaCount(raw.areaCount);
    data.setAreaRadius(raw.getAreaRadius());
    data.setAreaCeiling(raw.getAreaCeiling());
    data.setAreaFloor(raw.getOperatorAltitudeGeo());

    // Set category and class values
    data.setCategory(raw.category);
    data.setClassValue(raw.classValue);

    // Set operator altitude and system timestamp
    data.setOperatorAltitudeGeo(raw.getOperatorAltitudeGeo());
    data.setSystemTimestamp(raw.systemTimestamp);

    // Update the system data in the aircraft object
    ac.system.value = data;
  }

  void handleOperatorId(AircraftObject ac, Payload message) {
    // Handle OperatorID Message

    OperatorID raw = message as OperatorID;
    OperatorIdData data = OperatorIdData();

    // Set message counter and timestamp
   // data.setMsgCounter(message.msgCounter);
    //data.setTimestamp(message.timestamp);

    // Set operator ID type and operator ID
    data.setOperatorIdType(raw.operatorIdType);
    data.setOperatorId(raw.operatorId);

    // Update the operator ID in the aircraft object
    ac.operatorid.value = data;
  }

  void handleMessagePack(
      AircraftObject ac,
      Message message,
      int timestamp,
      LogMessageEntry logMessageEntry,
      int msgCounter,
      ) {
    final raw = message.payload as MessagePack;
    if (raw == null) return;

    if (raw.messageSize != Constants.MAX_MESSAGE_SIZE ||
        raw.messagesInPack <= 0 ||
        raw.messagesInPack > Constants.MAX_MESSAGES_IN_PACK) {
      return;
    }

    for (int i = 0; i < raw.messagesInPack; i++) {
      final offset = i * raw.messageSize;
      final data = Uint8List.sublistView(
        raw.messages,
        offset.toInt(),
        offset.toInt() + raw.messageSize,
      );

      print("data after offset");
      print(data);




      final subMessage = OpenDroneIdParser.parseMessage(
        data,
        0,
        timestamp,
        logMessageEntry,
        receiverLocation,
        msgCounter,
      );
      // Identify message type and update appropriate evidence slice
      int evidenceOffset = -1;
      if (subMessage is BasicId) {
        evidenceOffset = 0;
      } else if (subMessage is Location) {
        evidenceOffset = 25;
      } else if (subMessage is SelfID ) {
        evidenceOffset = 50;
      }


      if (evidenceOffset >= 0 && ac.evidence.lengthInBytes  >= 75) {
        // Only copy 25 bytes starting from the correct offset
        for (int j = 0; j < 25; j++) {
          ac.evidence.setUint8(evidenceOffset + j, data[j]);
        }
      }

      if (subMessage == null) return;

      handleMessages(ac, subMessage);
    }
  }
  ByteData handleEvidence(Message data){

    Uint8List bytes = Uint8List.fromList(data.payload.toString().codeUnits);
    ByteData byteData = ByteData.sublistView(bytes);
    return byteData;
  }

// Add any additional methods as needed for your application



  helperController _helper = new helperController();
  Future<String> authenticateWrapper(Uint8List authData, ByteData evi) async {




    final bedbytes = evi.buffer.asUint8List(evi.offsetInBytes, evi.lengthInBytes);
    print("Before MODIFIED:");
    print(bedbytes);
    /// Convert ByteData to Uint8List
    Uint8List evidenceBytes = evi.buffer.asUint8List();

    // Allocate a new Uint8List to hold the result
    Uint8List modified = Uint8List(authData.length + evidenceBytes.length);

    // Copy original data up to index 8
    modified.setRange(0, 8, authData);

    // Insert evidence at index 8
    modified.setRange(8, 8 + evidenceBytes.length, evidenceBytes);

    // Copy the rest of authData after index 8
    modified.setRange(8 + evidenceBytes.length, modified.length, authData.sublist(8));

    print("MODIFED");
    print(modified);


    //return "DONE";

    //start constructing



    Uint8List publicKeyBytes = Uint8List(0) ;
    bool isValid = false;
    bool isLink = false;
    try {
      // Record the start time
      final startTime = DateTime.now();
      //final wrapperBytes = Uint8List.fromList(_helper.hexToBytes(wrapperHex));
      final signatureBytes = authData.sublist(authData.length - 64,);
      final messageBytes = modified.sublist(0, modified.length - 64);
      print ("wrapperBytes");
     print (modified);
      print("Full modified wrapper (Hex):");
      print(_helper.hexEncode(authData));  // or .map((b) => b.toRadixString(16)).join(' ')
      print("Message (Hex): ${_helper.hexEncode(Uint8List.fromList(messageBytes))}");
      print("Signature (Hex): ${_helper.hexEncode(Uint8List.fromList(signatureBytes))}");
// Extract DET (16 bytes before the signature, after the evidence)
      final detBytes = messageBytes.sublist(messageBytes.length - 16, messageBytes.length);
      final detHex = _helper.hexEncode(Uint8List.fromList(detBytes));
      // If already authenticating this DET, skip
      if (_authInProgress.contains(detHex)) {
        return "Skipped: Authentication already in progress for $detHex";
      }

      _authInProgress.add(detHex); // Mark as in progress


      print("DET (Hex): $detHex");
      if (detAuthenticationCache.containsKey(detHex)) {
        //print("Skipping authentication for already authenticated DET: $detHex");
        _authInProgress.remove(detHex);
        return "Authentication successful: Signature is valid.";

      }
      final publicKeyHex = await checkCache(detHex);
      //print("Fetched Public Key: $publicKeyHex");
      // Convert public key from hex to bytes
      publicKeyBytes = Uint8List.fromList(_helper.hexToBytes(publicKeyHex!));
      final publicKey = SimplePublicKey(publicKeyBytes, type: KeyPairType.ed25519);
      final signature = Signature(signatureBytes, publicKey: publicKey);
      isValid = await Ed25519().verify(Uint8List.fromList(modified.sublist(0,modified.length - 64)), signature: signature);
      if (isValid){
        detAuthenticationCache[detHex] = true;
        droneDet = detHex;
        _authInProgress.remove(detHex);

      }else{
        detAuthenticationCache[detHex] = false;
        _authInProgress.remove(detHex);

      }
      return isValid ? "Authentication successful: Signature is valid." : "Authentication failed: Signature is invalid.";
    } catch (e) {
      return "Error during authentication: $e";
    }
  }

  Future<String?> checkCache(String detHex) async {
    final startTime = DateTime.now();
    final cache = await PublicKeyCache.loadCache();

    // Check if the DET exists in the cache
    if (cache.containsKey(detHex)) {
      print("Public key found in cache for DET: $detHex");
      final endTime = DateTime.now();
      // Calculate the time taken
      final duration = endTime.difference(startTime).inMilliseconds;

      print("Time it took to hit: $duration");
      return cache[detHex];
    }else{
      final endTime = DateTime.now();
      // Calculate the time taken
      final duration = endTime.difference(startTime).inMilliseconds;
      print("Time it took to miss: $duration");
      await reverseDnsLookup (detHex);
    }
  }



  Future<String?> reverseDnsLookup(String detHex) async {
    try {
      print ("REVERSE FUNCTION");

      print(detHex);

      // Record the start time
      final startTime = DateTime.now();
      final detDomain = reverseDet(detHex); // Reverse DET to domain format
      print("Recived DET");
      print("Det HEX");
      print("Reversed DET");
      print(detDomain);
      final dnsolve = DNSolve();
      final response = await dnsolve.lookup(
          detDomain,
          dnsSec: false,
          type: RecordType.txt,
          provider: DNSProvider.cloudflare
      );

      if (response.answer?.records != null) {
        for (final record in response.answer!.records!) {
          if (record.rType == RecordType.txt && record.data.contains("pubkey=")) {
            final publicKey = record.data.split("pubkey=")[1].replaceAll('"', ''). trim();
            final endTime = DateTime.now();
            // Calculate the time taken
            final duration = endTime.difference(startTime).inMilliseconds;
            // Add the public key to the cache
            final cache = await PublicKeyCache.loadCache();
            print("DNS RESOLVE time: $duration ms");
            cache[detHex] = publicKey;
            // Save the updated cache
            await PublicKeyCache.saveCache(cache);
            print("Saved in Cache Public Key: $publicKey");
            return publicKey;


          }
        }
      }

      print("REVERS BNULL");
      return null;
    } catch (e) {
      return null;
    }
  }

  String reverseDet(String detHex) {
    // Validate that the input string contains only valid hexadecimal characters
    final hexPattern = RegExp(r'^[0-9a-fA-F]+$');
    if (!hexPattern.hasMatch(detHex)) {
      throw FormatException("Invalid DET format: $detHex");
    }

    // Split the DET into nibbles (single hex characters)
    final nibbles = detHex.split('');

    // Reverse the nibble order and join with dots
    final reversedNibbles = nibbles.reversed.join('.').toLowerCase();

    // Append the domain
    return "$reversedNibbles.vertexpal.com";
  }



  /// Parses the dynamic wrapper and extracts its components.
  Map<String, dynamic> parseWrapper(Uint8List wrapper) {
    //testStaticLocation();
    final ByteData byteData = ByteData.sublistView(wrapper);

    // Extract fixed components
    int vnb = byteData.getUint32(0, Endian.little);
    int vna = byteData.getUint32(4, Endian.little);

    // Calculate payload size
    int payloadStartIndex = 8; // VNB (4 bytes) + VNA (4 bytes)
    int detStartIndex = wrapper.length - 80; // DET (16 bytes) + Signature (64 bytes)
    int payloadEndIndex = detStartIndex; // Payload ends where DET starts
    int payloadSize = payloadEndIndex - payloadStartIndex;

    // Extract payload
    Uint8List payload = wrapper.sublist(payloadStartIndex, payloadEndIndex);

    // Extract DET
    Uint8List det = wrapper.sublist(detStartIndex, detStartIndex + 16);

    // Extract Signature
    Uint8List signature = wrapper.sublist(detStartIndex + 16, wrapper.length);

    // Parse payload if necessary
    final parsedPayload = parseF3411Message(payload);

    // Return parsed components
    return {
      "VNB": vnb,
      "VNA": vna,
      "payload": parsedPayload,
      "DET": det,
      "signature": signature,
    };
  }

  /// Parses the F3411 payload and extracts geolocation and other details.
  Map<String, dynamic> parseF3411Message(Uint8List payload) {
    final ByteData byteData = ByteData.sublistView(payload);

    // Extract fields from the payload
    double latitudeRaw = byteData.getFloat32(0, Endian.little);
    double longitudeRaw = byteData.getFloat32(4, Endian.little);
    // to keep data live

    //Get.find<map_controller>().Latitude.value  = latitudeRaw;
    // Get.find<map_controller>().Longitude.value = longitudeRaw;
    int altitude = byteData.getUint16(8, Endian.little);
    int velocity = byteData.getUint16(10, Endian.little);

    print("Raw Payload Bytes: ${payload.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ')}");

    // Apply dynamic scaling

    print("Location");


    // Get.find<map_controller>().updateDroneLocation(latitudeRaw, longitudeRaw);

    print(latitudeRaw);
    print(longitudeRaw);
    print(velocity);


    return {
      "latitude": latitudeRaw,
      "longitude": longitudeRaw,
      "altitude": altitude,
      "velocity": velocity,
    };

  }

  /*void processWrapper(Uint8List wrapper) async {

    String hexString = _helper.convertToHexList(wrapper);
    await authenticateWrapper(hexString).then((authResult) {
      print("Authentication Result: $authResult");
    });
  }*/








  Future<String> authenticateDripLink( Uint8List dripLinkBytes) async {
    try {
      final startTime = DateTime.now();

      // Parse the DRIP Link
      //Uint8List dripLinkBytes = _helper.hexToBytes(dripLinkHex);
      const String hdaPublicKeyHex = "3e373f3064e6da5a1a3248df708ba95bf405d13b12a169fc5017c5cdeb33baed";

      // Extract fields from the DRIP Link
      Uint8List validNotBeforeBytes = dripLinkBytes.sublist(0, 4);
      Uint8List validNotAfterBytes = dripLinkBytes.sublist(4, 8);
      Uint8List uavDetBytes = dripLinkBytes.sublist(8, 24);
      Uint8List uavPublicKeyBytes = dripLinkBytes.sublist(24, 56);
      Uint8List parentDetBytes = dripLinkBytes.sublist(56, 72);
      Uint8List parentSignatureBytes = dripLinkBytes.sublist(72, 136);



      // Convert fields to readable formats
      int validNotBefore = ByteData.sublistView(validNotBeforeBytes).getUint32(0, Endian.little);
      int validNotAfter = ByteData.sublistView(validNotAfterBytes).getUint32(0, Endian.little);
      String uavDetHex = _helper.hexEncode(uavDetBytes);
      String uavPublicKeyHex = _helper.hexEncode(uavPublicKeyBytes);
      String parentDetHex = _helper.hexEncode(parentDetBytes);
      String parentSignatureHex = _helper.hexEncode(parentSignatureBytes);
      // Check if the DRIP Link is cached
      if (isDripLinkCached(uavDetHex)) {
        print("Parent Signature verified successfully.");
        return "DRIP Link authenticated successfully (cached).";
      }

      print("Parsed DRIP Link Fields:");
      print("Valid Not Before: $validNotBefore");
      print("Valid Not After: $validNotAfter");
      print("UAV DET: $uavDetHex");
      print("UAV Public Key: $uavPublicKeyHex");
      print("Parent DET: $parentDetHex");
      print("Parent Signature: $parentSignatureHex");

      // Step 1: Validate timestamps
      /*if (!validateTimestamps(validNotBefore, validNotAfter)) {
      return "Invalid timestamps in DRIP Link.";
    }*/


      print(" HDA Public Key: $hdaPublicKeyHex");
      // Step 3: Verify Parent Signature
      bool isParentSignatureValid = await verifyParentSignature(parentDetHex: parentDetHex,
          parentSignatureHex: parentSignatureHex,
          uavDetHex: uavDetHex,
          uavPublicKeyHex: uavPublicKeyHex,
          hdaPublicKeyHex: hdaPublicKeyHex,
          validNotAfter: validNotAfter,
          validNotBefore: validNotBefore

      );
      if (!isParentSignatureValid) {
        return "Parent Signature verification failed.";
      }

      cacheDripLink(uavDetHex, {
        "parentDet": parentDetHex,
        "validNotBefore": validNotBefore,
        "validNotAfter": validNotAfter,
        "isAuthenticated": true,
      });

      print("Parent Signature verified successfully.");
      final elapsedTime = DateTime.now().difference(startTime).inMilliseconds;
      print("Time taken to authenticate received DRIP Link: ${elapsedTime}ms");


      // Step 4: Authenticate the UAV
      /* bool isUAVAuthenticated = await authenticateUAV(
      uavDetHex,
      parentSignatureHex, // Wrapper signature is generally needed for full UAV authentication
      uavPublicKeyHex,
    );
    if (!isUAVAuthenticated) {
      return "UAV authentication failed.";
    }

    print("UAV authentication successful.");
*/
      // If all steps pass
      return "DRIP Link authenticated successfully.";
    } catch (e) {
      print("Error during DRIP Link authentication: $e");
      return "Error during DRIP Link authentication: $e";
    }
  }




  Future<bool> verifyParentSignature({
    required String uavDetHex,
    required String parentDetHex,
    required String uavPublicKeyHex,
    required String parentSignatureHex,
    required String hdaPublicKeyHex,
    required int validNotBefore,
    required int validNotAfter,
  }) async {
    try {
      // Convert hex strings to bytes
      Uint8List uavDetBytes = _helper.hexToBytes(uavDetHex);
      Uint8List parentDetBytes = _helper.hexToBytes(parentDetHex);
      Uint8List uavPublicKeyBytes = _helper.hexToBytes(uavPublicKeyHex);
      Uint8List parentSignatureBytes = _helper.hexToBytes(parentSignatureHex);
      Uint8List hdaPublicKeyBytes = _helper.hexToBytes(hdaPublicKeyHex);

      // Concatenate data to be verified (HDA DET + UAV DET + UAV Public Key + Validity Periods)
      Uint8List validityPeriodBytes = Uint8List(8)
        ..buffer.asByteData().setUint32(0, validNotBefore, Endian.little)
        ..buffer.asByteData().setUint32(4, validNotAfter, Endian.little);

      Uint8List dataToVerify = Uint8List.fromList(
        parentDetBytes + uavDetBytes + uavPublicKeyBytes + validityPeriodBytes,
      );

      // Verify the signature
      final publicKey = SimplePublicKey(hdaPublicKeyBytes, type: KeyPairType.ed25519);
      final signature = Signature(parentSignatureBytes, publicKey: publicKey);

      bool isValid = await Ed25519().verify(dataToVerify, signature: signature);

      print(isValid ? "Parent Signature is valid." : "Parent Signature is invalid.");
      return isValid;
    } catch (e) {
      print("Error verifying Parent Signature: $e");
      return false;
    }
  }




  String extractPublicKeyFromDnsResponse(String response) {
    // Parse the public key from the DNS TXT response
    final regex = RegExp(r'pubkey=([0-9a-fA-F]+)');
    final match = regex.firstMatch(response);
    if (match != null) {
      return match.group(1) ?? "Invalid response format.";
    } else {
      return "Public key not found in response.";
    }
  }


  bool isDripLinkCached(String uavDet) {
    return dripLinkCache.containsKey(uavDet);
  }

  void cacheDripLink(String uavDet, Map<String, dynamic> linkDetails) {
    dripLinkCache[uavDet] = linkDetails;
    print("Cached DRIP Link for UAV DET: $uavDet");
  }


  Map<String, dynamic>? getCachedDripLink(String uavDet) {
    return dripLinkCache[uavDet];
  }

}

