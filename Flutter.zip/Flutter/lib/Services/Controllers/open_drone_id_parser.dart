import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';

import '../../Constants/Constants.dart';
import '../../Constants/log_message_entry.dart';
import '../../Models/BLEModels/parsed_results.dart';
final double LAT_LONG_MULTIPLIER = 1e-7;
final double SPEED_VERTICAL_MULTIPLIER = 0.5;



enum MessageType {
  basicId(0),
  location(1),
  auth(2),
  selfId(3),
  system(4),
  operatorId(5),
  messagePack(0xF);

  const MessageType(this.id);
  final int id;

  static MessageType? fromId(int id) {
    switch (id) {
      case 0:
        return MessageType.basicId;
      case 1:
        return MessageType.location;
      case 2:
        return MessageType.auth;
      case 3:
        return MessageType.selfId;
      case 4:
        return MessageType.system;
      case 5:
        return MessageType.operatorId;
      case 0xF:
        return MessageType.messagePack;
      default:
        return null;
    }
  }
}


 enum HorizontalAccuracyEnum {
  Unknown,
  kilometers_18_52,
  kilometers_7_408,
  kilometers_3_704,
  kilometers_1_852,
  meters_926,
  meters_555_6,
  meters_185_2,
  meters_92_6,
  meters_30,
  meters_10,
  meters_3,
  meters_1,
}


class Header {
  MessageType? type;
  int version = 0;

  @override
  String toString() => 'Header{type: $type, version: $version}';
}

abstract class Payload {
  String toCsvString();
}

class BasicId implements Payload {
  int idType = 0;
  int uaType = 0;
  final Uint8List uasId = Uint8List(Constants.MAX_ID_BYTE_SIZE);

  static String csvHeader() => 'idType${Constants.DELIM}uaType${Constants.DELIM}uasId${Constants.DELIM}';

  @override
  String toCsvString() => '$idType${Constants.DELIM}$uaType${Constants.DELIM}${String.fromCharCodes(uasId)}${Constants.DELIM}';

  @override
  String toString() => 'BasicId{idType: $idType, uaType: $uaType, uasId: $uasId}';
}

class Location implements Payload {

  int status = 0;
  int heightType = 0;
  int ewDirection = 0;
  int speedMult = 0;
  int direction = 0;
  int speedHori = 0;
  int speedVert = 0;
  int droneLat = 0;
  int droneLon = 0;
  int altitudePressure = 0;
  int altitudeGeodetic = 0;
  int height = 0;
  int horizontalAccuracy = 0;
  int verticalAccuracy = 0;
  int baroAccuracy = 0;
  int speedAccuracy = 0;
  int timestamp = 0;
  int timeAccuracy = 0;
  double distance = 0.0;

  static double calcSpeed(int value, int mult) => mult == 0 ? value * 0.25 : (value * 0.75) + (255 * 0.25);
  static double calcDirection(int value, int ew) => ew == 0 ? value.toDouble() : value + 180.0;
  static double calcAltitude(int value) => value / 2 - 1000;

  double get latitude => droneLat * 1e-7;
  double get longitude => droneLon * 1e-7;
  double get speed => calcSpeed(speedHori, speedMult);
  double get verticalSpeed => speedVert * 0.5;
  double get currentDirection => calcDirection(direction, ewDirection);

  // This function calls calcDirection to get the final direction
  double getDirection() {
    return calcDirection(direction, ewDirection);
  }

  // This function calls calcSpeed to get the horizontal speed
  double getSpeedHori() {
    return calcSpeed(speedHori, speedMult);
  }

  // This function calculates vertical speed based on the multiplier
  double getSpeedVert() {
    return SPEED_VERTICAL_MULTIPLIER * speedVert;
  }

  double getLatitude() {
    return LAT_LONG_MULTIPLIER * droneLat;
  }

  double getLongitude() {
    return LAT_LONG_MULTIPLIER * droneLon;
  }

  double getAltitudeGeodetic() { return calcAltitude(altitudeGeodetic); }
  double getAltitudePressure() { return calcAltitude(altitudePressure); }
  double getHeight() { return calcAltitude(height); }
  double getTimeAccuracy() { return timeAccuracy * 0.1; }



  static String csvHeader() => 'status${Constants.DELIM}heightType${Constants.DELIM}ewDirection${Constants.DELIM}'
      'speedMult${Constants.DELIM}direction${Constants.DELIM}speedHori${Constants.DELIM}speedVert${Constants.DELIM}'
      'droneLat${Constants.DELIM}droneLon${Constants.DELIM}altitudePressure${Constants.DELIM}altitudeGeodetic${Constants.DELIM}'
      'height${Constants.DELIM}horizontalAccuracy${Constants.DELIM}verticalAccuracy${Constants.DELIM}baroAccuracy${Constants.DELIM}'
      'speedAccuracy${Constants.DELIM}timestamp${Constants.DELIM}timeAccuracy${Constants.DELIM}distance${Constants.DELIM}';

  @override
  String toCsvString() => '$status${Constants.DELIM}$heightType${Constants.DELIM}$ewDirection${Constants.DELIM}$speedMult${Constants.DELIM}'
      '$direction${Constants.DELIM}$speedHori${Constants.DELIM}$speedVert${Constants.DELIM}$droneLat${Constants.DELIM}$droneLon${Constants.DELIM}'
      '$altitudePressure${Constants.DELIM}$altitudeGeodetic${Constants.DELIM}$height${Constants.DELIM}$horizontalAccuracy${Constants.DELIM}'
      '$verticalAccuracy${Constants.DELIM}$baroAccuracy${Constants.DELIM}$speedAccuracy${Constants.DELIM}$timestamp${Constants.DELIM}'
      '$timeAccuracy${Constants.DELIM}$distance${Constants.DELIM}';

  @override
  String toString() => 'Location{status: $status, heightType: $heightType, ewDirection: $ewDirection, '
      'speedMult: $speedMult, direction: $direction, speedHori: $speedHori, speedVert: $speedVert, '
      'droneLat: $droneLat, droneLon: $droneLon, altitudePressure: $altitudePressure, '
      'altitudeGeodetic: $altitudeGeodetic, height: $height, horizontalAccuracy: $horizontalAccuracy, '
      'verticalAccuracy: $verticalAccuracy, baroAccuracy: $baroAccuracy, speedAccuracy: $speedAccuracy, '
      'timestamp: $timestamp, timeAccuracy: $timeAccuracy, distance: $distance}';
}

class Authentication implements Payload {
  int authType = 0;
  int authDataPage = 0;
  int authLastPageIndex = 0;
  int authLength = 0;
  int authTimestamp = 0;
  final Uint8List authData = Uint8List(Constants.MAX_AUTH_DATA);

  static String csvHeader() => 'authType${Constants.DELIM}authDataPage${Constants.DELIM}'
      'authLastPageIndex${Constants.DELIM}authLength${Constants.DELIM}authTimestamp${Constants.DELIM}authData${Constants.DELIM}';

  String _authDataToString() => authData.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ');

  @override
  String toCsvString() => '$authType${Constants.DELIM}$authDataPage${Constants.DELIM}$authLastPageIndex${Constants.DELIM}'
      '$authLength${Constants.DELIM}$authTimestamp${Constants.DELIM}${_authDataToString()}${Constants.DELIM}';

  @override
  String toString() => 'Authentication{authType: $authType, authDataPage: $authDataPage, '
      'authLastPageIndex: $authLastPageIndex, authLength: $authLength, authTimestamp: $authTimestamp, '
      'authData: $authData}';
}

class SelfID implements Payload {
  int descriptionType = 0;
  final Uint8List operationDescription = Uint8List(Constants.MAX_STRING_BYTE_SIZE);

  static String csvHeader() => 'descriptionType${Constants.DELIM}operationDescription${Constants.DELIM}';

  @override
  String toCsvString() => '$descriptionType${Constants.DELIM}${String.fromCharCodes(operationDescription)}${Constants.DELIM}';

  @override
  String toString() => 'SelfID{descriptionType: $descriptionType, operationDescription: $operationDescription}';
}

class SystemMsg implements Payload {
  int operatorLocationType = 0;
  int classificationType = 0;
  double operatorLatitude = 0;
  double operatorLongitude = 0;
  int areaCount = 0;
  int areaRadius = 0;
  int areaCeiling = 0;
  int areaFloor = 0;
  int category = 0;
  int classValue = 0;
  int operatorAltitudeGeo = 0;
  int systemTimestamp = 0;

  int get radius => areaRadius * 10;
  double get ceiling => areaCeiling / 2 - 1000;
  double get floor => areaFloor / 2 - 1000;
  double get altitude => operatorAltitudeGeo / 2 - 1000;



  double getLatitude() {
    return LAT_LONG_MULTIPLIER * operatorLatitude;
  }
  double getLongitude() {
    return LAT_LONG_MULTIPLIER * operatorLongitude;
  }
  int getAreaRadius() { return areaRadius * 10; }
  static double calcAltitude(int value) { return  value / 2 - 1000; }
  double getAreaCeiling() { return calcAltitude(areaCeiling); }
  double getAreaFloor() { return calcAltitude(areaFloor); }
  double getOperatorAltitudeGeo() { return calcAltitude(operatorAltitudeGeo); }
  static String csvHeader() => 'operatorLocationType${Constants.DELIM}classificationType${Constants.DELIM}'
      'operatorLatitude${Constants.DELIM}operatorLongitude${Constants.DELIM}areaCount${Constants.DELIM}areaRadius${Constants.DELIM}'
      'areaCeiling${Constants.DELIM}areaFloor${Constants.DELIM}category${Constants.DELIM}classValue${Constants.DELIM}'
      'operatorAltitudeGeo${Constants.DELIM}systemTimestamp${Constants.DELIM}';

  @override
  String toCsvString() => '$operatorLocationType${Constants.DELIM}$classificationType${Constants.DELIM}'
      '$operatorLatitude${Constants.DELIM}$operatorLongitude${Constants.DELIM}$areaCount${Constants.DELIM}$areaRadius${Constants.DELIM}'
      '$areaCeiling${Constants.DELIM}$areaFloor${Constants.DELIM}$category${Constants.DELIM}$classValue${Constants.DELIM}'
      '$operatorAltitudeGeo${Constants.DELIM}$systemTimestamp${Constants.DELIM}';

  @override
  String toString() => 'SystemMsg{operatorLocationType: $operatorLocationType, classificationType: $classificationType, '
      'operatorLatitude: $operatorLatitude, operatorLongitude: $operatorLongitude, areaCount: $areaCount, '
      'areaRadius: $areaRadius, areaCeiling: $areaCeiling, areaFloor: $areaFloor, category: $category, '
      'classValue: $classValue, operatorAltitudeGeo: $operatorAltitudeGeo, systemTimestamp: $systemTimestamp}';
}

class OperatorID implements Payload {
  int operatorIdType = 0;
  final Uint8List operatorId = Uint8List(Constants.MAX_ID_BYTE_SIZE);

  static String csvHeader() => 'operatorIdType${Constants.DELIM}operatorId${Constants.DELIM}';

  @override
  String toCsvString() => '$operatorIdType${Constants.DELIM}${String.fromCharCodes(operatorId)}${Constants.DELIM}';

  @override
  String toString() => 'OperatorID{operatorIdType: $operatorIdType, operatorId: $operatorId}';
}

class MessagePack implements Payload {
  int messageSize = 0;
  int messagesInPack = 0;
  final Uint8List messages = Uint8List(Constants.MAX_MESSAGE_PACK_SIZE);

  @override
  String toCsvString() => '';

  @override
  String toString() => 'MessagePack{messageSize: $messageSize, messagesInPack: $messagesInPack, messages: $messages}';
}

class Message<T extends Payload> implements Comparable<Message<Payload>> {
  final int msgCounter;
  final int timestamp;
  final Header header;
  final T payload;
  final Uint8List rawBytes;




  Message(this.header, this.payload, this.timestamp, this.msgCounter, this.rawBytes);

  @override
  int compareTo(Message<Payload> other) {
    if (header.type == MessageType.auth && other.header.type == MessageType.auth) {
      final authThis = payload as Authentication;
      final authOther = other.payload as Authentication;
      return authThis.authDataPage.compareTo(authOther.authDataPage);
    }
    return header.type!.index.compareTo(other.header.type!.index);
  }
}

class OpenDroneIdParser {

  static Message<Payload>? parseData(Uint8List payload, int offset, int timestamp,
      LogMessageEntry logMessageEntry, Location receiverLocation) {
    //List<ByteData>  evidence = [];
    print("parse data function");
    print(payload);
    if (offset <= 0 || payload.length < offset + Constants.MAX_MESSAGE_SIZE) {
      print("null early");
      return  null;
    }
    int msgCounter = payload[offset - 1] & 0xFF;
    print("message counter");
    print(msgCounter);
    // Call the parseMessage method to parse the message
    var message = parseMessage(payload, offset, timestamp, logMessageEntry, receiverLocation, msgCounter);
    return message;
  }

  static Message<Payload>? parseMessage(Uint8List payload, int offset, int timestamp,
      LogMessageEntry logMessageEntry, Location receiverLocation, int msgCounter) {
    if (payload.length < offset + Constants.MAX_MESSAGE_SIZE){
      print("size issue");
      return  null;

    }
    // Using ByteData for reading byte data from the Uint8List
    ByteData byteData = ByteData.sublistView(payload, offset, offset + Constants.MAX_MESSAGE_SIZE);
    final Uint8List rawBytes = payload.sublist(offset, offset + Constants.MAX_MESSAGE_SIZE);


    //Evidence.

    ByteData  evidence = ByteData(0);

    // Creating a Header object
    Header header = Header();

    // Reading the header byte (same as in Java)
    print("before parsing");
    print(payload);
    print(byteData.getInt32(5, Endian.little));
    int b = byteData.getUint8(0);

    int type = (b & 0xF0) >> 4;
    print("TYPEEE");
    print(type);
    header.type = MessageType.fromId(type); // Using the MessageType enum in Dart
    if (header.type == null) {
      print("Header type unknown");
      return  null;
    }

    header.version = b & 0x0F;

    Payload? payloadObj;

    // Switch to handle different message types
    switch (header.type) {
      case MessageType.basicId:
        //print("NEW EVI BASIC");
        //evidence = byteData;
        //Uint8List bytes = evidence.buffer.asUint8List(evidence.offsetInBytes, evidence.lengthInBytes);
        //print(bytes);
        payloadObj = _parseBasicId(byteData);
        break;
      case MessageType.location:

        print("Location!!!!");
        payloadObj = _parseLocation(byteData, receiverLocation);
        break;
      case MessageType.auth:
        print("WE GOT AUTH");
        payloadObj = _parseAuthentication(byteData);
        break;
      case MessageType.selfId:
        //evidence.add(byteData);
        payloadObj = _parseSelfID(byteData);
        break;
      case MessageType.system:
        //evidence.add(byteData);
        payloadObj = _parseSystem(byteData);
        break;
      case MessageType.operatorId:
       // evidence.add(byteData);
        payloadObj = _parseOperatorID(byteData);
        break;
      case MessageType.messagePack:
        print("message pack detected");
        payloadObj = _parseMessagePack(payload, offset);
        break;
      default:
        print("Received unhandled message type: id=$type");
    }

    // Creating the message with the parsed data
    Message<Payload> message = Message(header, payloadObj!, timestamp, msgCounter,rawBytes);
    print("Final DAATA");
    print(message.payload.toString());

    // Setting the message version
    logMessageEntry.setMsgVersion(message.header.version);

    // Adding the message to the log if it's not a MESSAGE_PACK type
    if (header.type != MessageType.messagePack) {
      logMessageEntry.add(message);
    }

    //print("EVIDENCE BEFORE RETURN ");
    //Uint8List bytes = evidence.buffer.asUint8List(evidence.offsetInBytes, evidence.lengthInBytes);
    //print(bytes);

    return  message;
  }


  static BasicId _parseBasicId(ByteData byteData) {
    final basicId = BasicId();
    final type = byteData.getUint8(0);
    basicId.idType = (type & 0xF0) >> 4;
    basicId.uaType = type & 0x0F;
    for (var i = 0; i < Constants.MAX_ID_BYTE_SIZE; i++) {
      basicId.uasId[i] = byteData.getUint8(1 + i);
    }
    return basicId;
  }

  static Location _parseLocation(ByteData byteData, Location receiverLocation) {
    final location = Location();
    var index = 0;


    final b = byteData.getUint8(index++);
    location.status = (b & 0xF0) >> 4;
    location.heightType = (b & 0x04) >> 2;
    location.ewDirection = (b & 0x02) >> 1;
    location.speedMult = b & 0x01;

    location.direction = byteData.getUint8(index++);
    location.speedHori = byteData.getUint8(index++);
    location.speedVert = byteData.getInt8(index++);
    index ++;
    location.droneLat = byteData.getInt32(index, Endian.little);
    print(location.droneLat);
    print(byteData.getInt32(index, Endian.little));
    index += 4;
    location.droneLon = byteData.getInt32(index, Endian.little);
    print(location.droneLon);
    print(byteData.getInt32(index, Endian.little));
    index += 4;

    location.altitudePressure = byteData.getUint16(index, Endian.little);
    index += 2;
    location.altitudeGeodetic = byteData.getUint16(index, Endian.little);
    index += 2;
    location.height = byteData.getUint16(index, Endian.little);
    index += 2;

    final horiVertAccuracy = byteData.getUint8(index++);
    location.horizontalAccuracy = horiVertAccuracy & 0x0F;
    location.verticalAccuracy = (horiVertAccuracy & 0xF0) >> 4;

    final speedBaroAccuracy = byteData.getUint8(index++);
    location.baroAccuracy = (speedBaroAccuracy & 0xF0) >> 4;
    location.speedAccuracy = speedBaroAccuracy & 0x0F;

    location.timestamp = byteData.getUint16(index, Endian.little);
    index += 2;
    location.timeAccuracy = byteData.getUint8(index++) & 0x0F;

    // Distance calculation
    if (receiverLocation.droneLat != 0 && receiverLocation.droneLon != 0) {
      print(receiverLocation.droneLat);
      print(receiverLocation.droneLon);
      print("worjing!!!");
      // Simplified distance calculation (replace with proper Haversine formula)
      final latDiff = location.latitude - receiverLocation.latitude;
      final lonDiff = location.longitude - receiverLocation.longitude;
      location.distance = sqrt(pow(latDiff, 2) + pow(lonDiff, 2));
    }else{

      print("Zeroooo");

    }

    return location;
  }



  static Authentication _parseAuthentication(ByteData byteData) {
    final auth = Authentication();
    var index = 0;

    print("AUTH BEFORE WORKING");
    printByteData(byteData);
    index ++;

    final type = byteData.getUint8(index);

    auth.authType = (type & 0xF0) >> 4;

    print("AUTH TYPE");
    print(type);
    print(auth.authType);
    print("AUTH DATA PAGE");

    auth.authDataPage = type & 0x0F;
    print(auth.authDataPage);

    if (auth.authDataPage == 0) {
      index ++;
      auth.authLastPageIndex = byteData.getUint8(index);
      index ++;
      auth.authLength = byteData.getUint8(index);
      index ++ ;
      auth.authTimestamp = byteData.getUint32(index, Endian.little);
      index = index + 4;

      final len = auth.authLastPageIndex * Constants.MAX_AUTH_PAGE_NON_ZERO_SIZE + Constants.MAX_AUTH_PAGE_ZERO_SIZE;
      if (auth.authLastPageIndex >= Constants.MAX_AUTH_DATA_PAGES || auth.authLength > len) {
        auth.authLastPageIndex = 0;
        auth.authLength = 0;
        auth.authTimestamp = 0;
      } else {
        auth.authLength = len;
      }
    }else {
      index ++;
    }



    final start = auth.authDataPage == 0 ? 0 : Constants.MAX_AUTH_PAGE_ZERO_SIZE + (auth.authDataPage - 1) * Constants.MAX_AUTH_PAGE_NON_ZERO_SIZE;
    final end = start + (auth.authDataPage == 0 ? Constants.MAX_AUTH_PAGE_ZERO_SIZE : Constants.MAX_AUTH_PAGE_NON_ZERO_SIZE);

    for (var i = start; i < end && i < Constants.MAX_AUTH_DATA; i++) {

      auth.authData[i] = byteData.getUint8(index);
      index ++ ;
    }

    if(auth.authDataPage == 0){
      print("BYTE ADTA Page 0");

      printByteData(byteData);

    }

    if (auth.authDataPage == 1){
      print("BYTE ADTA Page 1");

      printByteData(byteData);

    }


    print("ALL AUTH");
    print(auth);

    return auth;
  }



  static SelfID _parseSelfID(ByteData byteData) {
    final selfID = SelfID();
    selfID.descriptionType = byteData.getUint8(0);
    for (var i = 0; i < Constants.MAX_STRING_BYTE_SIZE; i++) {
      selfID.operationDescription[i] = byteData.getUint8(1 + i);
    }
    return selfID;
  }

  static SystemMsg _parseSystem(ByteData byteData) {
    final system = SystemMsg();
    var index = 0;

    final b = byteData.getUint8(index++);
    system.operatorLocationType = b & 0x03;
    system.classificationType = (b & 0x1C) >> 2;

    system.operatorLatitude = byteData.getInt32(index, Endian.little) * 1e-7;
    index += 4;
    system.operatorLongitude = byteData.getInt32(index, Endian.little) * 1e-7;
    index += 4;

    system.areaCount = byteData.getUint16(index, Endian.little);
    index += 2;
    system.areaRadius = byteData.getUint8(index++);
    system.areaCeiling = byteData.getUint16(index, Endian.little);
    index += 2;
    system.areaFloor = byteData.getUint16(index, Endian.little);
    index += 2;

    final categoryClass = byteData.getUint8(index++);
    system.category = (categoryClass & 0xF0) >> 4;
    system.classValue = categoryClass & 0x0F;

    system.operatorAltitudeGeo = byteData.getUint16(index, Endian.little);
    index += 2;
    system.systemTimestamp = byteData.getUint32(index, Endian.little);

    return system;
  }

  static OperatorID _parseOperatorID(ByteData byteData) {
    final operatorID = OperatorID();
    operatorID.operatorIdType = byteData.getUint8(0);
    for (var i = 0; i < Constants.MAX_ID_BYTE_SIZE; i++) {
      operatorID.operatorId[i] = byteData.getUint8(1 + i);
    }
    return operatorID;
  }

  static MessagePack _parseMessagePack(Uint8List payload, int offset) {
    final pack = MessagePack();
    final byteData = ByteData.view(payload.buffer, offset + 1, 2);
    pack.messageSize = byteData.getUint8(0);
    pack.messagesInPack = byteData.getUint8(1);

    if (pack.messageSize != Constants.MAX_MESSAGE_SIZE ||
        pack.messagesInPack <= 0 ||
        pack.messagesInPack > Constants.MAX_MESSAGES_IN_PACK) {
      return pack;
    }

    final start = offset + 1 + 2;
    final end = start + pack.messageSize * pack.messagesInPack;
    pack.messages.setRange(0, end - start, payload.sublist(start, end));

    return pack;
  }
}

void printByteData(ByteData byteData) {
  // Convert ByteData into a list of integers (bytes)
  List<int> byteList = [];
  for (int i = 0; i < byteData.lengthInBytes; i++) {
    byteList.add(byteData.getUint8(i)); // Add each byte to the list
  }

  // Print the byte list
  print(byteList);
}