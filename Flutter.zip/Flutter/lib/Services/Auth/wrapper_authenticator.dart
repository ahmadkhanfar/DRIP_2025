import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';

class WrapperAuthenticator {
  // Verify signature using Ed25519
  Future<bool> verifySignature(Uint8List message, Uint8List signature, SimplePublicKey publicKey) async {
    final algorithm = Ed25519();
    try {
      return await algorithm.verify(
        message,
        signature: Signature(signature, publicKey: publicKey),
      );
    } catch (e) {
      print("Signature verification failed: $e");
      return false;
    }
  }

  // Validate VNB (Valid Not Before) and VNA (Valid Not After) timestamps
  bool validateTimestamps(int vnb, int vna) {
    int currentTime = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    print("VNB (Valid Not Before): $vnb");
    print("VNA (Valid Not After): $vna");
    print("Current Time: $currentTime");

    return currentTime >= vnb && currentTime <= vna;
  }

  // Authenticate Wrapper
  Future<bool> authenticateWrapper(Uint8List wrapper) async {
    try {
      // Ensure the Wrapper is long enough
      if (wrapper.length < 96) { // Minimum size: 8 bytes (timestamps) + 32 bytes (UAV public key) + 64 bytes (signature)
        print("Invalid Wrapper: Too short.");
        return false;
      }

      // Extract VNB and VNA (first 8 bytes of the Wrapper)
      int vnb = wrapper.buffer.asByteData().getUint32(0, Endian.little);
      int vna = wrapper.buffer.asByteData().getUint32(4, Endian.little);

      // Validate timestamps
      if (!validateTimestamps(vnb, vna)) {
        print("Wrapper timestamps are invalid.");
        return false;
      }

      // Extract UAV public key (bytes 8–40)
      Uint8List uavPublicKey = wrapper.sublist(8, 40);

      // Extract UAV signature (last 64 bytes of the Wrapper)
      Uint8List uavSignature = wrapper.sublist(wrapper.length - 64);

      // Verify the UAV signature
      bool isVerified = await verifySignature(
        wrapper.sublist(0, wrapper.length - 64), // Exclude signature
        uavSignature,
        SimplePublicKey(uavPublicKey, type: KeyPairType.ed25519),
      );

      if (!isVerified) {
        print("Wrapper signature is invalid.");
        return false;
      }

      print("Wrapper authenticated successfully.");
      return true;
    } catch (e) {
      print("Error authenticating Wrapper: $e");
      return false;
    }
  }
}
