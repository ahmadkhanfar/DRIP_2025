

import 'dart:typed_data';

import '../../Services/Controllers/open_drone_id_parser.dart';

class ParsedResult {

  final Message<Payload> ? message;

  final ByteData evidence;

  ParsedResult ({
  required this.message,
  required this.evidence
});

}